USE [primefirebd]
GO

/****** COMPLETE DATABASE BACKUP WITH ALL DATA ******/
/****** Generated: 2026-07-21 15:24:43 ******/
/****** Database: primefirebd on server-primefiredb.database.windows.net ******/
/****** This script contains ALL table structures and ALL data ******/

-- =============================================
-- DROP ALL TABLES
-- =============================================

IF OBJECT_ID('dbo.warehouses', 'U') IS NOT NULL
    DROP TABLE dbo.warehouses;
GO

IF OBJECT_ID('dbo.warehouse_locations', 'U') IS NOT NULL
    DROP TABLE dbo.warehouse_locations;
GO

IF OBJECT_ID('dbo.time_sheet_settings', 'U') IS NOT NULL
    DROP TABLE dbo.time_sheet_settings;
GO

IF OBJECT_ID('dbo.time_sheet_punches', 'U') IS NOT NULL
    DROP TABLE dbo.time_sheet_punches;
GO

IF OBJECT_ID('dbo.time_sheet_location_snapshots', 'U') IS NOT NULL
    DROP TABLE dbo.time_sheet_location_snapshots;
GO

IF OBJECT_ID('dbo.time_off_requests', 'U') IS NOT NULL
    DROP TABLE dbo.time_off_requests;
GO

IF OBJECT_ID('dbo.time_off_balances', 'U') IS NOT NULL
    DROP TABLE dbo.time_off_balances;
GO

IF OBJECT_ID('dbo.tickets', 'U') IS NOT NULL
    DROP TABLE dbo.tickets;
GO

IF OBJECT_ID('dbo.ticket_recurrence_config', 'U') IS NOT NULL
    DROP TABLE dbo.ticket_recurrence_config;
GO

IF OBJECT_ID('dbo.ticket_messages', 'U') IS NOT NULL
    DROP TABLE dbo.ticket_messages;
GO

IF OBJECT_ID('dbo.ticket_attachments', 'U') IS NOT NULL
    DROP TABLE dbo.ticket_attachments;
GO

IF OBJECT_ID('dbo.tenants', 'U') IS NOT NULL
    DROP TABLE dbo.tenants;
GO

IF OBJECT_ID('dbo.tenant_logos', 'U') IS NOT NULL
    DROP TABLE dbo.tenant_logos;
GO

IF OBJECT_ID('dbo.tenant_employees', 'U') IS NOT NULL
    DROP TABLE dbo.tenant_employees;
GO

IF OBJECT_ID('dbo.roles', 'U') IS NOT NULL
    DROP TABLE dbo.roles;
GO

IF OBJECT_ID('dbo.role_modules', 'U') IS NOT NULL
    DROP TABLE dbo.role_modules;
GO

IF OBJECT_ID('dbo.quotations', 'U') IS NOT NULL
    DROP TABLE dbo.quotations;
GO

IF OBJECT_ID('dbo.quotation_items', 'U') IS NOT NULL
    DROP TABLE dbo.quotation_items;
GO

IF OBJECT_ID('dbo.products', 'U') IS NOT NULL
    DROP TABLE dbo.products;
GO

IF OBJECT_ID('dbo.product_specifications', 'U') IS NOT NULL
    DROP TABLE dbo.product_specifications;
GO

IF OBJECT_ID('dbo.product_families', 'U') IS NOT NULL
    DROP TABLE dbo.product_families;
GO

IF OBJECT_ID('dbo.product_categories', 'U') IS NOT NULL
    DROP TABLE dbo.product_categories;
GO

IF OBJECT_ID('dbo.product_catalog', 'U') IS NOT NULL
    DROP TABLE dbo.product_catalog;
GO

IF OBJECT_ID('dbo.product_attachments', 'U') IS NOT NULL
    DROP TABLE dbo.product_attachments;
GO

IF OBJECT_ID('dbo.modules', 'U') IS NOT NULL
    DROP TABLE dbo.modules;
GO

IF OBJECT_ID('dbo.licenses', 'U') IS NOT NULL
    DROP TABLE dbo.licenses;
GO

IF OBJECT_ID('dbo.jobs', 'U') IS NOT NULL
    DROP TABLE dbo.jobs;
GO

IF OBJECT_ID('dbo.inventory_movements', 'U') IS NOT NULL
    DROP TABLE dbo.inventory_movements;
GO

IF OBJECT_ID('dbo.inventory_movement_approvals', 'U') IS NOT NULL
    DROP TABLE dbo.inventory_movement_approvals;
GO

IF OBJECT_ID('dbo.holidays', 'U') IS NOT NULL
    DROP TABLE dbo.holidays;
GO

IF OBJECT_ID('dbo.hardware_inventory', 'U') IS NOT NULL
    DROP TABLE dbo.hardware_inventory;
GO

IF OBJECT_ID('dbo.external_users', 'U') IS NOT NULL
    DROP TABLE dbo.external_users;
GO

IF OBJECT_ID('dbo.employees', 'U') IS NOT NULL
    DROP TABLE dbo.employees;
GO

IF OBJECT_ID('dbo.employee_roles', 'U') IS NOT NULL
    DROP TABLE dbo.employee_roles;
GO

IF OBJECT_ID('dbo.departments', 'U') IS NOT NULL
    DROP TABLE dbo.departments;
GO

IF OBJECT_ID('dbo.customers', 'U') IS NOT NULL
    DROP TABLE dbo.customers;
GO

IF OBJECT_ID('dbo.customer_notes', 'U') IS NOT NULL
    DROP TABLE dbo.customer_notes;
GO

IF OBJECT_ID('dbo.customer_attachments', 'U') IS NOT NULL
    DROP TABLE dbo.customer_attachments;
GO

IF OBJECT_ID('dbo.customer_alternate_contacts', 'U') IS NOT NULL
    DROP TABLE dbo.customer_alternate_contacts;
GO

IF OBJECT_ID('dbo.curriculums', 'U') IS NOT NULL
    DROP TABLE dbo.curriculums;
GO

IF OBJECT_ID('dbo.countries', 'U') IS NOT NULL
    DROP TABLE dbo.countries;
GO

IF OBJECT_ID('dbo.auth_tokens', 'U') IS NOT NULL
    DROP TABLE dbo.auth_tokens;
GO

IF OBJECT_ID('dbo.addresses', 'U') IS NOT NULL
    DROP TABLE dbo.addresses;
GO


-- =============================================
-- CREATE ALL TABLES
-- =============================================

-- =============================================
-- Table: addresses
-- =============================================

CREATE TABLE [dbo].[addresses](
    [address_id] [int] IDENTITY(1,1) NOT NULL,
    [address_1] [nvarchar](200) NOT NULL,
    [address_2] [nvarchar](200) NULL,
    [city] [nvarchar](100) NOT NULL,
    [state] [nvarchar](100) NOT NULL,
    [zip_code] [nvarchar](20) NOT NULL,
    [country_id] [int] NOT NULL,
    [google_place_id] [nvarchar](255) NULL,
    [is_validated] [bit] NOT NULL DEFAULT ((0)),
    [validated_at] [datetime2] NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
 CONSTRAINT [pk_addresses] PRIMARY KEY CLUSTERED
(
    [address_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: auth_tokens
-- =============================================

CREATE TABLE [dbo].[auth_tokens](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [email] [nvarchar](255) NOT NULL,
    [token] [nvarchar](512) NOT NULL,
    [token_type] [nvarchar](50) NOT NULL,
    [expires_at] [datetime2] NOT NULL,
    [used_at] [datetime2] NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (getutcdate()),
 CONSTRAINT [PK_auth_tokens] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: countries
-- =============================================

CREATE TABLE [dbo].[countries](
    [country_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [varchar](20) NULL,
 CONSTRAINT [pk_countrie_10d1609f78e422f4] PRIMARY KEY CLUSTERED
(
    [country_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: curriculums
-- =============================================

CREATE TABLE [dbo].[curriculums](
    [curriculum_id] [int] IDENTITY(1,1) NOT NULL,
    [job_id] [int] NOT NULL,
    [name] [varchar](100) NOT NULL,
    [email] [varchar](100) NOT NULL,
    [phone] [varchar](20) NULL,
    [curriculum_path] [varchar](255) NULL,
    [cover_letter] [varchar](1000) NULL,
    [status] [varchar](20) NOT NULL,
    [submitted_at] [datetime] NOT NULL,
    [employee_id] [int] NULL,
 CONSTRAINT [pk_curricul_06c9fa1c1a1b5187] PRIMARY KEY CLUSTERED
(
    [curriculum_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: customer_alternate_contacts
-- =============================================

CREATE TABLE [dbo].[customer_alternate_contacts](
    [customer_alternate_contact_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [name] [nvarchar](200) NOT NULL,
    [email] [nvarchar](255) NULL,
    [phone] [nvarchar](20) NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
    [updated_at] [datetime2] NULL,
 CONSTRAINT [pk_customer_alternate_contacts] PRIMARY KEY CLUSTERED
(
    [customer_alternate_contact_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: customer_attachments
-- =============================================

CREATE TABLE [dbo].[customer_attachments](
    [customer_attachment_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [file_name] [nvarchar](255) NOT NULL,
    [file_type] [nvarchar](100) NULL,
    [file_path] [nvarchar](500) NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
    [created_by] [int] NOT NULL,
 CONSTRAINT [pk_customer_attachments] PRIMARY KEY CLUSTERED
(
    [customer_attachment_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: customer_notes
-- =============================================

CREATE TABLE [dbo].[customer_notes](
    [customer_note_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [note_text] [nvarchar](MAX) NOT NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
    [updated_at] [datetime2] NULL,
    [created_by] [int] NOT NULL,
 CONSTRAINT [pk_customer_notes] PRIMARY KEY CLUSTERED
(
    [customer_note_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: customers
-- =============================================

CREATE TABLE [dbo].[customers](
    [customer_id] [int] IDENTITY(1,1) NOT NULL,
    [customer_type] [nvarchar](20) NOT NULL,
    [company_name] [nvarchar](200) NULL,
    [first_name] [nvarchar](100) NULL,
    [last_name] [nvarchar](100) NULL,
    [additional_name] [nvarchar](100) NULL,
    [market] [nvarchar](50) NULL,
    [dtd_potential] [nvarchar](20) NULL,
    [primary_email] [nvarchar](255) NULL,
    [primary_phone] [nvarchar](20) NULL,
    [primary_address_id] [int] NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
    [updated_at] [datetime2] NULL,
    [created_by] [int] NOT NULL,
 CONSTRAINT [pk_customers] PRIMARY KEY CLUSTERED
(
    [customer_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: departments
-- =============================================

CREATE TABLE [dbo].[departments](
    [department_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [code] [nvarchar](20) NULL,
 CONSTRAINT [pk_departments] PRIMARY KEY CLUSTERED
(
    [department_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: employee_roles
-- =============================================

CREATE TABLE [dbo].[employee_roles](
    [employee_id] [int] NOT NULL,
    [role_id] [int] NOT NULL,
 CONSTRAINT [pk_employee_c27fe3f0c0f63c02] PRIMARY KEY CLUSTERED
(
    [employee_id] ASC,[role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: employees
-- =============================================

CREATE TABLE [dbo].[employees](
    [employee_id] [int] IDENTITY(1,1) NOT NULL,
    [first_name] [varchar](50) NULL,
    [last_name] [varchar](50) NULL,
    [display_name] [varchar](100) NULL,
    [title] [varchar](50) NULL,
    [department] [varchar](50) NULL,
    [office] [varchar](50) NULL,
    [email] [varchar](50) NULL,
    [phone] [varchar](20) NULL,
    [mobile_phone] [varchar](20) NULL,
    [office_phone] [varchar](20) NULL,
    [street_address] [varchar](100) NULL,
    [city] [varchar](50) NULL,
    [state] [varchar](50) NULL,
    [postal_code] [varchar](20) NULL,
    [country_id] [int] NULL,
    [azure_oid] [varchar](100) NULL,
    [azure_upn] [varchar](100) NULL,
    [last_synced_at] [datetime] NULL,
    [anydesk] [nvarchar](50) NULL,
    [password_hash] [nvarchar](255) NULL,
    [manager] [nvarchar](100) NULL,
    [manager_email] [nvarchar](100) NULL,
    [manager_employee_id] [int] NULL,
 CONSTRAINT [pk_employee_7ad04f1160241b26] PRIMARY KEY CLUSTERED
(
    [employee_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: external_users
-- =============================================

CREATE TABLE [dbo].[external_users](
    [external_user_id] [int] IDENTITY(1,1) NOT NULL,
    [email] [varchar](100) NOT NULL,
    [password_hash] [varchar](255) NOT NULL,
    [tenant_id] [int] NOT NULL,
    [created_at] [datetime] NOT NULL,
 CONSTRAINT [pk_external_94cc235758f0bdbe] PRIMARY KEY CLUSTERED
(
    [external_user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: hardware_inventory
-- =============================================

CREATE TABLE [dbo].[hardware_inventory](
    [hardware_id] [int] IDENTITY(1,1) NOT NULL,
    [serial_number] [varchar](50) NOT NULL,
    [brand] [varchar](50) NOT NULL,
    [model] [varchar](100) NULL,
    [device_type] [varchar](20) NULL,
    [processor] [varchar](100) NULL,
    [ram_gb] [int] NULL,
    [storage_type] [varchar](20) NULL,
    [storage_size_gb] [int] NULL,
    [gpu] [varchar](100) NULL,
    [operating_system] [varchar](100) NULL,
    [warranty_start_date] [date] NULL,
    [warranty_end_date] [date] NULL,
    [purchase_date] [date] NULL,
    [employee_id] [int] NULL,
    [location] [varchar](100) NULL,
    [status] [varchar](20) NULL,
    [notes] [varchar](255) NULL,
    [created_at] [datetime] NULL,
    [updated_at] [datetime] NULL,
 CONSTRAINT [pk_hardware_13a9b58868586958] PRIMARY KEY CLUSTERED
(
    [hardware_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: holidays
-- =============================================

CREATE TABLE [dbo].[holidays](
    [holiday_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [date] [varchar](10) NOT NULL,
    [year] [int] NOT NULL,
 CONSTRAINT [pk_holidays] PRIMARY KEY CLUSTERED
(
    [holiday_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: inventory_movement_approvals
-- =============================================

CREATE TABLE [dbo].[inventory_movement_approvals](
    [approval_id] [int] IDENTITY(1,1) NOT NULL,
    [product_id] [int] NOT NULL,
    [warehouse_id] [int] NULL,
    [movement_type] [varchar](20) NOT NULL,
    [quantity] [decimal](18,2) NOT NULL,
    [movement_date] [date] NOT NULL DEFAULT (CONVERT([date],getdate())),
    [project] [nvarchar](150) NULL,
    [po_number] [nvarchar](100) NULL,
    [reference_type] [nvarchar](50) NULL,
    [reference_id] [int] NULL,
    [notes] [nvarchar](500) NULL,
    [status] [varchar](20) NOT NULL DEFAULT ('PENDING'),
    [requested_by] [nvarchar](100) NULL,
    [requested_by_email] [nvarchar](255) NULL,
    [review_note] [nvarchar](500) NULL,
    [reviewed_by] [nvarchar](100) NULL,
    [reviewed_at] [datetime2] NULL,
    [movement_id] [int] NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (getdate()),
 CONSTRAINT [PK_inventory_movement_approvals] PRIMARY KEY CLUSTERED
(
    [approval_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: inventory_movements
-- =============================================

CREATE TABLE [dbo].[inventory_movements](
    [movement_id] [int] IDENTITY(1,1) NOT NULL,
    [product_id] [int] NOT NULL,
    [warehouse_id] [int] NULL,
    [movement_type] [varchar](20) NOT NULL,
    [quantity] [decimal](18,2) NOT NULL,
    [movement_date] [date] NOT NULL DEFAULT (CONVERT([date],getdate())),
    [project] [nvarchar](150) NULL,
    [po_number] [nvarchar](100) NULL,
    [notes] [nvarchar](500) NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (getdate()),
    [reference_type] [nvarchar](50) NULL,
    [reference_id] [int] NULL,
    [created_by] [nvarchar](100) NULL,
 CONSTRAINT [PK__inventor__3213E83F44D26BDC] PRIMARY KEY CLUSTERED
(
    [movement_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: jobs
-- =============================================

CREATE TABLE [dbo].[jobs](
    [job_id] [int] IDENTITY(1,1) NOT NULL,
    [title] [varchar](100) NOT NULL,
    [description] [varchar](1000) NULL,
    [requirements] [varchar](1000) NULL,
    [location] [varchar](100) NULL,
    [salary_min] [float] NULL,
    [salary_max] [float] NULL,
    [status] [varchar](20) NOT NULL,
    [posted_at] [datetime] NOT NULL,
    [employee_id] [int] NULL,
    [country_id] [int] NULL,
 CONSTRAINT [pk_jobs_056690c2c3a32b63] PRIMARY KEY CLUSTERED
(
    [job_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: licenses
-- =============================================

CREATE TABLE [dbo].[licenses](
    [license_id] [int] IDENTITY(1,1) NOT NULL,
    [software] [varchar](50) NULL,
    [version] [varchar](20) NULL,
    [created_at] [date] NULL,
    [expiry_date] [date] NULL,
    [key] [varchar](50) NULL,
    [account] [varchar](50) NULL,
    [password] [varchar](50) NULL,
    [employee_id] [int] NULL,
    [notes] [nvarchar](500) NULL,
 CONSTRAINT [pk_licenses_72d6008283025401] PRIMARY KEY CLUSTERED
(
    [license_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: modules
-- =============================================

CREATE TABLE [dbo].[modules](
    [module_id] [int] IDENTITY(1,1) NOT NULL,
    [module_name] [varchar](50) NOT NULL,
    [module_key] [varchar](50) NOT NULL,
    [description] [varchar](200) NULL,
    [icon] [varchar](50) NULL,
    [route_url] [varchar](100) NULL,
    [display_order] [int] NULL,
    [is_active] [bit] NOT NULL,
    [parent_module_id] [int] NULL,
    [created_at] [datetime] NULL,
 CONSTRAINT [pk_modules_2b7477a770a3bb13] PRIMARY KEY CLUSTERED
(
    [module_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: product_attachments
-- =============================================

CREATE TABLE [dbo].[product_attachments](
    [product_attachment_id] [int] IDENTITY(1,1) NOT NULL,
    [product_id] [int] NOT NULL,
    [file_name] [nvarchar](255) NOT NULL,
    [file_type] [nvarchar](100) NULL,
    [file_path] [nvarchar](500) NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
    [created_by] [int] NOT NULL,
 CONSTRAINT [PK__product___EAF11C22F4A16C1F] PRIMARY KEY CLUSTERED
(
    [product_attachment_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: product_catalog
-- =============================================

CREATE TABLE [dbo].[product_catalog](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [code] [nvarchar](50) NOT NULL,
    [name] [nvarchar](255) NOT NULL,
    [family_id] [int] NULL,
    [category_id] [int] NULL,
    [unit] [nvarchar](20) NULL,
    [min_stock] [decimal](12,2) NOT NULL DEFAULT ((0)),
    [active] [bit] NOT NULL DEFAULT ((1)),
    [description] [nvarchar](MAX) NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
 CONSTRAINT [PK__product___3213E83F6219B591] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: product_categories
-- =============================================

CREATE TABLE [dbo].[product_categories](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [family_id] [int] NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [description] [nvarchar](MAX) NULL,
    [active] [bit] NOT NULL DEFAULT ((1)),
 CONSTRAINT [PK__product___3213E83F057C7FB3] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: product_families
-- =============================================

CREATE TABLE [dbo].[product_families](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [description] [nvarchar](MAX) NULL,
    [active] [bit] NOT NULL DEFAULT ((1)),
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
 CONSTRAINT [PK__product___3213E83F228DA97D] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: product_specifications
-- =============================================

CREATE TABLE [dbo].[product_specifications](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [product_id] [int] NOT NULL,
    [specification] [nvarchar](100) NULL,
    [size] [nvarchar](100) NULL,
    [material] [nvarchar](100) NULL,
    [manufacturer] [nvarchar](100) NULL,
    [model] [nvarchar](100) NULL,
    [notes] [nvarchar](MAX) NULL,
 CONSTRAINT [PK__product___3213E83F70E621E2] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: products
-- =============================================

CREATE TABLE [dbo].[products](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](200) NOT NULL,
    [description] [nvarchar](1000) NULL,
    [type] [varchar](20) NOT NULL,
    [sku] [nvarchar](100) NULL,
    [unit_price] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [cost] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [tax_rate] [decimal](5,4) NOT NULL DEFAULT ((0)),
    [unit] [nvarchar](50) NOT NULL DEFAULT ('pieza'),
    [stock_quantity] [int] NOT NULL DEFAULT ((0)),
    [is_active] [bit] NOT NULL DEFAULT ((1)),
    [created_at] [datetime2] NOT NULL DEFAULT (sysdatetime()),
    [code] [nvarchar](100) NULL,
    [family] [nvarchar](100) NULL,
    [category] [nvarchar](100) NULL,
    [size] [nvarchar](100) NULL,
    [material_type] [nvarchar](100) NULL,
    [min_stock] [decimal](18,2) NULL,
    [needed_quantity] [decimal](18,2) NULL,
    [family_id] [int] NULL,
    [category_id] [int] NULL,
    [specification] [nvarchar](100) NULL,
    [manufacturer] [nvarchar](100) NULL,
    [model] [nvarchar](100) NULL,
 CONSTRAINT [pk_products_3214ec07d1f91339] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: quotation_items
-- =============================================

CREATE TABLE [dbo].[quotation_items](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [quotation_id] [int] NOT NULL,
    [product_id] [int] NOT NULL,
    [description] [nvarchar](1000) NULL,
    [quantity] [decimal](18,2) NOT NULL DEFAULT ((1)),
    [unit_price] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [discount] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [tax] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [total] [decimal](18,2) NOT NULL DEFAULT ((0)),
 CONSTRAINT [pk_quotatio_3214ec079f1c6400] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: quotations
-- =============================================

CREATE TABLE [dbo].[quotations](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [customer_id] [int] NOT NULL,
    [quote_date] [datetime2] NOT NULL DEFAULT (sysdatetime()),
    [expiration_date] [datetime2] NULL,
    [subtotal] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [tax] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [discount] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [total] [decimal](18,2) NOT NULL DEFAULT ((0)),
    [status] [varchar](20) NOT NULL DEFAULT ('Draft'),
    [notes] [nvarchar](2000) NULL,
    [created_at] [datetime2] NOT NULL DEFAULT (sysdatetime()),
 CONSTRAINT [pk_quotatio_3214ec074ec3b0f6] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: role_modules
-- =============================================

CREATE TABLE [dbo].[role_modules](
    [role_id] [int] NOT NULL,
    [module_id] [int] NOT NULL,
    [can_view] [bit] NOT NULL,
    [can_create] [bit] NOT NULL,
    [can_edit] [bit] NOT NULL,
    [can_delete] [bit] NOT NULL,
    [can_export] [bit] NOT NULL,
    [admin_actions] [bit] NOT NULL,
    [other_actions] [bit] NOT NULL,
    [assigned_at] [datetime] NULL,
 CONSTRAINT [pk_role_modu_e84d89600a5756de] PRIMARY KEY CLUSTERED
(
    [role_id] ASC,[module_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: roles
-- =============================================

CREATE TABLE [dbo].[roles](
    [role_id] [int] IDENTITY(1,1) NOT NULL,
    [role_name] [varchar](50) NOT NULL,
    [description] [varchar](200) NULL,
 CONSTRAINT [pk_roles_8aface1a81a168c1] PRIMARY KEY CLUSTERED
(
    [role_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: tenant_employees
-- =============================================

CREATE TABLE [dbo].[tenant_employees](
    [id] [int] IDENTITY(1,1) NOT NULL,
    [tenant_id] [int] NOT NULL,
    [employee_id] [int] NOT NULL,
    [status] [varchar](20) NOT NULL,
    [IsDefault] [bit] NOT NULL,
    [created_at] [datetime] NOT NULL,
 CONSTRAINT [pk_tenant_em_3214ec072433eafd] PRIMARY KEY CLUSTERED
(
    [id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: tenant_logos
-- =============================================

CREATE TABLE [dbo].[tenant_logos](
    [logo_id] [int] IDENTITY(1,1) NOT NULL,
    [tenant_id] [int] NOT NULL,
    [title] [varchar](100) NOT NULL,
    [description] [varchar](500) NULL,
    [path] [varchar](500) NOT NULL,
    [path_background] [varchar](500) NULL,
    [primary_color] [varchar](50) NULL,
    [secondary_color] [varchar](50) NULL,
    [tertiary_color] [varchar](50) NULL,
    [created_at] [datetime] NOT NULL,
    [updated_at] [datetime] NULL,
    [url] [nvarchar](500) NOT NULL,
 CONSTRAINT [pk_tenant_lo_c620158d40bfcf43] PRIMARY KEY CLUSTERED
(
    [logo_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: tenants
-- =============================================

CREATE TABLE [dbo].[tenants](
    [tenant_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [varchar](100) NOT NULL,
    [db_connection_key] [varchar](50) NOT NULL,
    [description] [varchar](255) NULL,
    [is_active] [bit] NOT NULL,
    [created_at] [datetime] NOT NULL,
 CONSTRAINT [pk_tenants_2e9b47e1f92eb300] PRIMARY KEY CLUSTERED
(
    [tenant_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: ticket_attachments
-- =============================================

CREATE TABLE [dbo].[ticket_attachments](
    [ticket_attachment_id] [int] IDENTITY(1,1) NOT NULL,
    [ticket_id] [int] NOT NULL,
    [ticket_message_id] [int] NULL,
    [file_name] [varchar](255) NOT NULL,
    [file_type] [varchar](100) NULL,
    [file_path] [varchar](500) NULL,
    [created_at] [datetime] NOT NULL,
 CONSTRAINT [pk_ticket_at_25528bc8235cc48c] PRIMARY KEY CLUSTERED
(
    [ticket_attachment_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: ticket_messages
-- =============================================

CREATE TABLE [dbo].[ticket_messages](
    [ticket_message_id] [int] IDENTITY(1,1) NOT NULL,
    [ticket_id] [int] NOT NULL,
    [user_id] [int] NOT NULL,
    [message_txt] [varchar](MAX) NULL,
    [created_at] [datetime] NOT NULL,
    [updated_at] [datetime] NULL,
    [edited_at] [datetime] NULL,
 CONSTRAINT [pk_ticket_me_602a18a4d77f2994] PRIMARY KEY CLUSTERED
(
    [ticket_message_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: ticket_recurrence_config
-- =============================================

CREATE TABLE [dbo].[ticket_recurrence_config](
    [config_id] [int] IDENTITY(1,1) NOT NULL,
    [ticket_id] [int] NULL,
    [recurrence_type] [nvarchar](20) NOT NULL DEFAULT ('none'),
    [next_occurrence] [datetime2] NULL,
    [parent_ticket_id] [int] NULL,
    [is_active] [bit] NOT NULL DEFAULT ((1)),
    [created_at] [datetime2] NOT NULL DEFAULT (sysutcdatetime()),
 CONSTRAINT [PK__ticket_r__4AD1BFF13CCC2FDF] PRIMARY KEY CLUSTERED
(
    [config_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: tickets
-- =============================================

CREATE TABLE [dbo].[tickets](
    [ticket_id] [int] IDENTITY(1,1) NOT NULL,
    [title] [varchar](200) NOT NULL,
    [description] [varchar](2000) NULL,
    [status] [varchar](11) NOT NULL,
    [priority] [varchar](6) NOT NULL,
    [sla] [varchar](3) NULL,
    [created_by] [int] NOT NULL,
    [assigned_to] [int] NULL,
    [created_at] [datetime2] NOT NULL,
    [updated_at] [datetime2] NOT NULL,
    [ticket_type] [nvarchar](20) NOT NULL DEFAULT ('request'),
    [in_progress_at] [datetime2] NULL,
 CONSTRAINT [pk_tickets_712cc607abd622ab] PRIMARY KEY CLUSTERED
(
    [ticket_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: time_off_balances
-- =============================================

CREATE TABLE [dbo].[time_off_balances](
    [balance_id] [int] IDENTITY(1,1) NOT NULL,
    [employee_id] [int] NOT NULL,
    [absence_type] [varchar](20) NOT NULL,
    [year] [int] NOT NULL,
    [entitled_days] [varchar](10) NOT NULL DEFAULT ('0.00'),
    [used_days] [varchar](10) NOT NULL DEFAULT ('0.00'),
    [pending_days] [varchar](10) NOT NULL DEFAULT ('0.00'),
    [carryover_days] [varchar](10) NOT NULL DEFAULT ('0.00'),
 CONSTRAINT [pk_time_off_balances] PRIMARY KEY CLUSTERED
(
    [balance_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: time_off_requests
-- =============================================

CREATE TABLE [dbo].[time_off_requests](
    [request_id] [int] IDENTITY(1,1) NOT NULL,
    [employee_id] [int] NOT NULL,
    [absence_type] [varchar](20) NOT NULL,
    [status] [varchar](20) NOT NULL DEFAULT ('pending'),
    [time_unit] [varchar](20) NOT NULL,
    [start_date] [varchar](10) NOT NULL,
    [end_date] [varchar](10) NOT NULL,
    [start_time] [varchar](8) NULL,
    [end_time] [varchar](8) NULL,
    [total_hours] [varchar](10) NULL,
    [total_days] [varchar](10) NOT NULL,
    [reason] [nvarchar](MAX) NULL,
    [reviewed_by] [int] NULL,
    [reviewed_at] [varchar](19) NULL,
    [review_notes] [nvarchar](MAX) NULL,
    [created_at] [varchar](19) NOT NULL,
    [updated_at] [varchar](19) NOT NULL,
 CONSTRAINT [pk_time_off_requests] PRIMARY KEY CLUSTERED
(
    [request_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: time_sheet_location_snapshots
-- =============================================

CREATE TABLE [dbo].[time_sheet_location_snapshots](
    [snapshot_id] [int] IDENTITY(1,1) NOT NULL,
    [employee_id] [int] NOT NULL,
    [customer_id] [int] NULL,
    [ip_address] [varchar](45) NULL,
    [latitude] [varchar](20) NULL,
    [longitude] [varchar](20) NULL,
    [gps_accuracy] [varchar](20) NULL,
    [city] [nvarchar](100) NULL,
    [region] [nvarchar](100) NULL,
    [country] [nvarchar](100) NULL,
    [timezone] [varchar](80) NULL,
    [location_raw] [nvarchar](MAX) NULL,
    [captured_at] [varchar](19) NOT NULL,
 CONSTRAINT [pk_time_sheet_location_snapshots] PRIMARY KEY CLUSTERED
(
    [snapshot_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: time_sheet_punches
-- =============================================

CREATE TABLE [dbo].[time_sheet_punches](
    [punch_id] [int] IDENTITY(1,1) NOT NULL,
    [employee_id] [int] NOT NULL,
    [customer_id] [int] NOT NULL,
    [clock_in_at] [varchar](19) NOT NULL,
    [clock_out_at] [varchar](19) NULL,
    [timezone] [varchar](80) NULL,
    [ip_address] [varchar](45) NULL,
    [latitude] [varchar](20) NULL,
    [longitude] [varchar](20) NULL,
    [gps_accuracy] [varchar](20) NULL,
    [city] [nvarchar](100) NULL,
    [region] [nvarchar](100) NULL,
    [country] [nvarchar](100) NULL,
    [location_raw] [nvarchar](MAX) NULL,
    [worked_minutes] [int] NOT NULL DEFAULT ((0)),
    [status] [varchar](20) NOT NULL DEFAULT ('open'),
    [note] [nvarchar](MAX) NULL,
    [approved_by] [int] NULL,
    [approved_at] [varchar](19) NULL,
    [created_at] [varchar](19) NOT NULL,
    [updated_at] [varchar](19) NOT NULL,
 CONSTRAINT [pk_time_sheet_punches] PRIMARY KEY CLUSTERED
(
    [punch_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: time_sheet_settings
-- =============================================

CREATE TABLE [dbo].[time_sheet_settings](
    [setting_id] [int] IDENTITY(1,1) NOT NULL,
    [overtime_daily_hours] [varchar](10) NOT NULL DEFAULT ('8.00'),
    [overtime_weekly_hours] [varchar](10) NULL DEFAULT ('40.00'),
    [round_to_minutes] [int] NULL,
    [is_active] [bit] NOT NULL DEFAULT ((1)),
    [created_at] [varchar](19) NOT NULL,
    [updated_at] [varchar](19) NOT NULL,
    [max_overtime_daily_hours] [nvarchar](10) NULL,
 CONSTRAINT [pk_time_sheet_settings] PRIMARY KEY CLUSTERED
(
    [setting_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: warehouse_locations
-- =============================================

CREATE TABLE [dbo].[warehouse_locations](
    [warehouse_location_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](200) NOT NULL,
    [is_active] [bit] NOT NULL DEFAULT ((1)),
 CONSTRAINT [PK__warehous__292B0D6FF460C173] PRIMARY KEY CLUSTERED
(
    [warehouse_location_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

-- =============================================
-- Table: warehouses
-- =============================================

CREATE TABLE [dbo].[warehouses](
    [warehouse_id] [int] IDENTITY(1,1) NOT NULL,
    [name] [nvarchar](100) NOT NULL,
    [location] [nvarchar](200) NULL,
    [is_active] [bit] NOT NULL DEFAULT ((1)),
    [location_id] [int] NULL,
 CONSTRAINT [PK__warehous__3213E83F4DE66F6C] PRIMARY KEY CLUSTERED
(
    [warehouse_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


-- =============================================
-- INSERT DATA FOR ALL TABLES
-- =============================================


-- Data for countries (8 records)
SET IDENTITY_INSERT [dbo].[countries] ON
GO

INSERT [dbo].[countries] ([country_id], [name]) VALUES (1, N'US')
INSERT [dbo].[countries] ([country_id], [name]) VALUES (2, N'PR')
INSERT [dbo].[countries] ([country_id], [name]) VALUES (3, N'DO')
INSERT [dbo].[countries] ([country_id], [name]) VALUES (4, N'MX')
INSERT [dbo].[countries] ([country_id], [name]) VALUES (5, N'Mexico')
INSERT [dbo].[countries] ([country_id], [name]) VALUES (6, N'Dominican Republic')
INSERT [dbo].[countries] ([country_id], [name]) VALUES (7, N'Puerto Rico')
INSERT [dbo].[countries] ([country_id], [name]) VALUES (8, N'United States')

SET IDENTITY_INSERT [dbo].[countries] OFF
GO


-- Data for addresses (474 records)
SET IDENTITY_INSERT [dbo].[addresses] ON
GO

INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (1, N'Plaza Galerias #3', NULL, N'Santo Domingo', N'RD', N'123456', 3, NULL, 0, NULL, N'2026-02-19 16:30:33.0000000')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (2, N'C. Rafael Augusto Sánchez 92,', NULL, N'Santo Domingo', N'Distrito Nacional', N'10129', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9107432')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (3, N'Dir: Emilio A. Morel #15', N'Ensance La Fe', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9269128')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (4, N'DIR CASIMIRO DE MOYA', N'REPUBLICA DOMINICANA', N'Gazcue', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9281446')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (5, N'Ave. Wiston Churchill no. 53', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9285114')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (6, N'ABI KARRAM MORILLA INGENIEROS ARQUITECTOS', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9285114')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (7, N'Playa Arena Gorda,', N'Carr. El Macao-Arena Gorda', N'La Altagracia', N'La Altagracia', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9289325')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (8, N'Domicilio Social Av. Abraham Lincoln #960', NULL, N'D.N.', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9289325')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (9, N'República Dominicana', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9289325')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (10, N'República Dominicana', NULL, N'Montecristi', N'Montecristi', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9301539')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (11, N'Avda. George Washington 500', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9301539')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (12, N'INDUSTRIALES SRL', NULL, N'Bonao', N'Monseñor Nouel', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9305318')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (13, N'Av. Abraham Lincoln #960, Santo Domingo', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9309480')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (14, N'C. Del Sol 32-34,', N'Rep. Dom.', N'Santiago de los Caballeros', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9309480')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (15, N'Av. Winston Churchill 1452,', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9309480')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (16, N'Calle del Sol No. 51, Centro de la Ciudad', NULL, N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9321656')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (17, N'C. Francisco Prats Ramírez 877,', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9325562')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (18, N'Av. Winston Churchill, Esq. Gustavo Mejia', N'Torre Blue Mall, Piso 23', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9329657')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (19, N'Ingyosa Ingenieria EIRL', N'Calle Estado de Israel, Plaza Centro del', N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9329657')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (20, N'Carr. Ramón Santana Proyecto Esperanza', N'Rep. Dom', N'San Pedro de Macorís', N'San Pedro de Macorís', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9329657')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (21, N'Autopista Duar Km. 22 1/2', N'Parque industrial  Duarte.', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9329657')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (22, N'Rep. Dom.', NULL, N'San Cristóbal', N'San Cristóbal', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9329657')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (23, N'Rep. Dom.', NULL, N'Santiago de los Caballeros', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9341750')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (24, N'Av 27 de Febrero 1760, Alameda', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9341750')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (25, N'365 George Washington Avenue', N'Dominican Republic, 10205', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9345752')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (26, N'No. 402, C/ Arzobispo Nouel, Santo Doming', N'Renzo Saavedra', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9349864')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (27, N'mario@ingemati.com', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9349864')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (28, N'Calle César A. Canó #32', N'Rep. Dom.', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9349864')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (29, N'Av. Máximo Gómez, Esq.', N'Pedro Livio Cedeño,', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9349864')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (30, N'Av. Sarasota 20,', N'Rep. Dom.', N'Santo Domingo', N'Distrito Nacional', N'10109', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9349864')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (31, N'Calle 3ra NO.19', N'Edificio R,', N'D.N.', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9361856')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (32, N'C. Francisco del Rosario Sánchez', N'Rep. Dom.', N'San Pedro de Macorís', N'San Pedro de Macorís', N'21000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9361856')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (33, N'Roberto Pastoriza 15, Santiago de los Cab', NULL, N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9365933')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (34, N'Av. Abraham Lincoln 960', NULL, N'DN', N'Distrito Nacional', N'11202', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9370069')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (35, N'WARECOMM', N'Martin Calderon - mcalderon@warecomm.net', N'Distrito Nacional', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9370069')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (36, N'Ext. III Zona Franca Industrial', NULL, N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9381949')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (37, N'Calle Capitán Eugenio de Marchena 22La Es', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9386117')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (38, N'Urb. Los Rosales, Santiago, Rep, Dominica', NULL, N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9394684')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (39, N'Av. Rafael Vidal, El Embrujo I, Santago,', N'Rep. Dominicana', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9400747')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (40, N'InciIFire SRL', N'Calle Espiritu Santo No. 2,', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9406416')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (41, N'República Domicana', NULL, N'La Romana', N'La Romana', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9409633')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (42, N'info@semsrd.com', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:32:44.9419662')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (43, N'Misc 2023', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:32:54.7235294')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (44, N'Sodexo Misc 2023', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:32:54.7241378')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (45, N'Misc 2024', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:32:54.7241378')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (46, N'Misc 2025', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:32:54.7241378')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (47, N'Sodexo Misc Bta, Guayama & Citi', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:32:54.7241378')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (48, N'Luis Brett', N'Cel.: 1 (829) 839-9758', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:03.1040953')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (49, N'20259 Plaza Lincoln', N'Av Abraham Lincoln', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:03.1048507')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (50, N'Prime Fire Dominicana, SRL', N'Av. Abraham Lincoln, Plaza Comercial', N'Santo Domingo', N'Distrito Nacional', N'10108', 6, NULL, 0, NULL, N'2026-05-22 16:33:03.1054646')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (51, N'Ing. Joaquin Peignand', N'Sr. EHS & Security Engineer', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:03.1054646')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (52, N'Calle del Parque 607', NULL, N'San Juan', N'PR', N'00909', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1068941')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (53, N'Pmb 302 - 1353 Rd.19', NULL, N'Guaynabo', N'PR', N'00966', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1068941')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (54, N'HC40 Box 44355', NULL, N'San Lorenzo', N'PR', N'00754', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1079280')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (55, N'PO Box 810061', NULL, N'Carolina', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1083543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (56, N'Industrial C&S of P.R. LLC', N'URB Parc Ponderosa', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1083543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (57, N'INDUSTRIAL C&S OF P.R. LLC', N'URB Parc Ponderosa', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1083543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (58, N'ABB Installation Products Caribe LLC', N'Cabo Caribe Ind. Park', N'Vega Baja', N'PR', N'00694-4058', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1083543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (59, N'Vascular Business Unit', N'PO Box 1410', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1083543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (60, N'PO Box 3030', NULL, N'Barceloneta', N'PR', N'00617', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1083543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (61, N'Bo. Palmas', N'PR', N'Cataño', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1099391')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (62, N'1909, 1893 Cll Narciso', NULL, N'SanJuan', N'PR', N'00927', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1099391')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (63, N'42 Broadway 2nd Floor', NULL, N'Lynbrook', N'NY', N'11563', 8, NULL, 0, NULL, N'2026-05-22 16:33:11.1099391')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (64, N'284 Calle B Parque Industrial Luchetti', NULL, N'Bayamon', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1099391')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (65, N'PO Box 1271', NULL, N'Saint Just', N'PR', N'00978', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1099391')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (66, N'463 Ave Ponce de Leon', NULL, N'Hato Rey', N'PR', N'00936-4508', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1099391')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (67, N'119 El Tuque Industrial Park', NULL, N'Ponce', N'PR', N'00728', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1118374')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (68, N'PO BOX 38085', NULL, N'SAN JUAN', N'PR', N'00937-1085', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1118374')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (69, N'PO Box 1890', N'Guayama', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1118374')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (70, N'RR5 Box 8418 Suite #3', NULL, N'Bayamon', N'PR', N'00956', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1118374')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (71, N'PO Box 2559', NULL, N'Toa Baja', N'PR', N'00951', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1118374')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (72, N'270 PR I Unit #2', N'250 Munoz Rivera Suite 320', N'San Juan', N'PR', N'00918', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1139814')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (73, N'PO Box 2128', NULL, N'San Juan', N'PR', N'00922-2128', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1139814')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (74, N'PO BOX 1776', NULL, N'San Lorenzo', N'PR', N'00754-1776', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1139814')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (75, N'PO Box 94995', N'Cleveland, OH 44101-4995', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1139814')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (76, N'Bo. Puente de Jobos', N'Carr. #3 KM 144.7', N'Guayama', N'PR', N'00784', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1158621')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (77, N'PMB #419 - 90', N'Ave. Rio Hondo', N'Bayamon', N'PR', N'00961', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1158621')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (78, N'PO Box 893', N'PR', N'Humacao', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1158621')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (79, N'PO Box 427', NULL, N'Newbury Park', N'CA', N'91319', 8, NULL, 0, NULL, N'2026-05-22 16:33:11.1158621')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (80, N'Surgical Specialties PR, Inc.', N'Accounts Payable Department', N'Aguadilla', N'PR', N'00605', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1171961')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (81, N'1836 C Reina de las Flores', NULL, N'San Juan', N'PR', N'00927', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1175134')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (82, N'PO Box 9084', NULL, N'San Juan', N'PR', N'00908-1084', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1178468')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (83, N'PO BOX 2129', NULL, N'San Juan', N'PR', N'00922-2129', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1178468')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (84, N'P.O. Box 808', NULL, N'Juncos', N'PR', N'00777', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1184623')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (85, N'PO BOX 2128', NULL, N'San Juan', N'PR', N'00922-2128', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1184623')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (86, N'3465 Chandler Creek Road', N'Virginia Beach, VA 23453', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1184623')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (87, N'Mylan, Inc.', N'P.O. Box 2648', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1184623')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (88, N'PO Box 16575', NULL, N'San Juan', N'PR', N'00908', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1184623')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (89, N'Apartado 364267', N'Correo General', N'San Juan', N'PR', N'00936-4267', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1196762')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (90, N'Las Islas Municipio', N'PO Box 41267', N'San Juan', N'PR', N'00940', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1196762')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (91, N'State Road 165 KM 2.6', NULL, N'Cataño', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1196762')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (92, N'CR Bard C/O BD', N'1 Becton Drive', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1196762')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (93, N'00 PARK AVENUE,', N'FLORHAM PARK, NJ 07932-0685', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1196762')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (94, N'BAXTER HEALTHCARE OF PUERTO RICO', N'BAS-COSTA RICA', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1196762')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (95, N'Accounts Payable Dept.', N'Call Box 2200', N'Aibonito', N'PR', N'00705-2200', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1196762')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (96, N'BAXTER HEALTHCARE OF PUERTO RICO', N'BAS-COSTA RICA', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1216861')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (97, N'PO Box 2002', NULL, N'Cataño', N'PR', N'00963', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1216861')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (98, N'PO Box 5200', N'Rantoul, IL 61866-5200', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1216861')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (99, N'Suite 103, Plaza El Amal Building', N'282 J.T. Piñero Ave.', N'San Juan', N'PR', N'00927', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1216861')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (100, N'PO Box 402', NULL, N'Juncos', N'PR', N'00777-0402', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1216861')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (101, N'PMB 398 200 AVE. RAFAEL CORDERO', NULL, N'Caguas', N'PR', N'00725', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1236976')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (102, N'Urb. Palacios del Rio II', N'692 Calle Guajataca', N'Toa Alta', N'PR', N'00961-3105', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1236976')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (103, N'Los Jardines Shopping Center', N'130 Marginal St Suite 11', N'Guaynabo', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1236976')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (104, N'PO Box 193476', NULL, N'San Juan', N'PR', N'00919-3476', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1253825')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (105, N'211161 Brisas del Bosque', NULL, N'Cayey', N'PR', N'00736', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1257159')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (106, N'3100 Carr. 199, Suite 203', NULL, N'San Juan', N'PR', N'00926', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1257159')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (107, N'501 West Lake St, Suite 104', N'Elmhurst, IL 60126-1419', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1257159')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (108, N'BMS Manufacturing Company', N'ATTN: Accounts Payable', N'Tampa', N'FL', N'33622', 8, NULL, 0, NULL, N'2026-05-22 16:33:11.1257159')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (109, N'NG&G Facility Services Intl', N'263 Jenckes Hill Rd', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1277274')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (110, N'Portsmouth · Commonwealth of Dominica', NULL, N'Bell Hall Road', N'CA', N'00000', 8, NULL, 0, NULL, N'2026-05-22 16:33:11.1287477')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (111, N'PO Box 601893', NULL, N'Bayamón', N'PR', N'00960-1893', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1290900')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (112, N'Calle Nebraska U-4', NULL, N'Caguas', N'PR', N'00725', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1297394')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (113, N'300 Ave. Baltazar Jiménez Méndez', NULL, N'Camuy', N'PR', N'00627', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1297394')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (114, N'US Food & Drugs Administration', NULL, N'San Juan', N'PR', N'00901', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1297394')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (115, N'GPO Box 366211', NULL, N'San Juan', N'PR', N'00936-6211', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1297394')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (116, N'PO Box 10578', NULL, N'San Juan', N'PR', N'00922', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1313035')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (117, N'P.O. Box 29155', NULL, N'San Juan', N'PR', N'00929-0155', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1317494')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (118, N'PO 29726', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1317494')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (119, N'PO Box 9024051', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1328687')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (120, N'PO Box 338', NULL, N'Cataño', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1331832')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (121, N'PO Box 11999', N'Cidra', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1335715')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (122, N'PO BOX 790', NULL, N'Peñuelas', N'PR', N'00624-0790', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1335715')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (123, N'PO Box 116', NULL, N'Manati', N'PR', N'00674', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1335715')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (124, N'PO Box 25070', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1335715')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (125, N'CBRE GWS OF Puerto Rico, Inc.', N'Tax ID-66-0827285', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1354310')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (126, N'CBRE GWS OF Puerto Rico, Inc.', N'Tax ID-66-0827285', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1354310')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (127, N'PO Box 1681', NULL, N'Sabana Grande', N'PR', N'00637', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1361108')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (128, N'Calle Leone #1655', N'Com Punta Diamante', N'Ponce', N'PR', N'00728', 7, NULL, 0, NULL, N'2026-05-22 16:33:11.1366315')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (129, N'ACCOUNT PAYABLES DEPT.', N'PO BOX 1690', N'Mayaguez', N'PR', N'00681', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5751761')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (130, N'PO Box 191149', NULL, N'San Juan', N'PR', N'00919-1149', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5757619')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (131, N'Urb. Baralt', N'Ave. Principal I-10', N'Fajardo', N'PR', N'00738', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5760974')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (132, N'State Road #1 Km.23.0 Rio Ward', NULL, N'Guaynabo', N'PR', N'00971', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5764382')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (133, N'P.O. Box 1009', NULL, N'Gurabo', N'PR', N'00778', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5764382')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (134, N'PO Box 9752', NULL, N'San Juan', N'PR', N'00908', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5764382')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (135, N'PO BOX 11924', NULL, N'San Juan', N'PR', N'00922', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5764382')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (136, N'360 Harvey Road', N'Manchester, NH 03103', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5764382')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (137, N'Colgate-Palmolive Company Distr. LLC.', N'PO Box 363865', N'San Juan', N'PR', N'00936-3865', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5764382')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (138, N'PO Box 363865', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5780252')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (139, N'Columbia Care LLC', N'2381 Boulevard Luis A, Ferr', N'Ponce', N'PR', N'00717-0762', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5780252')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (140, N'PO Box 1208', NULL, N'Naguabo', N'PR', N'00718-1208', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5780252')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (141, N'PO Box 362983', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5788877')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (142, N'108 Liberty Street', N'Metuchen, NJ 08840', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5788877')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (143, N'Centro de Seguros, Suite 208', NULL, N'San Juan', N'PR', N'00907', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5788877')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (144, N'#105 Ave. Arterial Hostos', N'Buzon 266', N'San Juan', N'PR', N'00918', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5800441')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (145, N'PO BOX 373100', NULL, N'Cayey', N'PR', N'00737', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5809110')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (146, N'Calle Luis Muñoz Rivera #71', NULL, N'Yabucoa', N'PR', N'00767', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5809110')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (147, N'PO Box 561', N'PR', N'Humacao', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5809110')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (148, N'PO 364925', NULL, N'San Juan', N'PR', N'00936-4925', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5820568')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (149, N'425 Carr. 693 PMB 210', N'PR', N'Dorado', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5829316')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (150, N'C/C #1 Esq. C/5-S Residencial', N'Los Rosales Km 10 Carr Mella', N'Santo Domingo', N'DO', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:20.5829316')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (151, N'No 38 Pine Road,', N'Belleville Corporate Center', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5829316')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (152, N'Box 100', NULL, N'Las Piedras', N'PR', N'00771', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5840665')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (153, N'500 State Road 584', NULL, N'Juana Diaz', N'PR', N'00795', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5840665')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (154, N'Carr 110 KM 28.8', N'San Antonio Industrial Park', N'Aguadialla', N'PR', N'00603', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5849529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (155, N'PO Box 9144', NULL, N'San Juan', N'PR', N'00908', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5849529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (156, N'P.O. Box 303', N'Aguas Buenas, P.R. 00703', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5849529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (157, N'5443 Katy Hockley Cut Off Rd,', NULL, N'Katy', N'TX', N'77493', 8, NULL, 0, NULL, N'2026-05-22 16:33:20.5849529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (158, N'URB INDUSTRIAL VICTOR FERNANDEZ', N'# 340 CALLE 3 Ste-1', N'San Juan', N'PR', N'00926', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5849529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (159, N'Plaza Matienzo', NULL, N'Trujillo Alto', N'PR', N'00976', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5860754')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (160, N'9487 Regency Square Blvd.', NULL, N'Jacksonville', N'FL', N'32225', 8, NULL, 0, NULL, N'2026-05-22 16:33:20.5860754')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (161, N'PO Box 97', NULL, N'Las Piedras', N'PR', N'00771', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5867789')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (162, N'Converged Systems and Solutions', N'#38 Pine Road', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5867789')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (163, N'89 De Diego Ave.', N'PMB 580 Suite 105', N'San Juan', N'PR', N'00921', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5867789')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (164, N'Carr. 865 KM 5.4', NULL, N'Toa Baja', N'PR', N'00949', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5875741')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (165, N'HC04 Box 23646', NULL, N'Lajas', N'PR', N'00667', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5875741')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (166, N'C/O Dentsply Sirona, Inc..', N'PO Box 2846', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5880840')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (167, N'CORRECCION Y REHABILITACION', N'PO Box 71308', N'San Juan', N'PR', N'00936-8408', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5880840')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (168, N'Financial Services Center', N'P.O. Box 149971', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5880840')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (169, N'Villa Alegría', N'Calle Topacio #259', N'Aguadilla', N'PR', N'00603', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5890014')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (170, N'1919 Gallows Rd. Suite 950', N'Vienna', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5890014')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (171, N'PO BOX 3941', NULL, N'GUAYNABO', N'PR', N'00970', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5895813')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (172, N'Metro Medical Center Bldg', N'Torre B Piso 7, suite 701', N'Bayamon', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5895813')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (173, N'Norte Shopping Center', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5895813')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (174, N'Domicilio social Av. Abraham Lincoln #960', N'República Dominicana', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5910247')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (175, N'PMB 133, 405 Ave. Esmeralda Suite 102', NULL, N'Guaynabo', N'PR', N'00969', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5917979')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (176, N'Firm Delivery', N'641 Road 337', N'Peñuelas', N'PR', N'00624-9804', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5924256')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (177, N'Honeywell', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5927309')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (178, N'HC-03 Box 6413', NULL, N'Humacao', N'PR', N'00791', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5927309')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (179, N'PO Box 194111', NULL, N'San Juan', N'PR', N'00919-4111', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5936097')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (180, N'Centro Internacional de Mercadeo II', N'Carr. 165 Torre 90 Of. 312', N'Guaynabo', N'PR', N'00968', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5939115')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (181, N'PO BOX 193201', NULL, N'San Juan', N'PR', N'00919', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5939115')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (182, N'Cupey, PR', NULL, N'Cupey', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5956209')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (183, N'PO Box 16571', N'New Brunswick, NJ 08906-6571', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5960854')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (184, N'10250 Valley Rd.', N'Suite 123', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5963926')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (185, N'Services, Inc.', N'PO Box 195288', N'San Juan', N'PR', N'00919-5288', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5963926')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (186, N'5000 Carretera 190', NULL, N'Carolina', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5963926')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (187, N'5000 Carretera 190', NULL, N'Carolina', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5976359')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (188, N'466 Fernández Juncos Ave', NULL, N'San Juan', N'PR', N'00901-3223', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5981083')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (189, N'PO Box 9976 Cotto Station', NULL, N'Arecibo', N'PR', N'00613', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5988882')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (190, N'Calle AA bloque AA #24 Alturas', NULL, N'Vega Baja', N'PR', N'00693', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5994951')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (191, N'PO Box 699', NULL, N'Trujillo Alto', N'PR', N'00977-0699', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.5994951')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (192, N'Calle AA #24 AA  Alturas de Vega Baja', NULL, N'Vega Baja', N'PR', N'00693', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6001280')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (193, N'Box 1400', NULL, N'Cidra', N'PR', N'00739-1400', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6009137')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (194, N'Torre Chardón #350 Ste. 1244', N'Ave. Chardón', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6009137')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (195, N'1324 Calle Canada', NULL, N'San Juan', N'PR', N'00920', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6015031')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (196, N'377 Ave. Domenech', NULL, N'San Juan', N'PR', N'00918-3721', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6021481')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (197, N'6161 Imperial Loop', NULL, N'College Station', N'TX', N'77845', 8, NULL, 0, NULL, N'2026-05-22 16:33:20.6021481')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (198, N'G&N General Contractors, Inc.', N'Alturas del Encanto N 21', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6028774')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (199, N'PO Box 363866', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6028774')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (200, N'3623 Avenida Militar PMB 331', NULL, N'Isabela', N'PR', N'00662', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6028774')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (201, N'Zona Franca Industrial', N'Victor Manuel Espaillat', N'Santiago', N'DO', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:20.6041693')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (202, N'PMB 635M 267', N'Calle Sierra Morena', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6049490')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (203, N'PO Box 29726', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6049490')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (204, N'661 University Blvd.', NULL, N'Jupiter', N'FL', N'00000', 8, NULL, 0, NULL, N'2026-05-22 16:33:20.6049490')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (205, N'Barrio Coto Norte', N'Carr. 2 Km 45.7', N'Manati', N'PR', N'00674', 7, NULL, 0, NULL, N'2026-05-22 16:33:20.6049490')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (206, N'PO Box 143801', N'PR', N'Arecibo', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4442109')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (207, N'Apartado Postal 8', NULL, N'Carolina', N'PR', N'00986-0008', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4442109')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (208, N'PO Box 2017, PMB 189', NULL, N'Las Piedras', N'PR', N'00771', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4448387')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (209, N'PO Box 9431', N'Cotto Station', N'Arecibo', N'PR', N'00613', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4451793')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (210, N'ATTN Servicios Administrativos del Estado', N'552 Borinqueneer TRL', N'Guaynabo', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4455992')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (211, N'Urb Sagrado Corazón', N'Ave. San Claudio #358', N'San Juan', N'PR', N'00926', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4462268')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (212, N'9002 San Marco Court', NULL, N'Orlando', N'FL', N'00000', 8, NULL, 0, NULL, N'2026-05-22 16:33:31.4462268')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (213, N'P.O. Box 9220', NULL, N'San Juan', N'PR', N'00908-9220', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4462268')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (214, N'PO Box 8808', NULL, N'Ponce', N'PR', N'00732', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4462268')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (215, N'PO Box 3982', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4462268')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (216, N'Calle C #A9', NULL, N'Carolina', N'PR', N'00987', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4479235')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (217, N'PO Box 8539', NULL, N'San Juan', N'PR', N'00910', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4479235')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (218, N'Hogar Benaina', N'Carmelo Ortiz', N'Trujillo Alto', N'PR', N'00977', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4479235')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (219, N'PO Box 9321', N'PR', N'Humacao', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4479235')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (220, N'2455 Paces Ferry Rd SE', N'Atlanta, GA 30339, US', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4492690')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (221, N'Honeywell Puerto Rico', N'400 Suite 100 Calle C', N'Guaynabo', N'PR', N'00968', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4492690')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (222, N'2213 Ponce By Pass', NULL, N'Ponce', N'PR', N'00717', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4492690')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (223, N'DIV. CUENTAS A PAGAR, DEPTO. FINANZAS', N'AVE. LAUREL STA. JUANITA', N'BAYAMON', N'PR', N'00956', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4499434')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (224, N'Goods & Services', N'P. O box 502751', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4499434')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (225, N'P.O. Box 4138', N'Road 686 Km. 17.3', N'Vega Baja', N'PR', N'00694-4138', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4499434')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (226, N'200 Coco Beach Blvd', NULL, N'Rio Grande', N'PR', N'00745', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4499434')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (227, N'301 Hwy 693', NULL, N'Dorado', N'PR', N'00646', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4499434')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (228, N'PMB 216', N'405 Esmeralda Ave.', N'Guaynabo', N'PR', N'00969', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4499434')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (229, N'IDAVIE Contractors, Inc.', N'HC-02 Box 6859', N'Ciales', N'PR', N'00638-9655', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4499434')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (230, N'St. Rd. 950 Km 3', N'Bo. Higuerillo', N'Naguabo', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4519529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (231, N'516 Calle Alfredo Carbonell', NULL, N'San Juan', N'PR', N'00918', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4519529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (232, N'Santa Rosa Mall, 1455, 402', N'Av. Aguas Buenas', N'Bayamón', N'PR', N'00959', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4519529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (233, N'Carr PR 744 K1.1', N'Bo Machete Parque Industrial#67', N'Guayama', N'PR', N'00784', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4519529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (234, N'PO Box 3204', N'PR', N'Mayaguez', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4519529')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (235, N'138 Winston Churchill Ave. PMB 153', NULL, N'San Juan', N'PR', N'00926-6013', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4539609')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (236, N'INDUPRO, S.E.', N'PO Box 363232', N'San Juan', N'PR', N'00936-3232', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4539609')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (237, N'Reparto Marquez E-9 Calle 5', NULL, N'Arecibo', N'PR', N'00612-3913', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4539609')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (238, N'PO BOX 51565', NULL, N'TOA BAJA', N'PR', N'00950', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4539609')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (239, N'Metropolis, 47 CII Isarael', NULL, N'Carolina', N'PR', N'00987', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4539609')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (240, N'HC645 PO Box 7185', NULL, N'Trujillo Alto', N'PR', N'00976', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4559745')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (241, N'Integrated Business Solutions PO Box 6857', N'PR', N'Caguas', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4559745')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (242, N'PO Box 195615', NULL, N'San Juan', N'PR', N'00919-5615', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4559745')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (243, N'P.O. Box 10908', N'Caparra Heights Sta.', N'San Juan', N'PR', N'00922', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4571071')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (244, N'Calle 15 J10 Fairview', N'PR', N'Trujillo Alto', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4577278')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (245, N'Santo Domingo, República Dominicana', NULL, N'Santo Domingo', N'DO', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:31.4581165')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (246, N'Ave. Ponce de Leon 1259', NULL, N'San Juan', N'PR', N'00907', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4581165')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (247, N'Accounts Payable Section', N'PO Box 1624', N'Canóvanas', N'PR', N'00729-1624', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4581165')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (248, N'PR 887 Interior B1,', N'Martin Gonzales Industrial Park', N'Carolina', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4594934')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (249, N'PO Box 1089', NULL, N'Florida', N'PR', N'00650', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4594934')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (250, N'Parque de torrimar calle 8 c-3', NULL, N'Bayamon', N'PR', N'00959', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4602127')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (251, N'Juan F. García, Inc.', N'PO Box 1549', N'Guaynabo', N'PR', N'00970-1549', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4605773')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (252, N'450 Ave. Esmeralda, Suite 3', NULL, N'Guaynabo', N'PR', N'00969-3463', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4605773')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (253, N'Po Box 2352', NULL, N'Vega Baja', N'PR', N'00694', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4615102')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (254, N'Suite 112 MSC 428', N'400 Gran Boulevard Paseo', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4615102')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (255, N'PO BOX 1908', N'PR', N'Carolina', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4622323')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (256, N'Las Violetas #3-C', NULL, N'Vega Alta', N'PR', N'00692', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4622323')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (257, N'Ritz Carlton Reserve-Villa 2100, 200', NULL, N'Dorado', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4622323')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (258, N'1405 Calle Rio Danubio', N'Sabana Abajo Ind. Park', N'Carolina', N'PR', N'00982-1705', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4635301')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (259, N'Jones Lang LaSalle Puerto Rico Inc', N'MailStop#42103-1618068', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4635301')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (260, N'Jones Lang LaSalle Puerto Rico Inc', N'Jones Lang LaSalle Puerto Rico Inc', N'Guaynabo', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4642563')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (261, N'MailStop: 47112-1618068', N'700 Oakmont Lane, 3rd Floor', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4642563')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (262, N'Jones Lang LaSalle Puerto Rico Inc', N'Mail Stop #49904-1618068', N'San Lorenzo', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4642563')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (263, N'Mailstop 49904- 1618068', N'27 Gonzalez Giusti St.', N'Suite 101 Guaynabo', N'PR', N'00968', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4655412')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (264, N'Mailstop# 47112-1618068', N'Mail Bin CSCF', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4660086')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (265, N'1519 Ave. Ponce de Leon Suite 1120', NULL, N'San Juan', N'PR', N'00909', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4660086')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (266, N'PO Box 444', N'Saint Just Station', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4660086')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (267, N'Metro Office Park 8 St 1 Suite 300', NULL, N'Guaynabo', N'PR', N'00968-1713', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4660086')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (268, N'PO Box 3669999', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4660086')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (269, N'4002 Raphune Hill Rd', N'Suite 401', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4675479')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (270, N'Post Office Box 1198', NULL, N'Carolina', N'PR', N'00986-1198', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4675479')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (271, N'PO Box 363408', NULL, N'San Juan', N'PR', N'00936-3408', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4675479')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (272, N'Calle César Iglesias #1', N'Punta Garza', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4675479')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (273, N'PO BOX 7066', NULL, N'Ponce', N'PR', N'00732', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4687128')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (274, N'1250 Avenida de la Constitución,', N'8th Floor', N'San Juan', N'PR', N'00907', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4687128')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (275, N'Mac Climber Rental', N'PO Box 1577', N'Guaynabo', N'PR', N'00970', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4695543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (276, N'PO Box 29228', NULL, N'San Juan', N'PR', N'00929', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4695543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (277, N'Maglez Engineering and Contractors Corp.', N'Box 1174', N'Florida', N'PR', N'00650', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4695543')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (278, N'# 1761 PR-8838', NULL, N'San Juan', N'PR', N'00926', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4711256')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (279, N'MARBELLA CLUB OF HOMEOWNERS ASSOCIATION', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4714935')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (280, N'Marriott Hotel', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4714935')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (281, N'7338 Estate Bakkeroe', N'St. Thomas, Virgin Islands 00802-3011', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:31.4714935')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (282, N'858 Zenway Boulevard', NULL, N'St. Kitts', N'KN', N'00000', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1103577')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (283, N'161 Calle San Jorge', NULL, N'San Juan', N'PR', N'00911', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1103577')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (284, N'8 Rosendo Vela Acosta Ave.', NULL, N'Carolina', N'PR', N'00987', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1103577')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (285, N'D. Cabo Caribe Industrial Park', N'Calle A Lote 23', N'Vega baja', N'PR', N'00693', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1115934')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (286, N'5460 W 84th St.', N'Indianapolis, IN 46268', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1119008')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (287, N'PO Box 3062', NULL, N'Aguadilla', N'PR', N'00605', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1119008')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (288, N'Kenvue Invoice Mailroom', N'700 Distribution Drive', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1119008')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (289, N'Medtronic Puerto Rico Operations Co.', N'PO Box 778', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1119008')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (290, N'PO Box 6857', NULL, N'Caguas', N'PR', N'00726-6857', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1119008')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (291, N'PO Box 11924', NULL, N'San Juan', N'PR', N'00922-1924', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1119008')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (292, N'PO Box 2013', NULL, N'Las Piedras', N'PR', N'00771', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1137719')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (293, N'PO Box 9976 Cotto Station', NULL, N'Arecibo', N'PR', N'00613', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1137719')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (294, N'Office 301-B', N'Metro Medical Center Bldg B', N'Bayamon', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1137719')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (295, N'Urb Dos Pinos', N'Calle Lince #820', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1137719')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (296, N'100 Airside Drive', N'Moon Twp.', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1137719')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (297, N'Care, Inc.', N'Calle Cosme Reparto | San Lucas, Entrada', N'Sector Canejas, San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1157915')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (298, N'654 Plaza Luis Muñoz Rivera Avenue', NULL, N'San Juan', N'PR', N'00918', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1157915')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (299, N'1121 Américo Miranda Ave.', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1157915')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (300, N'Estadio Roberto Clemente Walker Marginal', N'Trujillo Bajo', N'Carolina', N'PR', N'00985', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1157915')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (301, N'PO Box 191643', NULL, N'San Juan', N'PR', N'00919-1643', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1178105')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (302, N'PO Box 1806', N'Cidra', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1181245')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (303, N'Ave Boulevard #1559', NULL, N'Toa Baja', N'PR', N'00949', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1185706')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (304, N'1044 Pulinski Road', N'Ivyland, PA 18974', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1185706')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (305, N'501 Calle Norzagaray', NULL, N'San Juan', N'PR', N'00901', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1185706')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (306, N'9986 Manchester Road', NULL, N'Glendale', N'MO', N'63122', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1185706')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (307, N'12793 Cogburn Ave.', NULL, N'San Antonio', N'TX', N'78249', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1198307')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (308, N'5142 State Hwy FF', N'Fordland', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1198307')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (309, N'499 Avenida Munoz Rivera esq.', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1198307')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (310, N'352 Ave San Clauidio', N'PMB 172', N'San Juan', N'PR', N'00926', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1205042')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (311, N'NOVOTECH PUERTO RICO, INC.', N'PO Box 8230', N'San Juan', N'PR', N'00910-0230', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1205042')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (312, N'40001 SR 9336', N'Homestead FL 33034', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1205042')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (313, N'233 South Patterson Ave.', NULL, N'Springfield', N'MO', N'00000', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1205042')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (314, N'Zeno Gandia Industrial Park', N'Road 129, Km 41.0', N'Arecibo', N'PR', N'00612', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1205042')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (315, N'Calle George Sanders', NULL, N'Aguadilla', N'PR', N'00603', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1218508')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (316, N'Angora Industrial Park Bldg 3', N'km 33.3 Road 1 Avenue Bairoa Ward', N'Caguas', N'PR', N'00725', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1218508')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (317, N'Urb. Industrial Víctor Fernández', N'340 Calle 3 Suite 1', N'San Juan', N'PR', N'00926', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1218508')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (318, N'1710 Tablonal', N'Carr. 4441 Km. 0.6', N'Aguada', N'PR', N'00602', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1218508')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (319, N'PO Box 1724', NULL, N'Manatí', N'PR', N'00674', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1218508')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (320, N'Villa Caribe 279', N'Via Canada', N'Caguas', N'PR', N'00727', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1218508')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (321, N'PMB 705', N'89 De Diego Ave. Suite 105', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1218508')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (322, N'PO Box 363232', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1238705')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (323, N'PO box 195115', NULL, N'San Juan', N'PR', N'00919-5115', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1238705')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (324, N'PO Box 1120', N'PR', N'Mayaguez', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1238705')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (325, N'PO Box 16571', N'New Brunswick, NJ 08906-6571', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1238705')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (326, N'PO Box 9195', NULL, N'Caguas', N'PR', N'00726-9195', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1238705')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (327, N'PO Box 729', NULL, N'Fajardo', N'PR', N'00738', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1238705')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (328, N'c/o Thermo Fisher Scientific', N'PO Box 40017', N'College Station', N'TX', N'77842', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1258902')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (329, N'SUITE 102', NULL, N'San Juan', N'PR', N'00918', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1258902')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (330, N'Attn: Cuentas a Pagar Peerless', N'Oil and Chemicals, Inc. 671', N'Peñuelas', N'PR', N'00624', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1269256')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (331, N'15001 S. Figueroa St.', NULL, N'Gardena', N'CA', N'90248', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1272582')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (332, N'Pepsi-Cola Manufacturing Limited', N'PO Box 1558', N'Cidra', N'PR', N'00739-1558', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1272582')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (333, N'PF Consumer Healthcare B. V.', N'State Road No. 3, KM. 141.3', N'Guayama', N'PR', N'00784', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1272582')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (334, N'GFSS-Americas', N'PO Box 34600', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1294232')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (335, N'Inspecciones Misc.', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1294232')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (336, N'Calle Américo Capó 6811', NULL, N'Ponce', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1294232')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (337, N'PR', NULL, N'Santa Isabel', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1294232')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (338, N'PR', N'976', N'Trujillo Alto', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1314456')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (339, N'Queen''s Highway, PO Box F-42684', N'Freeport, Grand Bahama Island,', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1314456')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (340, N'2250 Boulevard Luis A. Ferré Suite 524', NULL, N'Ponce', N'PR', N'00717-0655', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1314456')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (341, N'812 South Crowley Road, Suite A', NULL, N'Crowley', N'TX', N'76036', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1328280')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (342, N'PR 00646-3306', NULL, N'Dorado', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1328280')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (343, N'PO Box 94995', N'Cleveland, OH 44101-4995', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1334654')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (344, N'PO BOX 158', N'PR 00986-0158', N'Carolina', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1334654')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (345, N'151 Calle de San Francisco', N'STE 200 PMB 1651', N'San Juan', N'PR', N'00901', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1344219')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (346, N'Ave. Abraham Lincoln Centro Comercial', N'Plaza Lincoln. Local #12', N'Santo Domingo', N'DO', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:41.1344219')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (347, N'AUSTIN, TX', NULL, N'AUSTIN', N'TX', N'00000', 8, NULL, 0, NULL, N'2026-05-22 16:33:41.1344219')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (348, N'PO Box 1288', N'00977-1288', N'Trujillo Alto', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1354855')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (349, N'PO Box 1288', NULL, N'Trujillo Alto', N'PR', N'00977-1288', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1354855')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (350, N'PO Box 98', NULL, N'Las Piedras', N'PR', N'00771-0098', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1364406')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (351, N'100 Road 165 Suite 601', NULL, N'Guaynabo', N'PR', N'00968', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1364406')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (352, N'Metro Medical Center', N'Carr. 2 Km 12.3 Hnas Davila', N'Bayamon', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1364406')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (353, N'Metro Medical Center Edificio B', N'Suite 303', N'Bayamón', N'PR', N'00959', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1375058')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (354, N'PO Box 11619', N'Caparra Heights Sta.', N'San Juan', N'PR', N'00922', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1375058')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (355, N'PO Box 851', NULL, N'Yauco', N'PR', N'00698', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1375058')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (356, N'BMS', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1375058')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (357, N'William Burgos', N'Urb Vista Mar C 33', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:41.1375058')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (358, N'PMB 1183', N'PO Box 4956', N'Caguas', N'PR', N'00726-4956', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1304003')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (359, N'PO Box 730', N'PR', N'Las Piedras', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1311747')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (360, N'33 Kennedy Avenue,', N'P O Box 1976,', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1317008')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (361, N'Edif Centro 4', NULL, N'TRUJILLO ALTO', N'PR', N'00977', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1320236')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (362, N'PO Box 427', NULL, N'Coamo', N'PR', N'00769', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1323371')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (363, N'PO Box 338', NULL, N'Mercedita', N'PR', N'00715', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1323371')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (364, N'PO Box 190406', NULL, N'San Juan', N'PR', N'00919', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1323371')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (365, N'PO Box 1338', NULL, N'Jayuya', N'PR', N'00664', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1323371')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (366, N'PO Box 2075', NULL, N'Aibonito', N'PR', N'00705', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1323371')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (367, N'605 Condado St. Ste. 322', NULL, N'San Juan', N'PR', N'00907', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1342507')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (368, N'Calle B Buzon 26', NULL, N'Ensenada', N'PR', N'00647', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1342507')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (369, N'Zona Franca', N'Dominican Republic', N'Santo Domingo', N'DO', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:49.1342507')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (370, N'3847 Crum Road', N'Youngstown, OH 44515', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1342507')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (371, N'Carr Royal Industrial Park #869', N'Bo. Palmas', N'Cataño', N'PR', N'00968', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1359582')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (372, N'P.O. Box 10069', NULL, N'Humacao', N'PR', N'00792', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1359582')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (373, N'PO BOX 4574', N'PR', N'Vega Baja', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1367643')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (374, N'405 Esmeralda Ave. PMB 418', NULL, N'Guaynabo', N'PR', N'00969', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1367643')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (375, N'1528 Woodward Suite 600', N'Detroit, MI 48226', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1379774')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (376, N'Att Acct. Payable', N'PO Box 332031', N'Ponce', N'PR', N'00733-6810', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1379774')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (377, N'PO Box 957', NULL, N'Manatí', N'PR', N'00674', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1379774')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (378, N'1215 San Dario Ave. Ste. 4-702', NULL, N'Laredo', N'TX', N'78040', 8, NULL, 0, NULL, N'2026-05-22 16:33:49.1379774')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (379, N'PO Box 193899', NULL, N'San Juan', N'PR', N'00919-3899', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1394438')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (380, N'Emilia Ab 11 Urb Villa Rica', NULL, N'Bayamón', N'PR', N'00959', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1397607')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (381, N'P. O. BOX 801072', N'COTO LAUREL, P.R. 00780', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1397607')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (382, N'PO Box 1904010', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1401281')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (383, N'SHARETECH GROUP ENGINEERING , PSC', N'PO BOX 1330', N'Caguas', N'PR', N'00726-1330', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1401281')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (384, N'Sheraton PR Convention Center', N'200 Convention Blvd', N'San Juan', N'PR', N'00907', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1401281')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (385, N'P.O. BOX 330627', NULL, N'Ponce', N'PR', N'00733-0627', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1401281')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (386, N'Sigfredo Carrero', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1401281')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (387, N'State Road 53, KM 82 Bo. Jobos Exit 83', NULL, N'Guayama', N'PR', N'00784', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1415830')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (388, N'PO Box 8780', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1420140')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (389, N'Akyna Pro Building Suite 301', NULL, N'San Juan', N'PR', N'00927', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1425468')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (390, N'PO Box 4956 PMB 1115', NULL, N'Caguas', N'PR', N'00726', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1425468')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (391, N'235 Federico Costa,', NULL, N'San Juan', N'PR', N'00918', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1425468')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (392, N'Sodexo c/o Pfizer', N'Attn. Edgard Quinones', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1425468')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (393, N'Sodexo c/o Pfizer', N'Carr. 3, Km. 142.1', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1440333')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (394, N'& Refrigeration, Inc.', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1445697')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (395, N'PO Box 998', N'PR', N'Caguas', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1445697')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (396, N'Metro Office Park Suite 305 Calle 1', NULL, N'Guaynabo', N'PR', N'00968-1705', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1445697')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (397, N'PO Box 851', N'PMB 274', N'Humacao', N'PR', N'00972-0851', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1445697')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (398, N'Bayamon, PR 00957', NULL, N'Bayamon', N'PR', N'00957', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1460521')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (399, N'Atn. Javier Rivera', N'PR', N'Salinas', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1460521')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (400, N'PO Box 4819', NULL, N'Carolina', N'PR', N'00984', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1460521')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (401, N'PO Box 1 4 9 3', NULL, N'T ruj i l lo A l to', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1460521')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (402, N'Cigar Division', NULL, N'Santiago', N'DO', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:49.1473669')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (403, N'Swidish Match Nevera', NULL, N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1480038')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (404, N'16888 State Route 706', N'Montrose, PA 18801', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1483956')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (405, N'305 Villamil St Apt 510', NULL, N'San Juan', N'PR', N'00907', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1492325')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (406, N'PO Box 3913Aguadilla, PR 00605', NULL, N'PO Box 3913Aguadilla', N'PR', N'00605', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1496628')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (407, N'Caribe Office Center 2004', N'Carr 506 Suite 203', N'Ponce', N'PR', N'00780', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1496628')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (408, N'PO Box 3826', NULL, N'Guaynabo', N'PR', N'00970', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1496628')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (409, N'PO Box 3308', N'Marina Station', N'Mayagüez', N'PR', N'00681-3308', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1496628')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (410, N'PO Box 193852', NULL, N'San Juan', N'PR', N'00919-3852', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1496628')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (411, N'Warner Chilcott Company, LLC', N'PO Box 1055', N'Manatí', N'PR', N'00674', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1496628')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (412, N'Calle Las Violetas', NULL, N'San Juan', N'PR', N'00915', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1518440')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (413, N'9591 Premier Parkway', NULL, N'Miramar', N'FL', N'33025', 8, NULL, 0, NULL, N'2026-05-22 16:33:49.1523631')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (414, N'PO Box 110', NULL, N'Carolina', N'PR', N'00986', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1523631')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (415, N'405 Ave. Esmeralda, Suite 2', NULL, N'Guaynabo', N'PR', N'00969-4457', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1523631')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (416, N'100 WALNUT AVE FL 4', N'CLARK, NJ 07066-1253', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1523631')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (417, N'Parque de las Ciencias 1550 Ave. Comerio', NULL, N'Bayamon', N'PR', N'00961', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1538651')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (418, N'PO Box 11197', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1538651')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (419, N'Apartado 21150', NULL, N'San Juan', N'PR', N'00928-1150', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1538651')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (420, N'PO Box 363255', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1538651')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (421, N'10 Casia Street', NULL, N'San Juan', N'PR', N'00921-3201', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1538651')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (422, N'Ave. Wiston Churchill #175', N'PR', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1538651')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (423, N'3130 Seminole Road', NULL, N'Fort Pierce', N'FL', N'00000', 8, NULL, 0, NULL, N'2026-05-22 16:33:49.1538651')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (424, N'KM 1.9 Road #689', NULL, N'Vega Baja', N'PR', N'00693', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (425, N'PMB 717 89 Ave De Diego Ste 105', NULL, N'San Juan', N'PR', N'00927', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (426, N'PMB 303', N'35 Juan C Borbon Ste 67', N'Guaynabo', N'PR', N'00969-5375', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (427, N'PO Box 5403', N'PR', N'Caguas', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (428, N'Carr #2 Km 135.3', NULL, N'Aguada', N'PR', N'00602', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (429, N'1 Premium Outlets Blvd.', NULL, N'Barceloneta', N'PR', N'00617', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (430, N'1000 Calle Los Ángeles Suite 100', NULL, N'San Juan', N'PR', N'00909', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (431, N'HC 03 Box 53995', NULL, N'Arecibo', N'PR', N'00612', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1558867')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (432, N'A/P Project No. 1110630', N'2000 Regency Parkway, St 300', N'San Juan', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1579073')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (433, N'Bo. Puente Carr. 119 Km. 4.8 Zona Industr', NULL, N'Camuy', N'PR', N'00627-1035', 7, NULL, 0, NULL, N'2026-05-22 16:33:49.1579073')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (434, N'República Dominicana', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7482410')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (435, N'Ave. John F. Keneddy No. 88', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7486604')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (436, N'República Dominicana', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7492586')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (437, N'de los Caballeros, Rep. Dominicana', NULL, N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7492586')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (438, N'República Dominicana', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7492586')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (439, N'00977-1288', NULL, N'Trujillo Alto', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:55.7502477')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (440, N'00977-1288', NULL, N'Trujillo Alto', N'PR', N'00000', 7, NULL, 0, NULL, N'2026-05-22 16:33:55.7506693')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (441, N'Av. Abraham Lincoln Esq. Av. 27 de Febrer', N'Plaza Comercial Lincoln, Local #12', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7506693')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (442, N'Infopisan.elec@gmail.com', NULL, N'Santiago de los Caballeros', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7506693')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (443, N'Compañia Dominicana de Teléfono, S.A.', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7506693')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (444, N'Santo Domingo, Rep.Dom.', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7522568')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (445, N'Rafael A. Acevedo Marte', N'rafaelacevedo_m@outlook.com', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7526855')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (446, N'Becton, Dickinson and Company', N'CareFusion D R 203 LTD, RNC: 101-77200-1', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7526855')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (447, N'Republica Dominicana', NULL, N'Punta Cana', N'La Altagracia', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7526855')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (448, N'MP Servicios, SRL', N'C/ Cerifo #18, Buenos Aires, Mirador Sur,', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7544254')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (449, N'Av. Romulo Betancourt, No. 1208,', N'Plaza Sahira 2Do Piso', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7544254')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (450, N'Robert Richard Rodriguez', N'Manzana 29, Local 27-B, Sto. Dgo.', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7544254')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (451, N'Frito Lay Dominicana, S.A.', N'Carr. Duarte, Km. 22 1/2, Zona Franca', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7544254')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (452, N'benitefire74@gmail.com', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7544254')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (453, N'Aut. Duarte Km. 22.5 Parque Ind. Duarte', N'Teléfono: (809) 330-8825', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7544254')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (454, N'Rafael Morillo C.', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7564442')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (455, N'anibalelfuelte1.7@hotmail.com', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7564442')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (456, N'Av. Tiradentes 21, Santo Domingo', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7564442')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (457, N'Mr. Emilio Villanueva', N'Fajardo Puerto Rico.', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7572121')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (458, N'Ave. Pedro A. Rivera Km. 3,', N'La Vega, Republica Dominicana', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7572121')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (459, N'Km.18½, Carretera Sanchez, Parque', N'Industrial ITABO Haina, San Cristobal', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7572121')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (460, N'C/ Santa Rosa # 646', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7572121')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (461, N'340 TRAYNOR DR', N'Kyle, TX 78640', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7572121')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (462, N'C/Lorenzo Despradel #12, Los Prados', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7584643')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (463, N'operaciones@rdpalmar.com', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7584643')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (464, N'Reservas del Palmar DR SRL', N'Diamond Mall, C/Euclides Morillo,', N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7584643')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (465, N'DGII', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7592231')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (466, N'Avenida Estrella Sadhalá esquina Luperón', N'República Dominicana', N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7592231')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (467, N'C/ Rosendo Alvarez #8A,, Ens. Claret,', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7592231')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (468, N'República Dominicana', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7592231')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (469, N'C/ Central Manzana A. Edificios 4,5 y 6.', NULL, N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7592231')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (470, N'Calle Mauricio Baez 262, Santo Domingo', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7604849')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (471, N'Santo Domingo, Rep. Dominicana', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7604849')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (472, N'C/ Jesus Alvarez Bogaert, 1ra Etapa', NULL, N'Santiago', N'Santiago', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7604849')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (473, N'San PedroDe Macorís, República Dominicana', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7618412')
INSERT [dbo].[addresses] ([address_id], [address_1], [address_2], [city], [state], [zip_code], [country_id], [google_place_id], [is_validated], [validated_at], [created_at]) VALUES (474, N'Ave. Las Americas, Km. 22, Lot B-1 & B-2', NULL, N'Santo Domingo', N'Distrito Nacional', N'00000', 6, NULL, 0, NULL, N'2026-05-22 16:33:55.7621621')

SET IDENTITY_INSERT [dbo].[addresses] OFF
GO


-- auth_tokens: No data to insert


-- curriculums: No data to insert


-- Data for employees (54 records)
SET IDENTITY_INSERT [dbo].[employees] ON
GO

INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (1, N'Admin', N'Guaynabo', N'Admin Guaynabo', NULL, NULL, NULL, N'Administration@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'8eeb508a-9f43-41ec-80dc-36a63c0aea48', N'Administration@primefire.us', '2026-01-13 20:41:44', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (2, N'Adolfo', N'Martinez', N'Adolfo Martinez', N'Manager Alarm Designer', N'Engineering Alarms', N'Home Office TX', N'amartinez@primefire.us', NULL, N'+1 4075584334', N'+1 4075584334', N'Dallas, TX', N'Dallas', N'Texas (TX)', N'75202', 1, N'1e7152f1-aaf5-4789-9da4-e74d9b586843', N'amartinez@primefire.us', '2026-06-25 21:08:12', N'1 322 125 523', NULL, N'Willian Bencosme', N'wbencosme@primefire.do', 43)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (3, N'Jose Alberto', N'Rodriguez', N'Jose Alberto Rodriguez', N'President & CEO', N'President', N'Trujillo Alto, Puerto Rico', N'arodriguez@primefire.us', NULL, N'+1 7872212121', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'b826abb3-30c8-4369-8d87-ce0d648e7fba', N'arodriguez@primefire.us', '2026-04-28 18:53:26', N' 1 222 853 870', NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (4, N'Baxter', N'Jayuya', N'Baxter Jayuya', N'Engineering Alarm', N'Engineering Alarm Designer', N'Guaynabo, Puerto Rico', N'bjayuya@primefire.us', NULL, NULL, N'+1 7877613180', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'b9de2f69-4aba-42f3-87eb-da0e1dcf2cfa', N'bjayuya@primefire.us', '2025-11-06 18:16:00', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (5, N'Christopher', N'Carballo Rosado', N'Christopher Carballo Rosado', N'Fire Alarm Manager', N'Alarm Project Manager', N'Guaynabo, Puerto Rico', N'ccarballo@primefire.us', NULL, N'+1 7872017346', N'+1 7876303000', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'd63e397b-31e7-424e-a2c3-993562347b04', N'ccarballo@primefire.us', '2026-04-05 09:28:44', N'1 816 473 615', NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (6, N'Cesar', N'Figueroa Cruzado', N'Cesar Figueroa Cruzado', N'Group Leader', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'cfigueroa@primefire.us', NULL, N'+1 9398919203 ', N'+1 7876303000 ', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', NULL, N'b5ff98b3-be60-4693-aa6e-2553b941faff', N'cfigueroa@primefire.us', '2026-06-25 20:59:39', N'1347236989', NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (7, N'Jose Daniel', N'Agosto Rivera', N'Jose Daniel Agosto Rivera', N'Engineering', N'Pipe Filter', NULL, N'dagosto@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'a5c57db5-230b-41c2-a0e7-0747f4512d2d', N'dagosto@primefire.us', '2026-07-21 15:23:32', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (8, N'Alessa', N'Payano', N'Dominicana', NULL, NULL, NULL, N'dominicana@primefire.do', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'405c6850-50aa-490a-91f0-b666e016f12e', N'dominicana@primefire.do', '2026-07-21 15:23:33', N'952 993 371', NULL, N'Enmanuel Desueza', N'edesueza@primefire.do', 10)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (9, N'Edwin', N'De Jesus', N'Edwin De Jesus', N'Field Tech II', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'edejesus@primefire.us', NULL, N'+1 7876433660', N'+1 7877613180', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'1efe087c-1bd7-4e77-9ec3-5577519a9871', N'edejesus@primefire.us', '2025-11-06 18:16:01', NULL, NULL, N'Edwin De Jesus', N'edejesus@primefire.us', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (10, N'Emmanuel', N'Desueza', N'Enmanuel Desueza', N'Project Coordinator', N'Field Technician, Office Assistant ', N'Santo Domingo, República Dominicana', N'edesueza@primefire.do', NULL, N'+1 8095011901', N'+1 8095011900', N'Abraham Lincoln Ave, Lincoln Plaza Suite 12', N'Santo Domingo', N'Distrito Nacional (D.N.)', N'10124', 3, N'b0241d3b-03a7-45bf-a2fa-f06a76b9317d', N'edesueza@primefire.do', '2026-06-04 18:19:12', N'608 476 118', NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (11, N'Edwin', N'Guilloty', N'Edwin Guilloty', N'Project Manager', N'Operations', N'Guaynabo, Puerto Rico', N'eguilloty@primefire.us', NULL, N'+1 7876433660', N'+1 7876303000 ', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'76025b90-b5a8-4ba7-809b-0da6685492f8', N'eguilloty@primefire.us', '2026-06-04 18:18:22', N'211 843 138', NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (12, N'Elizaud', N'Hernandez', N'Elizaud Hernandez', N'Administration Manager', N'Administration', N'Trujillo Alto, Puerto Rico', N'ehernandez@primefire.us', NULL, N'+1 3867483621', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'ad15e516-906b-4e3f-8e4c-373134505755', N'ehernandez@primefire.us', '2025-11-06 18:16:03', NULL, NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (13, N'Emilio', N'Melendez', N'Emilio Melendez', N'Field Tech', N'Logistics / Operations', N'Prime Fire DO', N'emelendez@primefire.do', NULL, NULL, NULL, N'Av. Abraham Lincoln', N'Santo Domingo', N'Republica Dominiaca', N'10109', 3, N'4c12442f-758b-4921-8188-b0167d3e6281', N'emelendez@primefire.do', '2025-11-06 18:16:03', NULL, NULL, N'Enmanuel Desueza', N'edesueza@primefire.do', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (14, N'Elionetzy', N'Santiago Adames', N'Elionetzy Santiago Adames', N'Field Tech II', N'Suppression, Special  Hazards & ITM', N'Trujillo Alto', N'esadames@primefire.us', NULL, N'+1 7874729866', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'2b892a33-b52b-4f24-9af1-941c3eceb183', N'esadames@primefire.us', '2025-11-06 18:16:04', N'1871416500', NULL, N'Edwin Guilloty', N'eguilloty@primefire.us', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (15, N'Gustavo', N'Heredia', N'Gustavo Heredia', N'Designer ', NULL, NULL, N'gheredia@primefire.do', NULL, N'+1 8492854334', NULL, N'Abraham Lincoln Ave, Lincoln Plaza Suite 12', N'Santo Domingo', N'Distrito Nacional (D.N.)', N'10124', 3, N'44d8c9a2-c02f-41c7-85e0-50c9f92ec327', N'gheredia@primefire.do', '2026-06-04 18:42:26', N'518 428 131', NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (16, N'Geurys Jabbart', N'Medrano Montero', N'Geurys Medrano', N'Global Inventory Manager', N'Engineering Alarm & Sprinkler', N'Santo Domingo, República Dominicana', N'gmedrano@primefire.do', NULL, N'+1 8295594355', N'+1 8095011901', N'Abraham Lincoln Ave, Lincoln Plaza Suite 12', N'Santo Domingo', N'Distrito Nacional (D.N.)', N'10124', 3, N'6dc58092-0b27-431c-a2b6-353e2fcf4c49', N'gmedrano@primefire.do', '2026-06-04 18:25:15', N'1 827 324 420', NULL, N'Enmanuel Desueza', N'edesueza@primefire.do', 10)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (17, N'Gustavo', N'Vazquez', N'Gustavo Vazquez', N'Field Tech II', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'gvazquez@primefire.us', NULL, N'1 (787) 312-7679', N'+1 7876303000 ', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR', N'00969', 2, N'07e0c48e-bc49-4f58-9e3b-c391b4fe12c2', N'gvazquez@primefire.us', '2026-06-30 18:45:48', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (18, N'Giovanni', N'Velez', N'Giovanni Velez', N'Fire Alarm Manager', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'gvelez@primefire.us', NULL, N'+1 7873700568', N'+1 7876303000', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'8b6db431-ee49-46c2-be9a-2e89a493130a', N'gvelez@primefire.us', '2026-06-04 18:27:49', N'856 101 982', NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (19, NULL, NULL, N'Info', NULL, NULL, NULL, N'info@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'53172d9b-ad7e-49e4-81ce-25c1c7656a3e', N'info@primefire.us', '2026-07-21 15:23:34', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (20, N'Israel', N'Nieves', N'Israel Nieves', N'Field Tech II', N'Suppression, Special  Hazards & ITM', N'Trujillo Alto, Puerto Rico', N'inieves@primefire.us', NULL, N'+1 7872047807', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'396751cd-b9ac-40e9-8122-dffb9341f319', N'inieves@primefire.us', '2025-11-06 18:16:06', NULL, NULL, N'Edwin Guilloty', N'eguilloty@primefire.us', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (21, N'Jonathan', N'Romo', N'Jonathan Romo', N'Admin Systems', N'IT', N'Home Office, Mexico', N'it@primefire.us', NULL, N'+528125356287', N'+528125356287', N'Arturo B de la Garza #4613', N'Monterrey', NULL, NULL, 4, N'8c882f2c-19f8-4f17-a1e8-d5644456ea65', N'it@primefire.us', '2026-06-25 21:06:57', NULL, NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (22, N'Juan', N'Aybar', N'Juan Lehtenin', N'Fire Alarm Division', N'PrimeFire DO', N'República Dominica', N'jaybar@primefire.do', NULL, NULL, N'+1 8095011901', N'Av. Abraham Lincoln', N'Santo Domingo', N'Republica Dominicana', N'10109', 3, N'2a9640a5-897f-49c0-94f7-15a6f4d642c9', N'jaybar@primefire.do', '2025-11-06 18:16:07', NULL, NULL, N'Santiago Rodriguez', N'srodriguez@primefire.do', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (23, N'Joskayra', N'de Jesus Medina', N'Joskayra de Jesus Medina', N'Engineering Alarm Designer & Accountant', N'Engineering Alarm Designer', N'Santo Domingo, República Dominicana', N'jdejesus@primefire.do', NULL, N'+1 809-499-5821', N'+1 8095011900', N'Abraham Lincoln Ave, Lincoln Plaza Suite 12', N'Santo Domingo', N'Distrito Nacional (D.N.)', N'10124', 3, N'df97493e-56d4-45fb-8a18-25a60dead4b5', N'jdejesus@primefire.do', '2026-06-30 18:44:25', N'1 907 746 978', NULL, N'Willian Bencosme', N'wbencosme@primefire.do', 43)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (24, N'Javier', N'Lopez Rivera', N'Javier Lopez Rivera', N'Field tech II', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'jlopez@primefire.us', NULL, N'+1 9393399185', N'+1 7876303000 ', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'e809702b-2fb2-45d3-b486-04f66b89d725', N'jlopez@primefire.us', '2025-11-06 18:16:08', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (25, N'Jose', N'Martínez', N'Jose Martínez', N'Field Tech II', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'jmartinez@primefire.us', NULL, N'+1 787-948-3352', N'+1 7876303000', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'1eb06cab-eeae-425b-bd0e-562d6eb89735', N'jmartinez@primefire.us', '2026-07-03 20:10:13', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (26, N'Jose', N'Morales', N'Jose Morales', N'Group Leader', N'Sprinklers Division', N'Trujillo Alto, Puerto Rico', N'jmorales@primefire.us', NULL, N'+1 7876295196', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'd96be71d-b61f-40e5-b973-94843acf7c47', N'jmorales@primefire.us', '2025-11-06 18:16:09', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (27, N'Juan', N'Villa', N'Juan Villa', N'Systems', N'IT4', N'Home Office, Mexico', N'jvilla@primefire.us', N'1231231232', N'+522282553842', N'+522282553842', N'Heroes 47 400', N'Trujillo Alto', N'Nuevo Leon', N'64000', 2, N'0523631c-d286-4be5-9aaf-e33ac83b587c', N'jvilla@primefire.us', '2026-07-08 03:22:45', N'1231231232', NULL, N'Jonathan Romo', N'it@primefire.us', 21)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (28, N'Kevin', N'Morales', N'Kevin Morales', N'Administrative Assistant', N'HR Analyst', N'Trujillo Alto, Puerto Rico', N'kmorales@primefire.us', NULL, N'+1 7876295196', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'2b7ae779-a20d-47d9-9680-ccf54568ae41', N'kmorales@primefire.us', '2026-06-04 18:33:13', N'1 089 712 788', NULL, N'Sigfredo Carrero', N'scarrero@primefire.us', 39)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (29, N'Kristian', N'Torres', N'Kristian Torres', N'Field Tech', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'ktorres@primefire.us', NULL, N'+1 4077059670', N'+1 7876303000 ', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR', N'00969', 2, N'b02a129b-cb1f-4d22-ab12-acbbeb5291e2', N'ktorres@primefire.us', '2026-06-25 21:00:11', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (30, N'Luis', N'Burset', N'Luis Burset', N'Fire Sprinklers Designer', N'Designer', N'Home Office TX', N'lburset@primefire.us', NULL, N'+1 7874855008', N' +1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR', N'00976', 2, N'88b8d661-148d-4476-881c-d42f4d3ef96e', N'lburset@primefire.us', '2026-06-25 20:25:20', N'1 544 266 275', NULL, N'Willian Bencosme', N'wbencosme@primefire.do', 43)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (31, N'Luis', N'De Jesus', N'Luis De Jesus', N'Field tech II', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'ldejesus@primefire.us', NULL, N'+1 7873909755', N'+1 7876303000', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'8d91aafe-6b6d-4994-84d4-5108e4e7b0ca', N'ldejesus@primefire.us', '2025-11-06 18:16:11', NULL, NULL, N'Geurys Medrano', N'gmedrano@primefire.do', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (32, N'Luis', N'Nieves', N'Luis Nieves', N'Fire Protection Designer', N'Protection Designer', N'Trujillo Alto, Puerto Rico', N'lnieves@primefire.us', NULL, N'+1 7873641643', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'8f082fd0-cad1-4579-8305-08b31f95befd', N'lnieves@primefire.us', '2026-06-30 18:45:26', N'627 287 963', NULL, N'Willian Bencosme', N'wbencosme@primefire.do', 43)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (33, N'Max', N'Oliveras', N'Max Oliveras', N'Project Manager', N'Field Engineering', N'Trujillo Alto', N'moliveras@primefire.us', NULL, N'+ 787 607 7402', N'+1 7876303000', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'41b65f97-f746-46c2-b03a-9f0dffaefb19', N'moliveras@primefire.us', '2026-06-04 18:41:46', N'1 637 055421', NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (34, N'Marcos', N'Quiles', N'Marcos Quiles', N'Fire Protection Designer', N'Protection Designer', N'Trujillo Alto, Puerto Rico', N'mquiles@primefire.us', NULL, N'+1 7875257965', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'0f46165b-1617-4d70-82f4-f4768b01f90c', N'mquiles@primefire.us', '2026-06-30 18:44:42', N'1 755 106 283', NULL, N'Willian Bencosme', N'wbencosme@primefire.do', 43)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (35, N'Nathan', N'Gonzalez', N'Nathan Gonzalez', N'Engineering Alarm Designers', N'Engineering Alarm', N'Trujillo Alto, Puerto Rico', N'ngonzalez@primefire.us', NULL, N'+1 7879819444', N'+1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'c9d2250f-2b79-403f-9c13-fe11212f4ebb', N'ngonzalez@primefire.us', '2026-07-03 18:11:20', N'1 665 244 248', NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (36, NULL, NULL, N'Printer Guaynabo', NULL, NULL, NULL, N'Printer-Guaynabo@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'5719f4d2-8092-48f8-a53a-d6f0e28bf8ea', N'Printer-Guaynabo@primefire.us', '2026-07-21 15:23:35', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (37, N'Rayneé', N'Fúnez Heredia', N'Rayneé Fúnez Heredia', N'Account Manager', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'rfunez@primefire.us', NULL, N'+1 9392350216', N'+1 7876303000 ', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'ab01cd10-bff4-4620-b55e-0d0f1ab1d151', N'rfunez@primefire.us', '2025-11-06 18:16:13', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (38, N'Rolando', N'Rivera', N'Rolando Rivera', N'Alarm Designer', NULL, N'Guaynabo, Puerto Rico', N'rrivera@primefire.us', NULL, N'+1 7872377217', N'+1 7876303000', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR (Puerto Rico)', N'00969', 2, N'706337f9-ef71-47cb-982f-2ca206383da3', N'rrivera@primefire.us', '2026-07-06 12:18:09', NULL, NULL, N'Giovanni Velez', N'gvelez@primefire.us', 18)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (39, N'Sigfredo', N'Carrero', N'Sigfredo Carrero', N'General Manager / Sprinkler Division', N'SubDirection', N'Trujillo Alto, Puerto Rico', N'scarrero@primefire.us', NULL, N'+1 7876475955', N' +1 7877613180', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'b7d6932d-8c4c-411f-ab87-1547f9c07391', N'scarrero@primefire.us', '2026-06-04 18:41:06', N'421 327 579', NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (40, NULL, NULL, N'service', NULL, NULL, NULL, N'service@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'f1228614-b6eb-4c3e-bbae-869139b6736e', N'service@primefire.us', '2026-07-21 15:23:36', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (41, N'Stephanie', N'Martinez', N'Stephanie Martinez', N'HR Analyst', N'Hiuman Resource', N'Trujillo Alto, Puerto Rico', N'smartinez@primefire.us', NULL, N'+1 8292485211', N'+1 8095011901', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'9cfcf921-1266-468c-a7de-0ee20fd472cb', N'smartinez@primefire.us', '2025-11-06 18:16:15', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (42, N'Santiago', N'Rodriguez', N'Santiago Rodriguez', N'Operation Manager', N'Field Engineering ', N'Santo Domingo, República Dominicana', N'srodriguez@primefire.do', NULL, N'+1 7876077402', N'+1 7877613180', N'Abraham Lincoln Ave, Lincoln Plaza Suite 12', N'Santo Domingo', N'Distrito Nacional (D.N.)', N'10124', 3, N'635af9c2-ca37-4e5a-bfdd-989e0f7d14a9', N'srodriguez@primefire.do', '2026-06-25 20:02:47', N'960 318 174', NULL, N'Enmanuel Desueza', N'edesueza@primefire.do', 10)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (43, N'Willian', N'Bencosme', N'Willian Bencosme', N'Engineering Alarm & FireSpronkler', N'Engineering Alarm Designer', N'Santo Domingo, República Dominicana', N'wbencosme@primefire.do', NULL, N'+1 8297653844', N'+1 8095011901', N'Abraham Lincoln Ave, Lincoln Plaza Suite 12', N'Santo Domingo', N'Distrito Nacional (D.N.)', N'10124', 3, N'6987d8c8-0423-43bb-be3e-6601476147ab', N'wbencosme@primefire.do', '2026-06-25 21:06:12', N'1 495 665 089', NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (44, N'Wilnelia', N'Santos', N'Wilnelia Santos', N'HR Analyst', N'Hiuman Resource', N'Republica Dominicana', N'wsantos@primefire.us', NULL, N'+1 7877613180', N'+1 8608413625', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'be4788a5-f480-442d-ab40-209e317e54ac', N'wsantos@primefire.us', '2025-12-22 18:25:48', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (45, N'Luis', N'Belliard', N'Luis Belliard', N'Fire Sprinklers Designer', N'Engineering Alarm & Sprinkler', N'Santo Domingo, República Dominicana', N'lbelliard@primefire.do', NULL, N'+1 8292222869', N'+1 8095011901', N'Abraham Lincoln Ave, Lincoln Plaza Suite 12', N'Santo Domingo', N'Distrito Nacional (D.N.)', N'10124', 3, N'6e029e87-b520-4def-8aed-9484162bee13', N'lbelliard@primefire.do', '2026-06-25 20:25:43', NULL, NULL, N'Willian Bencosme', N'wbencosme@primefire.do', 43)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (46, N'Kevin', N'Lopez', N'Kevin Lopez', NULL, NULL, NULL, N'klopez@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'ac51c4f9-269a-44a8-99b9-aae4220a7e4e', N'klopez@primefire.us', '2026-07-21 15:23:34', NULL, NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (48, N'Luis D', N'Lugo', N'Luis D Lugo', N'Field tech II', N'Fire Alarm Division', N'Guaynabo, Puerto Rico', N'llugo@primefire.us', NULL, N'+1 7879514104', N'+1 7876306000', N'PR1 Km 22.3 Bo, Rio Solar Los Santa', N'Guaynabo', N'PR', N'00969', 2, N'542a5a99-aa6a-4ce9-8435-e42f587444b6', N'llugo@primefire.us', '2026-02-26 02:49:09', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (49, N'Rosa M', N'Rivera', N'Rosa M Rivera', N'Project Manager - AI Strategic Efficiency', N'Administration', N'Guaynabo', N'rmrivera@primefire.us', NULL, N'(787)975-9127', N'787-630-6000', N'Highway 8860 KM 1.2', N'Trujillo Alto', N'PR (Puerto Rico)', N'00976', 2, N'aa1aafd1-f175-4595-9dc1-d018b8069d66', N'rmrivera@primefire.us', '2026-07-03 17:29:47', NULL, NULL, N'Jose Alberto Rodriguez', N'arodriguez@primefire.us', 3)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (50, N'Katerin Ignaeliz', N'Mejias Bastida', N'Katerin Mejias', NULL, NULL, NULL, N'Kmejias@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'e8bf8435-b28e-43a0-9e1f-04bb1002ce2c', N'Kmejias@primefire.us', '2026-06-20 17:04:55', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (51, NULL, NULL, N'PrimeFire NFPA', NULL, NULL, NULL, N'nfpa@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'cef4013e-aa2d-46ee-9012-6c51d21066c4', N'nfpa@primefire.us', '2026-07-21 15:23:35', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (52, N'Lorenzo', N'Luciano', N'Lorenzo Luciano', NULL, NULL, NULL, N'Lluciano@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'fed86526-ffb7-49cc-b78c-b11f7f5ee689', N'Lluciano@primefire.us', '2026-07-21 15:23:35', NULL, NULL, N'Edwin Guilloty', N'eguilloty@primefire.us', 11)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (53, N'Sofía', N'Rodríguez', N'Sofía Rodríguez', NULL, NULL, NULL, N'srodriguez@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'644e42a9-44f2-426f-924b-b277f28fb87e', N'srodriguez@primefire.us', '2026-05-28 22:32:02', NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (54, N'Mario', N'Ordaz', N'Mario Ordaz', N'FullStack Developer & M365 Junior', N'IT', N'Home Office, Mexico', N'mordaz@primefire.us', NULL, N'+52 81 8463 6533', N'+52 81 8463 6533', N'Av Real del Valle 139', N'Santa Catarina', N'Nuevo León', N'NA', 4, N'9bcf27c1-ec02-4c4c-a9d0-bfd2109955fb', N'mordaz@primefire.us', '2026-06-05 02:26:51', N'1 905 244 252', NULL, NULL, NULL, NULL)
INSERT [dbo].[employees] ([employee_id], [first_name], [last_name], [display_name], [title], [department], [office], [email], [phone], [mobile_phone], [office_phone], [street_address], [city], [state], [postal_code], [country_id], [azure_oid], [azure_upn], [last_synced_at], [anydesk], [password_hash], [manager], [manager_email], [manager_employee_id]) VALUES (55, N'Sofia Beatriz', N'Rodriguez', N'Sofía Rodriguez', NULL, NULL, NULL, N'sbrodriguez@primefire.us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'388bca9f-e6bf-4704-93e7-7bc95f44d5c6', N'sbrodriguez@primefire.us', '2026-06-20 17:04:56', NULL, NULL, NULL, NULL, NULL)

SET IDENTITY_INSERT [dbo].[employees] OFF
GO


-- Data for customers (587 records)
SET IDENTITY_INSERT [dbo].[customers] ON
GO

INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (1, N'residential', NULL, N'Customer', N'Demo', N'Customer Demo', NULL, NULL, N'Rel@villanueva.com', N'+1 214 2345 21 34', 1, N'2026-02-19 16:30:33.0000000', NULL, 21)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (2, N'commercial', N'GEMPRO- General Electromechanical Project', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 2, N'2026-05-22 16:32:44.9165827', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (3, N'commercial', N'TALBOT LIMITED', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 3, N'2026-05-22 16:32:44.9269128', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (4, N'commercial', N'Conecta Mer SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 4, N'2026-05-22 16:32:44.9281446', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (5, N'commercial', N'Hotel JW Marriott', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 5, N'2026-05-22 16:32:44.9285114', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (6, N'commercial', N'AMINA', N'José Guillermo', N'Isa Núñez', NULL, N'commercial', NULL, N'j.isa@amina.com.do', N'(809) 508-6124', 6, N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (7, N'commercial', N'Grupo de Inversiones Lunar S.R.L', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 7, N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (8, N'commercial', N'Eastern Developers Investment S.A.S', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 8, N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (9, N'commercial', N'Certified Fire Protection Certifire SRL', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, 9, N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (10, N'commercial', N'Wyndham Garden by Super 8', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 10, N'2026-05-22 16:32:44.9301539', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (11, N'commercial', N'Quantum CCS', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 11, N'2026-05-22 16:32:44.9305318', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (12, N'commercial', N'LITHIUM OPTIMIZACION DE PROCESOS INDUSTR', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 12, N'2026-05-22 16:32:44.9305318', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (13, N'commercial', N'Corporación Aeroportuaria Del Este S.A.S', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 13, N'2026-05-22 16:32:44.9309480', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (14, N'commercial', N'AC Hotel Santiago', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 14, N'2026-05-22 16:32:44.9309480', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (15, N'commercial', N'Super Mercado Bravo Winston Churchill', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 15, N'2026-05-22 16:32:44.9309480', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (16, N'commercial', N'SAHDALA JORGE INGENIERIA S.R.L', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, 16, N'2026-05-22 16:32:44.9321656', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (17, N'commercial', N'Piarcon SRL', N'Arnaldo', N'Lantigua', NULL, N'commercial', NULL, N'alantigua@piarcon.com', NULL, 17, N'2026-05-22 16:32:44.9325562', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (18, N'commercial', N'Atlambar Management S.A.S', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 18, N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (19, N'commercial', N'INGYOSA Ingeneira EIRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 19, N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (20, N'commercial', N'Celso Cabrera & Asociados SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 20, N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (21, N'commercial', N'METALDOM SA', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 21, N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (22, N'commercial', N'Ingeniería Domingo Montás SRL', N'Julio', N'Montás', NULL, N'engineering', NULL, NULL, N'+1 (809) 943-8263', 22, N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (23, N'commercial', N'G2EL SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 23, N'2026-05-22 16:32:44.9341750', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (24, N'commercial', N'Contratistas Civiles y Mecánicos', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, 24, N'2026-05-22 16:32:44.9345752', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (25, N'commercial', N'Sheraton Santo Domingo Hotel', N'Cesar', N'Corporal', NULL, N'commercial', NULL, N'ccorporal@sheratonsantodomingo.com', N'+1 (809) 796-2922', 25, N'2026-05-22 16:32:44.9345752', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (26, N'commercial', N'Hotel Discovery', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 26, N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (27, N'commercial', N'Ingemati SRL', N'Mario', N'Marcano', NULL, N'commercial', NULL, N'mario@ingemati.com', NULL, 27, N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (28, N'commercial', N'Vemp Design Solutions', N'Eduardo', N'Rivas', NULL, N'engineering', NULL, N'Eduardorivas@vempds.com', N'Eduardo Rivas', 28, N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (29, N'commercial', N'MercaSID', NULL, NULL, NULL, N'commercial', NULL, N'Aridio.Abreu@induveca.com', NULL, 29, N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (30, N'commercial', N'Laesa LTD', N'Guillermo', N'Garcia', NULL, N'commercial', NULL, N'Guillermo.garcia@laesard.com', N'809-584-5925', 30, N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (31, N'commercial', N'Big Brothers Company', N'Carlos', N'Nieto', NULL, N'commercial', NULL, N'ventas@bigbrotherscompany.com', N'829-548-1759', 31, N'2026-05-22 16:32:44.9361856', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (32, N'commercial', N'RK Power', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 32, N'2026-05-22 16:32:44.9365933', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (33, N'commercial', N'Contratistas Eléctricos de Santiago SRL', N'Yorbin', N'Gonzalez', NULL, N'engineering', NULL, NULL, N'82-581-4344', 33, N'2026-05-22 16:32:44.9370069', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (34, N'commercial', N'Grupo Punta Cana', NULL, NULL, NULL, N'commercial', NULL, N'ojavier@puntacana.com', NULL, 34, N'2026-05-22 16:32:44.9370069', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (35, N'commercial', N'ALARM CONTROLS SEGURIDAD SAS', NULL, NULL, NULL, N'commercial', NULL, N'mcalderon@warecomm.net', NULL, 35, N'2026-05-22 16:32:44.9370069', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (36, N'commercial', N'Swedish Match Dominicana, S.A', N'Karen', N'Tejada', NULL, N'commercial', NULL, N'karen.tejada@swedishmatch.com', N'809-575-4300 ext. 29', 36, N'2026-05-22 16:32:44.9381949', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (37, N'commercial', N'Design & Build by Javier Rafel SRL', NULL, NULL, NULL, N'engineering', NULL, N'Kinfante@dybjr.com', N'849-889-3689', 37, N'2026-05-22 16:32:44.9386117', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (38, N'commercial', N'MeraFondeur Ingenieria y Proyectos', N'Junior', N'Rosario', NULL, N'engineering', NULL, NULL, NULL, 38, N'2026-05-22 16:32:44.9394684', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (39, N'commercial', N'Panaderia Pasteleria Lumijor SRL', N'Luis', N'Alvarez', NULL, N'commercial', NULL, NULL, NULL, 39, N'2026-05-22 16:32:44.9400747', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (40, N'commercial', N'InciFire SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 40, N'2026-05-22 16:32:44.9409633', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (41, N'commercial', N'Casa de Campo Resort & Villas', N'Emmanuel', N'Jorge', NULL, N'commercial', NULL, N'asistmant@ccampo.com.do', N'(809) 723-3048', 41, N'2026-05-22 16:32:44.9409633', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (42, N'commercial', N'Sems', NULL, NULL, NULL, N'commercial', NULL, N'info@semsrd.com', NULL, 42, N'2026-05-22 16:32:44.9419662', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (43, N'commercial', N'Adjustment 12-31-16', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7099498', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (44, N'commercial', N'Advance Marine Solutions', NULL, NULL, NULL, N'commercial', NULL, N'bdiaz@primefire.us', NULL, NULL, N'2026-05-22 16:32:54.7099498', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (45, N'commercial', N'Ajuste CPA', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (46, N'residential', NULL, N'Amec', N'Foster Wheeler', NULL, N'individual', NULL, N'felix.cardona@amecfw.com', NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (47, N'commercial', N'Antonio Roig Sucesores INC', NULL, NULL, NULL, N'commercial', NULL, N'wanelro.ar@gmail.com', NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (48, N'commercial', N'Apex Mechanical CORP', NULL, NULL, NULL, N'commercial', NULL, N'atoro@apexmechanicalcorp.com', NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (49, N'commercial', N'ASI Mechanical LLC', NULL, NULL, NULL, N'commercial', NULL, N'eacruz@aireko-services.com', NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (50, N'commercial', N'Asociación de Garantías de Seguros Misc', NULL, NULL, NULL, N'commercial', NULL, N'administracion@agsmpr.org', NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (51, N'commercial', N'AUDIT', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (52, N'commercial', N'Audit 2018', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (53, N'commercial', N'Audit2023', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7119574', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (54, N'residential', NULL, N'B', N'Boutique', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7119574', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (55, N'residential', NULL, N'Babilonia', N'Engineering Group', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (56, N'commercial', N'Bayamón Endodontics', NULL, NULL, NULL, N'commercial', NULL, N'bayamonendodontics@gmail.com', NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (57, N'commercial', N'Bermary Velázquez', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (58, N'commercial', N'BMS12-16', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (59, N'commercial', N'Building Improvement 2015', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (60, N'commercial', N'Building Improvement 2016', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (61, N'commercial', N'Casa BACARDÍ Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'glarroyoa@bacardi.com', NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (62, N'commercial', N'CCS LLC', NULL, NULL, NULL, N'commercial', NULL, N'juan.rivera@ccsllcpr.com', NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (63, N'commercial', N'CDT Metropolitano Carolina', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (64, N'commercial', N'CEL Fire', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (65, N'residential', NULL, N'CONDOMINIO', N'BLUE', NULL, N'individual', NULL, N'gvelez@primefire.us', NULL, NULL, N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (66, N'commercial', N'Condominio Bosque del Río', NULL, NULL, NULL, N'commercial', NULL, N'bosquedelrio.adm@gmail.com', NULL, NULL, N'2026-05-22 16:32:54.7139672', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (67, N'commercial', N'Condominio Santa María', NULL, NULL, NULL, N'commercial', NULL, N'condosantamaria@yahoo.com', NULL, NULL, N'2026-05-22 16:32:54.7139672', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (68, N'commercial', N'Costco Wholesale Logistics', NULL, NULL, NULL, N'commercial', NULL, N'dtorresrosado@costco.com', NULL, NULL, N'2026-05-22 16:32:54.7139672', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (69, N'commercial', N'CR Construction', NULL, NULL, NULL, N'engineering', NULL, N'cr_inc@yahoo.com', NULL, NULL, N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (70, N'commercial', N'Cruz Fire Protection', NULL, NULL, NULL, N'engineering', NULL, N'cruzfiresprinkler@gmail.com', NULL, NULL, N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (71, N'commercial', N'Cuadre 2021 - Update', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (72, N'commercial', N'Divisions Maintenance Group', NULL, NULL, NULL, N'commercial', NULL, N'mason.hollister@divisionsinc.com', N'(513) 614-9152', NULL, N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (73, N'commercial', N'Dommie', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (74, N'residential', NULL, N'El', N'Arca Infantil', NULL, N'individual', NULL, N'elarcainfantilinc@gmail.com', NULL, NULL, N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (75, N'residential', NULL, N'Elisa', N'Umpierre', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (76, N'residential', NULL, N'Eng.', N'Blair White', NULL, N'individual', NULL, N'bdiaz@primefire.us', NULL, NULL, N'2026-05-22 16:32:54.7155375', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (77, N'commercial', N'Eng. Jorge E Perez Ruiz PE', NULL, NULL, NULL, N'commercial', NULL, N'perezruiz@tcmg-pr.com', N'(787) 364-6258', NULL, N'2026-05-22 16:32:54.7155375', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (78, N'commercial', N'Enmanuel Desueza_', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7155375', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (79, N'commercial', N'Fire Mechanical Service', NULL, NULL, NULL, N'commercial', NULL, N'firemechservice@yahoo.com', NULL, NULL, N'2026-05-22 16:32:54.7159831', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (80, N'commercial', N'Fundación Luis Muñoz Marín', NULL, NULL, NULL, N'commercial', NULL, N'jquiros@flmm.org', NULL, NULL, N'2026-05-22 16:32:54.7159831', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (81, N'residential', NULL, N'Gallery', N'Plaza', NULL, N'individual', NULL, N'admgalleryplaza@gmail.com', N'787-605-8707', NULL, N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (82, N'residential', NULL, N'Gastos', N'Robo', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (83, N'commercial', N'GB Project Management LLC', NULL, NULL, NULL, N'commercial', NULL, N'arodriguez@primefire.us', N'205-531-4461', NULL, N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (84, N'commercial', N'GJ FIRE BURGLARY EQUIPMENT INC', NULL, NULL, NULL, N'commercial', NULL, N'gjfire@hotmail.com', NULL, NULL, N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (85, N'residential', NULL, N'Gorgas', N'Security Group', NULL, N'individual', NULL, N'gsg_pr@yahoo.com', N'(787) 597-8638', NULL, N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (86, N'residential', NULL, N'Hogar', N'Ciudad Dorada', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (87, N'commercial', N'Holiday', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7179941', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (88, N'residential', NULL, N'Hornblower', N'Ferries Ceiba', NULL, N'individual', NULL, N'jose.jimenez@hornblower.com', NULL, NULL, N'2026-05-22 16:32:54.7179941', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (89, N'residential', NULL, N'IKEA', N'CAROLINA', NULL, N'individual', NULL, N'contabilidad.pr@ikea.pr', NULL, NULL, N'2026-05-22 16:32:54.7179941', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (90, N'commercial', N'IMS Contractor', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7184827', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (91, N'commercial', N'Inversiones Clínica Las Américas S.E', NULL, NULL, NULL, N'commercial', NULL, N'adm.cla1988@gmail.com', NULL, NULL, N'2026-05-22 16:32:54.7184827', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (92, N'commercial', N'IRC Construction', NULL, NULL, NULL, N'engineering', NULL, NULL, N'787-869-2986', NULL, N'2026-05-22 16:32:54.7188489', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (93, N'commercial', N'Jirah General Contractors', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7191677', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (94, N'commercial', N'José Alberto Rodríguez', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7191677', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (95, N'commercial', N'JRM Consulting', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7191677', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (96, N'commercial', N'Mamis Pizza and Bar CORP', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7194691', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (97, N'commercial', N'Manitoa Construction', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (98, N'commercial', N'Matías Plumbing', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (99, N'commercial', N'Mercantil Mayaguez Associates', NULL, NULL, NULL, N'commercial', NULL, N'payables@kingbird.com', NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (100, N'commercial', N'Morgan Facility Services', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (101, N'commercial', N'Mylan INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (102, N'commercial', N'Oasis C.O.G.O.P', NULL, NULL, NULL, N'commercial', NULL, N'blake.hmgs@gmail.com', NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (103, N'commercial', N'Ornis CORP', NULL, NULL, NULL, N'commercial', NULL, N'bdiaz@primefire.us', NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (104, N'residential', NULL, N'Other', N'Deposit', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (105, N'residential', NULL, N'Overhead', N'Cost', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (106, N'commercial', N'PFP-GENERAL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7211789', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (107, N'commercial', N'PFP Misc 2012', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (108, N'commercial', N'PFP Misc 2013', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (109, N'commercial', N'PFP1305', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (110, N'commercial', N'PFP14-01', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (111, N'commercial', N'PFP15-01', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (112, N'commercial', N'Misc 2016', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (113, N'commercial', N'Misc 2017', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (114, N'commercial', N'PFP18-01 Misc 2018', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (115, N'commercial', N'PFP19-01 Misc 2019', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (116, N'commercial', N'PFP20-01 Misc 2020', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (117, N'commercial', N'PFP21-01 Misc 2021', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (118, N'commercial', N'PFP22-01 Misc 2022', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7235294', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (119, N'commercial', N'PFP22-03 Misc Sodexo Bta GMA Citi', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7235294', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (120, N'commercial', N'PFP23-01 Misc 2023', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 43, N'2026-05-22 16:32:54.7235294', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (121, N'commercial', N'PFP23-02 Misc Sodexo Bta Guay City', NULL, NULL, NULL, N'commercial', NULL, N'wigner.rodriguezmartinez@viatris.com', NULL, 44, N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (122, N'commercial', N'PFP24-01 Misc 2024', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 45, N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (123, N'commercial', N'PFP25-01 Misc 2025', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 46, N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (124, N'commercial', N'PFP25-02 Sodexo Misc Bta Guayama & Citi', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 47, N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (125, N'commercial', N'PFP26-01 Misc 2026', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7255370', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (126, N'commercial', N'Plaza Matienzo - Karate', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7255370', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (127, N'residential', NULL, N'Ponte', N'Fresco', NULL, N'individual', NULL, N'cordovalaw@pontefresco.net', NULL, NULL, N'2026-05-22 16:32:54.7255370', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (128, N'residential', NULL, N'Pro', N'Welding', NULL, N'individual', NULL, N'soldadurapr@hotmail.com', N'787-405-3835', NULL, N'2026-05-22 16:32:54.7255370', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (129, N'residential', NULL, N'Pfizer', N'Guayama', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7262102', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (130, N'commercial', N'Ps Misc 2013', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7262102', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (131, N'commercial', N'Puerto Rico Telephone Company', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (132, N'commercial', N'RESOURCE RECYCLING LLC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (133, N'commercial', N'RIFCO Manufacturing', N'Roberto', N'Rodriguez', NULL, N'commercial', NULL, N'rrsiso@coqui.net', N'787-617-7834', NULL, N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (134, N'residential', NULL, N'Roche', N'Diagnostic', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (135, N'commercial', N'Sick', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7285105', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (136, N'residential', NULL, N'Sin', N'Mesura', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7285105', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (137, N'commercial', N'SSS', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7285105', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (138, N'residential', NULL, N'Sucursal', N'Caguas', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7285105', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (139, N'residential', NULL, N'Sucursal', N'Guaynabo', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (140, N'residential', NULL, N'Sucursal', N'Trujillo Alto', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (141, N'commercial', N'Supermercado Selectos Guayama', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (142, N'residential', NULL, N'Taller', N'de Mecanica La Gloria', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (143, N'commercial', N'TD Iron', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (144, N'residential', NULL, N'Test', N'Environmental', NULL, N'individual', NULL, N'primefire@outlook.com', NULL, NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (145, N'commercial', N'Torcon INC', NULL, NULL, NULL, N'commercial', NULL, N'chiraldo@torcon.com', N'787-999-8900', NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (146, N'commercial', N'Unassinged', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (147, N'commercial', N'United States Treasury_', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (148, N'commercial', N'Vacations', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (149, N'commercial', N'William Burgos P.E', NULL, NULL, NULL, N'commercial', NULL, N'willow69@me.com', N'787-557-1226', NULL, N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (150, N'residential', NULL, N'Xtreme', N'Perfomance Martial Arts', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (151, N'residential', NULL, N'Xtreme', N'Performance Matial Arts', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:32:54.7326697', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (152, N'commercial', N'Punta Cana Beach & Golf, SAS', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1013913', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (153, N'commercial', N'Southside International Packaging SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (154, N'commercial', N'Novotech Dominicana', N'Ing.', N'Constantino Gonzalez', NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (155, N'commercial', N'Acuario Tropical SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (156, N'commercial', N'SERVICIOS Y VENTAS E Y R ALONSO EIRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (157, N'commercial', N'Energía 2000, SA', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (158, N'commercial', N'Fermont Group, SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1034018', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (159, N'residential', NULL, N'Jose', N'Alberto Rodriguez Riveras', NULL, N'individual', NULL, NULL, NULL, NULL, N'2026-05-22 16:33:03.1037668', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (160, N'commercial', N'Cliente US$', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 48, N'2026-05-22 16:33:03.1040953', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (161, N'commercial', N'Prime Fire Dominica', NULL, NULL, NULL, N'commercial', NULL, NULL, N'1 (787) 221-2121', NULL, N'2026-05-22 16:33:03.1045457', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (162, N'commercial', N'Prime Fire Dominica:Administration', NULL, NULL, NULL, N'commercial', NULL, NULL, N'1 (787) 221-2121', 49, N'2026-05-22 16:33:03.1051521', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (163, N'commercial', N'Administración:2019', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 50, N'2026-05-22 16:33:03.1054646', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (164, N'commercial', N'Miscelaneos', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 51, N'2026-05-22 16:33:03.1054646', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (165, N'commercial', N'1606 Ponce de León Ave INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 52, N'2026-05-22 16:33:11.1068941', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (166, N'commercial', N'504 Construction Managers', NULL, NULL, NULL, N'engineering', NULL, N'info@504constructionmanagers.com', N'787.706.1227', 53, N'2026-05-22 16:33:11.1079280', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (167, N'commercial', N'A&A Steri-Tec Contractors INC', NULL, NULL, NULL, N'commercial', NULL, N'alaboy@aasteritec.com', N'939-245-3082', 54, N'2026-05-22 16:33:11.1079280', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (168, N'commercial', N'A3 Services', NULL, NULL, NULL, N'commercial', NULL, N'a3servicespr@yahoo.com', NULL, 55, N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (169, N'commercial', N'ABB Arecibo', NULL, NULL, NULL, N'commercial', NULL, N'jonathan.padua-sepulveda@pr.abb.com', NULL, 56, N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (170, N'commercial', N'ABB Vega Alta', NULL, NULL, NULL, N'commercial', NULL, N'AP.BID210145@abb.com', NULL, 57, N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (171, N'commercial', N'ABB Vega Baja', NULL, NULL, NULL, N'commercial', NULL, N'chariluz.bonetvazquez@pr.abb.com', NULL, 58, N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (172, N'commercial', N'Abbott Diagnostics International LTD', NULL, NULL, NULL, N'commercial', NULL, N'Abbott.PR.Invoices@abbott.com', NULL, 59, N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (173, N'commercial', N'Abbvie Knoll LLC', N'Victor', N'Arcelay', NULL, N'commercial', NULL, N'AbbVie.PuertoRico.PRMF@ironmountain.com', N'787-828-8871', 60, N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (174, N'commercial', N'ABLE Sales', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 61, N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (175, N'residential', NULL, N'Academia', N'San Ignacio', NULL, N'individual', NULL, N'jmaiz@asiloyola.org', NULL, 62, N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (176, N'commercial', N'Academy Fire Life Safety LLC', NULL, NULL, NULL, N'commercial', NULL, N'JPearlstein@academyfire.com,   DOzery@academyfire.com', NULL, 63, N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (177, N'commercial', N'ACESCO', NULL, NULL, NULL, N'commercial', NULL, N'koquendo@acesco.com', NULL, 64, N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (178, N'commercial', N'Advanced Industrial Contractors INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 65, N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (179, N'commercial', N'AEELA', N'Roberto', N'Candelario', NULL, N'commercial', NULL, N'roberto.candelario@asociaciondeempleados.com', N'787-641-2021 Ext.108', 66, N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (180, N'commercial', N'AeroMetalica', NULL, NULL, NULL, N'commercial', NULL, N'gerardo@aerometalica.com', N'787-841-3400', 67, N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (181, N'commercial', N'AEROSTAR AIRPORT HOLDINGS LLC', NULL, NULL, NULL, N'commercial', NULL, N'accountspayable@aerostarairports.com', NULL, 68, N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (182, N'commercial', N'AES Puerto Rico LP', NULL, NULL, NULL, N'commercial', NULL, N'arnaldo.pomales@aes.com', N'787-866-8117 x 2264', 69, N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (183, N'commercial', N'AGM Group Engineering CORP', NULL, NULL, NULL, N'engineering', NULL, N'agmgroupcorp@hotmail.com', N'787-638-3383', 70, N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (184, N'commercial', N'Aguayo Sheet Metal INC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'7877941484', 71, N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (185, N'commercial', N'AIP Holdings LLC', NULL, NULL, NULL, N'commercial', NULL, N'nalicea@aipprholdings.com', N'787-250-6494', 72, N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (186, N'commercial', N'Aireko construction', NULL, NULL, NULL, N'engineering', NULL, N'cacevedo@aireko-services.com', N'787-653-6300', 73, N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (187, N'commercial', N'Aires & Servicios Contratistas', NULL, NULL, NULL, N'engineering', NULL, N'jvazquez@airesyservicios.com', N'787-712-3600', 74, N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (188, N'commercial', N'AKZONOBEL Paints PR INC', NULL, NULL, NULL, N'commercial', NULL, N'aksonobel_ap@infostorerecords.com', N'787-641-8900', 75, N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (189, N'commercial', N'ALPLA Caribe INC', NULL, NULL, NULL, N'commercial', NULL, N'carlos.rivera@alpla.com', NULL, 76, N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (190, N'commercial', N'Alproem Engineering Contractors CORP', N'Lisandra-AP', NULL, NULL, N'engineering', NULL, N'invoices@alproem.net', N'787-995-0309', 77, N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (191, N'residential', NULL, N'Alumino', N'del Caribe', NULL, N'individual', NULL, NULL, NULL, 78, N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (192, N'commercial', N'Amgen Manufacturing Limited', NULL, NULL, NULL, N'commercial', NULL, N'APInvoicePR@amgen.com', NULL, 79, N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (193, N'commercial', N'ANGIOTECH', NULL, NULL, NULL, N'commercial', NULL, N'egonzalez@surgicalspecialties.com', N'787-658-1800', 80, N'2026-05-22 16:33:11.1171961', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (194, N'residential', NULL, N'Ara', N'Security Integrators', NULL, N'individual', NULL, N'pramirez@arapr.net', NULL, 81, N'2026-05-22 16:33:11.1175134', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (195, N'commercial', N'Arco Caribe Architects PSC', NULL, NULL, NULL, N'commercial', NULL, N'jvalentin@arcocaribe.com', NULL, 82, N'2026-05-22 16:33:11.1178468', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (196, N'commercial', N'ASEM', NULL, NULL, NULL, N'commercial', NULL, N'thais.encarnacion1@asem.pr.gov', N'787-777-3535', 83, N'2026-05-22 16:33:11.1178468', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (197, N'residential', NULL, N'Asplundh', N'Tree Experts', NULL, N'individual', NULL, N'pmscontractor2020@gmail.com', NULL, 84, N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (198, N'commercial', N'AT CONSTRUCTION SOLUTIONS LLC', NULL, NULL, NULL, N'engineering', NULL, N'invoices@aireko.com', NULL, 85, N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (199, N'commercial', N'Atlantic Marine Construction Company INC', NULL, NULL, NULL, N'engineering', NULL, N'ocampor@amccinc.com', NULL, 86, N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (200, N'commercial', N'Auro PR', NULL, NULL, NULL, N'commercial', NULL, N'8883850848@onlinecapturecenter.com', N'787-704-7500', 87, N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (201, N'commercial', N'AUTOMATIC SUPPRESSION ENGINEERING INC', NULL, NULL, NULL, N'engineering', NULL, N'smokey.ase@gmail.com', NULL, 88, N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (202, N'commercial', N'Autoridad de Energía Eléctrica', NULL, NULL, NULL, N'commercial', NULL, N'roliveros12461@aeepr.com', NULL, 89, N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (203, N'commercial', N'Autoridad de Transporte Marítimo', NULL, NULL, NULL, N'commercial', NULL, N'jlmenendez@dtop.pr.gov', NULL, 90, N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (204, N'commercial', N'Bacardi Corporation', NULL, NULL, NULL, N'commercial', NULL, N'bcorp.apinvoices@bacardi.com', N'787 788-1500', 91, N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (205, N'commercial', N'BARD Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'BardInvoices-NA@bd.com', NULL, 92, N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (206, N'commercial', N'BASF Agricultural Products de Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'paul.nieves@basf.com', NULL, 93, N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (207, N'residential', NULL, N'Baxter', N'Guayama', NULL, N'individual', NULL, N'baxter_coupa_invoices@eportaldoc.com', N'787-954-2434', 94, N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (208, N'commercial', N'Baxter Health Care of Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'aibonito_ap@baxter.com', N'787-954-2434', 95, N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (209, N'commercial', N'Baxter Healthcare Jayuya', NULL, NULL, NULL, N'commercial', NULL, N'baxter_coupa_invoices@eportaldoc.com', N'787-954-2434', 96, N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (210, N'commercial', N'Baxter Healthcare SAS', NULL, NULL, NULL, N'commercial', NULL, N'catano_shs_ap@baxter.com', NULL, 97, N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (211, N'commercial', N'BD Puerto Rico LLC', NULL, NULL, NULL, N'commercial', NULL, N'invoices+NA@bd.coupahost.com', NULL, 98, N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (212, N'residential', NULL, N'Berlitz', N'Hato Rey', NULL, N'individual', NULL, N'janizka.cordova@berlitz.com.pr', N'(787) 753-2585', 99, N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (213, N'commercial', N'Best Solutions Eng & Maintenance Services', NULL, NULL, NULL, N'commercial', NULL, N'bestsolutionseng@yahoo.com', NULL, 100, N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (214, N'commercial', N'BGC PROJECT MANAGEMENT INC', NULL, NULL, NULL, N'commercial', NULL, N'yohan.colon@bgcproject.com', NULL, 101, N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (215, N'commercial', N'Bilgla Construction INC', NULL, NULL, NULL, N'engineering', NULL, N'bilgla2@aol.com', N'787-234-4042', 102, N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (216, N'commercial', N'Blackpoint Management', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-522-2151', 103, N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (217, N'commercial', N'Bonneville', NULL, NULL, NULL, N'commercial', NULL, N'ramon@bonnevillepr.net', N'787-747-0767', 104, N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (218, N'commercial', N'Borinken Marine Goup LLC', NULL, NULL, NULL, N'commercial', NULL, N'daniel.rodriguez@bmg-pr.com', NULL, 105, N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (219, N'commercial', N'BR&A LLC', NULL, NULL, NULL, N'commercial', NULL, N'lgautier@brapr.com', N'787-707-1717', 106, N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (220, N'commercial', N'Brandenburg Industrial Service Company', N'Seth', N'Snider', NULL, N'commercial', NULL, N'sniset@brandenburg.com', N'312-326-5800', 107, N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (221, N'residential', NULL, N'Bristol', N'Myers Squibb', NULL, N'individual', NULL, N'BMSInvoices.NA@bms.com', NULL, 108, N'2026-05-22 16:33:11.1277274', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (222, N'commercial', N'Brown Point Facility Management Solutions', NULL, NULL, NULL, N'commercial', NULL, N'invoices@brownpoint.com', N'1-8000-556-6484', 109, N'2026-05-22 16:33:11.1277274', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (223, N'commercial', N'Cabrits Resort & Spa Kempinski Dominica', NULL, NULL, NULL, N'commercial', NULL, N'arodriguez@primefire.us', NULL, 110, N'2026-05-22 16:33:11.1287477', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (224, N'commercial', N'Cadillac Uniform & Linen Supply', NULL, NULL, NULL, N'commercial', NULL, N'mleon@cadillacuniform.com', NULL, 111, N'2026-05-22 16:33:11.1290900', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (225, N'commercial', N'Caguas Mechanical Contractor', N'Mr.', N'Crespo', NULL, N'commercial', NULL, N'acrespo@caguasmechanical.com', NULL, 112, N'2026-05-22 16:33:11.1297394', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (226, N'commercial', N'CamuyCoop', NULL, NULL, NULL, N'commercial', NULL, N'kmuniz@camuycoop.com', N'787-898-4970', 113, N'2026-05-22 16:33:11.1297394', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (227, N'commercial', N'Capital Services LLC', NULL, NULL, NULL, N'commercial', NULL, N'iborges90@gmail.com', NULL, 114, N'2026-05-22 16:33:11.1297394', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (228, N'commercial', N'Cardinal Health PR INC', NULL, NULL, NULL, N'commercial', NULL, N'eduardo.Hernandez@cardinalhealth.com', N'787-625-4100', 115, N'2026-05-22 16:33:11.1313035', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (229, N'commercial', N'Caribbean Construction Partners CORP', NULL, NULL, NULL, N'engineering', NULL, N'caribbeanconstructiongroup@gmail.com', N'787-233-4804', 116, N'2026-05-22 16:33:11.1317494', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (230, N'commercial', N'Caribbean Energy', NULL, NULL, NULL, N'commercial', NULL, N'edna@cedpr.com', N'787-750-5566', 117, N'2026-05-22 16:33:11.1317494', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (231, N'commercial', N'Caribbean Industrial Construction S.E', NULL, NULL, NULL, N'engineering', NULL, NULL, N'787-287-3540', 118, N'2026-05-22 16:33:11.1317494', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (232, N'commercial', N'Caribbean Project Management', NULL, NULL, NULL, N'commercial', NULL, N'mrivera@grupocpm.com', N'787-999-4000', 119, N'2026-05-22 16:33:11.1328687', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (233, N'commercial', N'Caribbean Property Group LLC', NULL, NULL, NULL, N'commercial', NULL, N'livia.polanco@cpgservicing.com', N'787-788-1192', 120, N'2026-05-22 16:33:11.1331832', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (234, N'commercial', N'Caribbean Refrescos INC', NULL, NULL, NULL, N'commercial', NULL, N'rreyes@coca-cola.com', NULL, 121, N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (235, N'commercial', N'Caribe Hydroblasting Corp._', NULL, NULL, NULL, N'commercial', NULL, N'r.santos@chedcaribe.com', N'787-836-1110', 122, N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (236, N'commercial', N'Caribe Pro Services INC', NULL, NULL, NULL, N'commercial', NULL, N'mnegron@caribepro.com', N'(787) 275-7121', 123, N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (237, N'commercial', N'Carlos Beltrán Baseball Academy', NULL, NULL, NULL, N'commercial', NULL, N'paoclau43@hotmail.com', NULL, 124, N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (238, N'residential', NULL, N'CBRE', N'BMS', NULL, N'individual', NULL, N'be-bms-invoices@jci.com', NULL, 125, N'2026-05-22 16:33:11.1354310', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (239, N'commercial', N'CBRE GSK Guayama', NULL, NULL, NULL, N'commercial', NULL, N'BE-Pfizer-Invoices@jci.com', N'787-625-2011 R Cotto', 126, N'2026-05-22 16:33:11.1354310', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (240, N'commercial', N'CCL Puerto Rico INC', NULL, NULL, NULL, N'commercial', NULL, N'laperales@cclind.com', N'787-892-1268', 127, N'2026-05-22 16:33:11.1361108', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (241, N'commercial', N'CE Plumbing Corporation', N'Carlos', N'Montes', NULL, N'commercial', NULL, N'montescarlose@yahoo.com', N'787-259-3043', 128, N'2026-05-22 16:33:11.1366315', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (242, N'residential', NULL, N'Cervecera', N'de Puerto Rico', NULL, N'individual', NULL, N'maria.contreras@cerveceradepr.com', NULL, 129, N'2026-05-22 16:33:20.5751761', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (243, N'residential', NULL, N'Cesar', N'Castillo', NULL, N'individual', NULL, N'nlugo@cesarcastillo.com', N'787-999-1616', 130, N'2026-05-22 16:33:20.5757619', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (244, N'commercial', N'CG Construction CORP', NULL, NULL, NULL, N'engineering', NULL, N'cgconstruction@libertypr.net', N'787-863-2727', 131, N'2026-05-22 16:33:20.5760974', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (245, N'commercial', N'CIC Construction Group LLC', NULL, NULL, NULL, N'engineering', NULL, N'lfernandez@cic-pr.com', N'787-287-3540', 132, N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (246, N'commercial', N'Cimetric', NULL, NULL, NULL, N'commercial', NULL, N'office@cimetricpr.com', NULL, 133, N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (247, N'commercial', N'Clary Corp of P.R. INC', NULL, NULL, NULL, N'commercial', NULL, N'reiner.simshauser@clarypr.com', NULL, 134, N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (248, N'commercial', N'CLPG SJIP 1 LLC', NULL, NULL, NULL, N'commercial', NULL, N'madeline.oliveras@kingbird.com', N'787-239-1163', 135, N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (249, N'commercial', N'CMGC Building CORP', NULL, NULL, NULL, N'engineering', NULL, N'bdiaz@primefire.us', N'803-883-5169', 136, N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (250, N'residential', NULL, N'Colgate', N'Palmolive', NULL, N'individual', NULL, N'bp_shadir_galafa@colpal.com', NULL, 137, N'2026-05-22 16:33:20.5780252', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (251, N'commercial', N'Colgate Palmolive de PR INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 138, N'2026-05-22 16:33:20.5780252', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (252, N'commercial', N'Columbia Care PR', NULL, NULL, NULL, N'commercial', NULL, N'appuertorico@col-care.com', NULL, 139, N'2026-05-22 16:33:20.5780252', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (253, N'commercial', N'Combe Products INC', NULL, NULL, NULL, N'commercial', NULL, N'mlopezcastro@combe.com', N'787-313-6373', 140, N'2026-05-22 16:33:20.5780252', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (254, N'commercial', N'Commercial Centers Management INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 141, N'2026-05-22 16:33:20.5788877', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (255, N'commercial', N'Comprehensive Fire Technologies', NULL, NULL, NULL, N'commercial', NULL, N'jhagan@comprehensivefire.com, sshorkey@comprehensivefire.com', N'732-590-2293', 142, N'2026-05-22 16:33:20.5788877', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (256, N'residential', NULL, N'Concorde', N'Metro Seguros', NULL, N'individual', NULL, N'2metromedcenter@gmail.com', N'787-778-7000', 143, N'2026-05-22 16:33:20.5800441', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (257, N'residential', NULL, N'Cond.', N'Bayside Cove', NULL, N'individual', NULL, N'gvelez@primefire.us', NULL, 144, N'2026-05-22 16:33:20.5800441', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (258, N'commercial', N'CONGAR INTERNATIONAL CORP', N'Nelly', N'Vicente', NULL, N'commercial', NULL, N'mpagan@altadisusa.com', N'787-738-2106', 145, N'2026-05-22 16:33:20.5809110', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (259, N'commercial', N'Constructora DIROVI CORP', NULL, NULL, NULL, N'engineering', NULL, N'constructoradirovi@gmail.com', N'787-479-0387', 146, N'2026-05-22 16:33:20.5809110', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (260, N'commercial', N'CONSTRUCTORA EL ALBA INC', NULL, NULL, NULL, N'engineering', NULL, NULL, N'787-874-7981', 147, N'2026-05-22 16:33:20.5820568', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (261, N'commercial', N'Constructora Santiago', NULL, NULL, NULL, N'engineering', NULL, N'jrodriguez@constructorasantiago.com', N'787-761-7171', 148, N'2026-05-22 16:33:20.5820568', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (262, N'commercial', N'Contratista Millenium', NULL, NULL, NULL, N'engineering', NULL, N'milleniumps@gmail.com', N'787-626-5285', 149, N'2026-05-22 16:33:20.5829316', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (263, N'residential', NULL, N'Control', N'de Fuego', NULL, N'individual', NULL, N'controlf@codetel.net.do', N'809-695-6152', 150, N'2026-05-22 16:33:20.5829316', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (264, N'commercial', N'Converged Systems & Solutions', NULL, NULL, NULL, N'commercial', NULL, N'stephen.gibbs@css-caribbean.com', N'(246) 431 2774', 151, N'2026-05-22 16:33:20.5840665', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (265, N'residential', NULL, N'Cooperativa', N'Las Piedras', NULL, N'individual', NULL, N'jlozada@cooplaspiedras.com', N'787-733-2821', 152, N'2026-05-22 16:33:20.5840665', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (266, N'commercial', N'CooperVision MFG Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'apinvoice220@coopervision.com', NULL, 153, N'2026-05-22 16:33:20.5840665', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (267, N'commercial', N'Copan Industries INC', NULL, NULL, NULL, N'commercial', NULL, N'omar.camacho@copangroup.com', NULL, 154, N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (268, N'commercial', N'Cornerstone Industrial Group CORP', NULL, NULL, NULL, N'commercial', NULL, N'jrincon@cornerstoneindustrialpr.com', N'787-412-0900', 155, N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (269, N'residential', NULL, N'Cotto', N'Incorporado', NULL, N'individual', NULL, N'elis.melendez@cottoincorporado.com', NULL, 156, N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (270, N'commercial', N'COTTON INTERNATIONAL', NULL, NULL, NULL, N'commercial', NULL, N'cristina.alonso@cottonteam.com', NULL, 157, N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (271, N'commercial', N'CREATIVE DEVELOPMENTS CORP', NULL, NULL, NULL, N'commercial', NULL, N'jguerrero@creativedevelop.com', N'787.283.6969', 158, N'2026-05-22 16:33:20.5860754', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (272, N'commercial', N'CrossFit Purpose', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 159, N'2026-05-22 16:33:20.5860754', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (273, N'commercial', N'Crowley Maritime Corporation', NULL, NULL, NULL, N'commercial', NULL, N'juanmiguel.casiano@crowley.com', NULL, 160, N'2026-05-22 16:33:20.5860754', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (274, N'commercial', N'Cruybelt Contractor', NULL, NULL, NULL, N'commercial', NULL, N'administration@cruybeltpr.com', N'787-733-4417', 161, N'2026-05-22 16:33:20.5867789', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (275, N'commercial', N'CSS Caribbean', NULL, NULL, NULL, N'commercial', NULL, N'arodriguez@primefire.us', NULL, 162, N'2026-05-22 16:33:20.5867789', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (276, N'commercial', N'CSS Contractors CORP', NULL, NULL, NULL, N'commercial', NULL, N'drodriguez@csscontractors.com', N'787-775-9300', 163, N'2026-05-22 16:33:20.5867789', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (277, N'commercial', N'CytoImmune Therapeutics Puerto Rico LLC', NULL, NULL, NULL, N'commercial', NULL, N'jose.acevedo@cytoimmune.com', NULL, 164, N'2026-05-22 16:33:20.5875741', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (278, N'commercial', N'Damiani Contractors INC', NULL, NULL, NULL, N'commercial', NULL, N'damianicontractors@gmail.com', N'787-899-5763', 165, N'2026-05-22 16:33:20.5880840', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (279, N'residential', NULL, N'Dentsply', N'Ceramco', NULL, N'individual', NULL, N'docs.us@dentsplysirona.com', NULL, 166, N'2026-05-22 16:33:20.5880840', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (280, N'commercial', N'DEPARTAMENTO DE CORRECCION Y REHABILITACI', NULL, NULL, NULL, N'commercial', NULL, N'mdrivera@dcr.pr.gov', NULL, 167, N'2026-05-22 16:33:20.5880840', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (281, N'commercial', N'Department of Veterans Affairs', NULL, NULL, NULL, N'commercial', NULL, N'Francisco.Rivera-Mujica@va.gov', NULL, 168, N'2026-05-22 16:33:20.5880840', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (282, N'commercial', N'Designed Temperatures INC', NULL, NULL, NULL, N'engineering', NULL, N'designedtemperaturesinc@yahoo.com', N'787-882-4645', 169, N'2026-05-22 16:33:20.5890014', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (283, N'commercial', N'Digney York Associates LLC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-352-516-7826', 170, N'2026-05-22 16:33:20.5895813', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (284, N'commercial', N'DIVISION 16 LLC', NULL, NULL, NULL, N'commercial', NULL, N'jnazario@division16pr.com', N'(787)-286-6464', 171, N'2026-05-22 16:33:20.5895813', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (285, N'commercial', N'Doctor''s Cancer Center', NULL, NULL, NULL, N'commercial', NULL, N'cesarpr@me.com', N'7873463187', 172, N'2026-05-22 16:33:20.5895813', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (286, N'commercial', N'Downtown Development', NULL, NULL, NULL, N'commercial', NULL, N'lwiner@realestatepr.net', N'787-701-6067', 173, N'2026-05-22 16:33:20.5910247', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (287, N'commercial', N'Eastern Developers Investment S. A. S', NULL, NULL, NULL, N'commercial', NULL, N'fperez@puntacana.com', NULL, 174, N'2026-05-22 16:33:20.5914862', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (288, N'commercial', N'Eco Building Solutions INC', NULL, NULL, NULL, N'engineering', NULL, N'margarita@ecobuildinginc.com', N'787-789-2830', 175, N'2026-05-22 16:33:20.5921057', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (289, N'commercial', N'EcoEléctrica L.P', N'José', N'Borges', NULL, N'commercial', NULL, N'luis.cruz@ecoelectrica.com', N'787-836-2740', 176, N'2026-05-22 16:33:20.5924256', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (290, N'residential', NULL, N'Eileen', N'Medina', NULL, N'individual', NULL, N'krondon@primefire.us', N'787-692-5481', 177, N'2026-05-22 16:33:20.5927309', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (291, N'commercial', N'EM Contractor INC', NULL, NULL, NULL, N'commercial', NULL, N'emcontractorinc@gmail.com', N'787-656-9889', 178, N'2026-05-22 16:33:20.5936097', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (292, N'commercial', N'Endeavor Construction Group INC', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, 179, N'2026-05-22 16:33:20.5939115', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (293, N'commercial', N'Enersys Engineering Corporation', NULL, NULL, NULL, N'engineering', NULL, N'jruiz@enersyspr.com', N'787-620-1672', 180, N'2026-05-22 16:33:20.5939115', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (294, N'commercial', N'ER Building Solutions LLC', NULL, NULL, NULL, N'engineering', NULL, N'OFFICE@ERBPR.COM', N'7879983621', 181, N'2026-05-22 16:33:20.5939115', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (295, N'commercial', N'Essentials', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 182, N'2026-05-22 16:33:20.5956209', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (296, N'commercial', N'Ethicon LLC', NULL, NULL, NULL, N'commercial', NULL, N'JSant232@ITS.JNJ.com', NULL, 183, N'2026-05-22 16:33:20.5963926', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (297, N'commercial', N'EVS INC', NULL, NULL, NULL, N'commercial', NULL, N'rkack@evs-eng.com', N'952-646-0254', 184, N'2026-05-22 16:33:20.5963926', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (298, N'commercial', N'Executive Homesearch & Realty Services', NULL, NULL, NULL, N'commercial', NULL, N'eclemente@executivehomesearch.com', NULL, 185, N'2026-05-22 16:33:20.5963926', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (299, N'commercial', N'FAA ATCT', NULL, NULL, NULL, N'commercial', NULL, N'Gretchen.Fuentes@faa.gov', NULL, 186, N'2026-05-22 16:33:20.5976359', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (300, N'commercial', N'FAA CERAP', NULL, NULL, NULL, N'commercial', NULL, N'ThuyLinh.T.TranNguyen@faa.gov', NULL, 187, N'2026-05-22 16:33:20.5976359', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (301, N'commercial', N'FDA', NULL, NULL, NULL, N'commercial', NULL, N'Angel.Colon-Madera@fda.hhs.gov', NULL, 188, N'2026-05-22 16:33:20.5981083', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (302, N'commercial', N'FHC', NULL, NULL, NULL, N'commercial', NULL, N'rcruz@firsthealthcall.com', NULL, 189, N'2026-05-22 16:33:20.5988882', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (303, N'commercial', N'Fire Proof', NULL, NULL, NULL, N'commercial', NULL, N'fireproofinc@gmail.com', NULL, 190, N'2026-05-22 16:33:20.5994951', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (304, N'commercial', N'Fire Safe INC', NULL, NULL, NULL, N'commercial', NULL, N'gvelez@primefire.us', N'787-293-2210', 191, N'2026-05-22 16:33:20.6001280', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (305, N'commercial', N'FireProof', NULL, NULL, NULL, N'commercial', NULL, N'fireproofinc@gmail.com', NULL, 192, N'2026-05-22 16:33:20.6001280', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (306, N'commercial', N'First Hospital Panamericano', NULL, NULL, NULL, N'commercial', NULL, N'jcorrea@primefire.us', NULL, 193, N'2026-05-22 16:33:20.6009137', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (307, N'commercial', N'FM Global', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-993-0330', 194, N'2026-05-22 16:33:20.6015031', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (308, N'commercial', N'Four Seasons Environmental INC', NULL, NULL, NULL, N'commercial', NULL, N'adminpr@fseinc.net', N'787-421-6240', 195, N'2026-05-22 16:33:20.6015031', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (309, N'commercial', N'Fox Engineering & Construction', NULL, NULL, NULL, N'engineering', NULL, N'daniel@foxpr.net', NULL, 196, N'2026-05-22 16:33:20.6021481', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (310, N'commercial', N'G-Con Manufacturing INC', NULL, NULL, NULL, N'commercial', NULL, N'ap@gconbio.com', NULL, 197, N'2026-05-22 16:33:20.6021481', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (311, N'commercial', N'G & N Construction', NULL, NULL, NULL, N'engineering', NULL, N'gjrodz@hotmail.com', N'939-640-9649', 198, N'2026-05-22 16:33:20.6028774', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (312, N'commercial', N'G2 Construction Management LLC', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, 199, N'2026-05-22 16:33:20.6028774', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (313, N'commercial', N'GENCO', NULL, NULL, NULL, N'commercial', NULL, N'aurelio.mendoza@gencopr.com', NULL, 200, N'2026-05-22 16:33:20.6041693', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (314, N'residential', NULL, N'General', N'Cigar', NULL, N'individual', NULL, N'edesueza@primefirepr.com', NULL, 201, N'2026-05-22 16:33:20.6041693', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (315, N'commercial', N'Geoterra', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-548-8260', 202, N'2026-05-22 16:33:20.6049490', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (316, N'commercial', N'GH Properties Partnership', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-287-3540', 203, N'2026-05-22 16:33:20.6049490', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (317, N'commercial', N'Gilbane Building Company', NULL, NULL, NULL, N'engineering', NULL, N'PBurgos-Zayas@gilbaneco.com', NULL, 204, N'2026-05-22 16:33:20.6049490', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (318, N'commercial', N'GK Pharmaceuticals CMO LLC', NULL, NULL, NULL, N'commercial', NULL, N'crivera@gkcmo.com', N'787-621-1818', 205, N'2026-05-22 16:33:20.6061917', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (319, N'commercial', N'Global Innovative Network INC', NULL, NULL, NULL, N'commercial', NULL, N'global@ginpr.com', N'787-879-3886', 206, N'2026-05-22 16:33:31.4442109', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (320, N'commercial', N'Gobierno Municipal Autónomo de Carolina', NULL, NULL, NULL, N'commercial', NULL, N'cribot@carolina.pr.gov', N'787-757-2626', 207, N'2026-05-22 16:33:31.4448387', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (321, N'commercial', N'Green Energy Systems CORP', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 208, N'2026-05-22 16:33:31.4448387', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (322, N'commercial', N'GSG', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 209, N'2026-05-22 16:33:31.4451793', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (323, N'commercial', N'Guardia Nacional de Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'vianca.l.diazcalo.nfg@army.mil', N'787-289-1400 Ext 106', 210, N'2026-05-22 16:33:31.4455992', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (324, N'commercial', N'H&E Development LLC', NULL, NULL, NULL, N'commercial', NULL, N'lrodriguez@hedevelopment.onmicrosoft.com', N'787-763-1307', 211, N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (325, N'commercial', N'HACIENDA DEL MAR OWNERS'' ASSOCIATION INC', NULL, NULL, NULL, N'commercial', NULL, N'Shawn.cullum@msssolutions.com', NULL, 212, N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (326, N'commercial', N'HBA Contractors INC', NULL, NULL, NULL, N'commercial', NULL, N'calzadilla@hbacorp.net', N'787-722-6882', 213, N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (327, N'commercial', N'HCCM CORP', NULL, NULL, NULL, N'commercial', NULL, N'erhccm@gmail.com', NULL, 214, N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (328, N'commercial', N'Héctor M. Varela INC', NULL, NULL, NULL, N'commercial', NULL, N'hmvarelajr@hmvarela.com', N'787-789-9292', 215, N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (329, N'residential', NULL, N'Hernandez', N'Signs', NULL, N'individual', NULL, NULL, NULL, 216, N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (330, N'commercial', N'HMS Ferries - Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'hmspr-ap@cityexperiences.com', NULL, 217, N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (331, N'residential', NULL, N'Carmelo', N'Ortiz', NULL, N'individual', NULL, N'hogarbenaia1@yahoo.com', N'787-810-5634', 218, N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (332, N'commercial', N'Hogar Manuel Mediavilla Negrón INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 219, N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (333, N'commercial', N'Home Depot Support INC', NULL, NULL, NULL, N'commercial', NULL, N'gvelez@primefire.us', NULL, 220, N'2026-05-22 16:33:31.4492690', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (334, N'commercial', N'Honeywell International INC', NULL, NULL, NULL, N'commercial', NULL, N'Eileen.MedinaCoris@Honeywell.com', N'787-792-7075', 221, N'2026-05-22 16:33:31.4492690', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (335, N'commercial', N'Hospital Damas INC', NULL, NULL, NULL, N'commercial', NULL, N'plantafisica@hospitaldamas.com', NULL, 222, N'2026-05-22 16:33:31.4492690', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (336, N'commercial', N'HOSPITAL REGIONAL BAYAMON', NULL, NULL, NULL, N'commercial', NULL, N'natalia.garcia@salud.pr.gov', NULL, 223, N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (337, N'commercial', N'Hospitality Management Goods & Services', NULL, NULL, NULL, N'commercial', NULL, N'blake.hmgs@gmail.com', N'340-227-3919', 224, N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (338, N'commercial', N'Hubbell Caribe Limited', NULL, NULL, NULL, N'commercial', NULL, N'AArguinzoni@hubbell.com', NULL, 225, N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (339, N'residential', NULL, N'Hyatt', N'Regency', NULL, N'individual', NULL, N'bemara.miro@hyatt.com', NULL, 226, N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (340, N'residential', NULL, N'Hyatt', N'Residence Club Dorado', NULL, N'individual', NULL, N'jorgeluis.rodriguez@vacationclub.com', NULL, 227, N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (341, N'commercial', N'ICS INC', N'Armando', N'Vazquez   A/Payable', NULL, N'commercial', NULL, N'evillavicencio@ics-pr.com', N'787-273-8169', 228, N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (342, N'commercial', N'IDAIVE Contractors INC', NULL, NULL, NULL, N'commercial', NULL, N'i.sanchez@idaive.com', N'787-884-5065', 229, N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (343, N'commercial', N'Iglesia Avivada en Cristo INC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-627-3817', 230, N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (344, N'commercial', N'Iglesia Evangelica Unida', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 231, N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (345, N'residential', NULL, N'IKEA', N'BAYAMON', NULL, N'individual', NULL, N'carlos.molina@ikea.pr', NULL, 232, N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (346, N'commercial', N'Image First/DUI INC', NULL, NULL, NULL, N'commercial', NULL, N'llebron@duiinc.com', NULL, 233, N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (347, N'commercial', N'Impress Packaging PR INC', NULL, NULL, NULL, N'commercial', NULL, N'raul.ortiz@impressusa.net', N'787-834-3499', 234, N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (348, N'commercial', N'Inducom Group LLC', NULL, NULL, NULL, N'commercial', NULL, N'nb.bestproperties@gmail.com', N'787 760 6730', 235, N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (349, N'commercial', N'INDUPRO LLC', NULL, NULL, NULL, N'commercial', NULL, N'ralph@indupropr.com', N'787-704-2288', 236, N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (350, N'commercial', N'Industrial Fire', NULL, NULL, NULL, N'commercial', NULL, N'industrialfire@outlook.com', NULL, 237, N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (351, N'commercial', N'Industrial Process Supply', NULL, NULL, NULL, N'commercial', NULL, N'nacosta@ipspr.com', NULL, 238, N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (352, N'commercial', N'Innova Fire Protection INC', NULL, NULL, NULL, N'engineering', NULL, N'vilodi@gmail.com', NULL, 239, N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (353, N'commercial', N'Inova Fire Protection', NULL, NULL, NULL, N'engineering', NULL, N'eguilloty@primefire.us', N'787-702-8155', 240, N'2026-05-22 16:33:31.4559745', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (354, N'commercial', N'Integrated Building Solutions', NULL, NULL, NULL, N'engineering', NULL, N'payable@ibstg.com', N'787-743-0886', 241, N'2026-05-22 16:33:31.4559745', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (355, N'commercial', N'Integrated Health Systems of Guaynabo', NULL, NULL, NULL, N'commercial', NULL, N'yarivera@gms-pr.com', NULL, 242, N'2026-05-22 16:33:31.4559745', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (356, N'commercial', N'Inverco', NULL, NULL, NULL, N'commercial', NULL, N'inverco@prtc.net', NULL, 243, N'2026-05-22 16:33:31.4574081', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (357, N'commercial', N'Inversiones Grinne INC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-461-9332', 244, N'2026-05-22 16:33:31.4577278', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (358, N'commercial', N'INVERSIONES OMEGA SRL', NULL, NULL, NULL, N'commercial', NULL, N'edesueza@primefirepr.com', N'(809) 536 - 5020', 245, N'2026-05-22 16:33:31.4581165', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (359, N'commercial', N'IPQOZB LLC', NULL, NULL, NULL, N'commercial', NULL, N'pablo@cvgmanagement.com', N'(787) 646-4551', 246, N'2026-05-22 16:33:31.4581165', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (360, N'commercial', N'iPR Pharmaceuticals INC', N'Invoice_Puerto', N'Rico', NULL, N'commercial', NULL, N'ipr.accountspayable@astrazeneca.com', N'787-957-4303', 247, N'2026-05-22 16:33:31.4591921', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (361, N'residential', NULL, N'Iron', N'Mountain', NULL, N'individual', NULL, NULL, NULL, 248, N'2026-05-22 16:33:31.4594934', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (362, N'commercial', N'ISN', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 249, N'2026-05-22 16:33:31.4594934', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (363, N'commercial', N'J&E Construction Developers LLC', NULL, NULL, NULL, N'engineering', NULL, N'jorgecaldwellbraegger@gmail.com', N'(939) 368-1414', 250, N'2026-05-22 16:33:31.4602127', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (364, N'commercial', N'J.F. García', NULL, NULL, NULL, N'commercial', NULL, N'f.boschetti@juanfgarcia.net', N'787-720-1500', 251, N'2026-05-22 16:33:31.4605773', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (365, N'commercial', N'Jays and Fancy Management Services LLC', NULL, NULL, NULL, N'commercial', NULL, N'krobles@jaysandfancy.com', N'787-786-9411', 252, N'2026-05-22 16:33:31.4605773', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (366, N'commercial', N'JCR Electrical Contractor', NULL, NULL, NULL, N'engineering', NULL, N'info@jcrelectricalcontractor.com, j.cubano@jcrelectricalcontractor.com', N'(787) 975-4535', 253, N'2026-05-22 16:33:31.4615102', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (367, N'residential', NULL, N'JETSON', N'GROUP', NULL, N'individual', NULL, NULL, NULL, 254, N'2026-05-22 16:33:31.4615102', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (368, N'commercial', N'JFI GENERAL CONTRACTOR', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-384-5815', 255, N'2026-05-22 16:33:31.4622323', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (369, N'commercial', N'JJC Industrial Services INC', NULL, NULL, NULL, N'commercial', NULL, N'compras@jjcindustrial.com', N'787-883-5260', 256, N'2026-05-22 16:33:31.4622323', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (370, N'residential', NULL, N'John', N'Bader', NULL, N'individual', NULL, N'gvelez@primefire.us', NULL, 257, N'2026-05-22 16:33:31.4622323', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (371, N'commercial', N'Johnson Controls', NULL, NULL, NULL, N'commercial', NULL, N'Adalis.Vallejo-Machin@jci.com', NULL, 258, N'2026-05-22 16:33:31.4635301', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (372, N'residential', NULL, N'Jones', N'Lang Lasalle Amgen', NULL, N'individual', NULL, N'JLLUSA.CSInvoices@am.jll.com', NULL, 259, N'2026-05-22 16:33:31.4642563', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (373, N'commercial', N'Jones Lang Lasalle BD', NULL, NULL, NULL, N'commercial', NULL, N'JLLUSA.CSInvoices@am.jll.com', NULL, 260, N'2026-05-22 16:33:31.4642563', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (374, N'commercial', N'Jones Lang Lasalle BMS', NULL, NULL, NULL, N'commercial', NULL, N'JLLUSA.CSInvoices@am.jll.com', NULL, 261, N'2026-05-22 16:33:31.4642563', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (375, N'commercial', N'Jones Lang LaSalle Ethicon', NULL, NULL, NULL, N'commercial', NULL, N'jnj.facturacionpr@jll.com', NULL, 262, N'2026-05-22 16:33:31.4655412', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (376, N'residential', NULL, N'Jones', N'Lang Lasalle Ethicon Manati', NULL, N'individual', NULL, N'JNJ.facturacionpr@jll.com', NULL, 263, N'2026-05-22 16:33:31.4655412', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (377, N'commercial', N'Jones Lang LaSalle Puerto Rico INC', NULL, NULL, NULL, N'commercial', NULL, N'JLLUSA.CSInvoices@am.jll.com', NULL, 264, N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (378, N'commercial', N'L&R Engineering Group', NULL, NULL, NULL, N'engineering', NULL, N'jrosario@lrenggroup.com', N'787.725.7224', 265, N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (379, N'commercial', N'Laboratorio Clínico Isla Verde', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-564-9769', 266, N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (380, N'commercial', N'Las Brisas Property Management', NULL, NULL, NULL, N'commercial', NULL, N'support@lasbrisasproperty.com', N'787-771-2222', 267, N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (381, N'commercial', N'Latin American Subs LLC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 268, N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (382, N'commercial', N'Lemartec USVI', NULL, NULL, NULL, N'commercial', NULL, N'apusvi@lemartec.com', NULL, 269, N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (383, N'commercial', N'Lilly del Caribe INC', NULL, NULL, NULL, N'commercial', NULL, N'crespo_nelson@lilly.com', N'787-999-3840', 270, N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (384, N'commercial', N'Lord Electric Co. of Puerto Rico INC', NULL, NULL, NULL, N'engineering', NULL, N'cching@lordelectric.com', N'787-590-2469', 271, N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (385, N'commercial', N'Los Orígenes Power Plant', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 272, N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (386, N'commercial', N'Luis A. Ayala Colon Tucrs INC', NULL, NULL, NULL, N'commercial', NULL, N'frivera@ayacol.com', N'787.792.9000', 273, N'2026-05-22 16:33:31.4687128', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (387, N'commercial', N'LUMA ENERGY SERVCO LLC', NULL, NULL, NULL, N'commercial', NULL, N'ap@lumapr.com', NULL, 274, N'2026-05-22 16:33:31.4687128', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (388, N'commercial', N'Mac Climber INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 275, N'2026-05-22 16:33:31.4695543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (389, N'residential', NULL, N'Maderera', N'Donestevez', NULL, N'individual', NULL, N'arosado@maderera-donestevez.com', N'787-750-2000', 276, N'2026-05-22 16:33:31.4695543', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (390, N'commercial', N'Maglez Engineering & Contractors CORP', NULL, NULL, NULL, N'engineering', NULL, N'melgonzalez@maglez.net', NULL, 277, N'2026-05-22 16:33:31.4708141', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (391, N'commercial', N'MAKRO CORP', NULL, NULL, NULL, N'commercial', NULL, N'lgonzalez@makropr.com', NULL, 278, N'2026-05-22 16:33:31.4711256', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (392, N'commercial', N'MARBELLA CLUB OF HOA INC', NULL, NULL, NULL, N'commercial', NULL, N'manager@marbellaclubpr.com', NULL, 279, N'2026-05-22 16:33:31.4714935', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (393, N'residential', NULL, N'Marriot', N'Courtyard Isla Verde', NULL, N'individual', NULL, NULL, N'787-643-3260', 280, N'2026-05-22 16:33:31.4714935', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (394, N'commercial', N'Marriott''s Frenchman''s Cove', NULL, NULL, NULL, N'commercial', NULL, N'Junior.Jean-Baptiste@vacationclub.com', NULL, 281, N'2026-05-22 16:33:31.4727629', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (395, N'commercial', N'MARRIOTT''S ST. KITTS BEACH CLUB', NULL, NULL, NULL, N'commercial', NULL, N'Carlos.Skelton@vacationclub.com', NULL, 282, N'2026-05-22 16:33:41.1103577', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (396, N'commercial', N'Marvel Designs', NULL, NULL, NULL, N'engineering', NULL, N'hralat@marveldesigns.com', N'787.289.9494', 283, N'2026-05-22 16:33:41.1103577', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (397, N'commercial', N'Mastec Renewables Puerto Rico LLC', NULL, NULL, NULL, N'commercial', NULL, N'fernando.roig@mastec.com', NULL, 284, N'2026-05-22 16:33:41.1112844', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (398, N'commercial', N'Matosantos Commercial CORP', NULL, NULL, NULL, N'commercial', NULL, N'accountspayables@matosantos.com', NULL, 285, N'2026-05-22 16:33:41.1115934', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (399, N'commercial', N'Mattcon General Contractors INC', NULL, NULL, NULL, N'commercial', NULL, N'jareds@mattcongc.com', N'317-872-4700', 286, N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (400, N'commercial', N'Maximo Solar Industries INC', NULL, NULL, NULL, N'commercial', NULL, N'jsegarra@maximosolar.com', NULL, 287, N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (401, N'commercial', N'McNeil Healthcare LLC', NULL, NULL, NULL, N'commercial', NULL, N'lsanti25@kenvue.com', NULL, 288, N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (402, N'commercial', N'Medtronic INC', NULL, NULL, NULL, N'commercial', NULL, N'RS.USAP@MEDTRONIC.COM', NULL, 289, N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (403, N'residential', NULL, N'Jesús', N'Torres', NULL, N'individual', NULL, N'ifmpayable@mentortg.com', N'787-743-0897', 290, N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (404, N'commercial', N'MERCANTIL SAN PATRICIO ASSOCIATES', NULL, NULL, NULL, N'commercial', NULL, N'payables@kingbird.com', NULL, 291, N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (405, N'residential', NULL, N'Merck', N'Las Piedras Operations', NULL, N'individual', NULL, N'accounting@cruybeltpr.com', NULL, 292, N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (406, N'commercial', N'Metro Health Care Management System INC', NULL, NULL, NULL, N'commercial', NULL, N'accpay1@metropaviaclinic.com', N'787-650-7294', 293, N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (407, N'commercial', N'Metro Medical Orthopedic', N'Miguel', N'Cortes', NULL, N'commercial', NULL, NULL, N'787-269-0040', 294, N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (408, N'commercial', N'Metro Realty INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 295, N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (409, N'commercial', N'Michael Baker CORP', NULL, NULL, NULL, N'commercial', NULL, NULL, N'412-269-6116', 296, N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (410, N'commercial', N'Millennium Institute', NULL, NULL, NULL, N'commercial', NULL, N'ypedrogo@mifanc.com', NULL, 297, N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (411, N'commercial', N'Molina Healthcare of Puerto Rico', NULL, NULL, NULL, N'commercial', NULL, N'marcos.gonzalez@molinahealthcare.com', N'787-200-3300', 298, N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (412, N'commercial', N'Monserrate Consulting Group INC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-774-8322', 299, N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (413, N'commercial', N'MRG Factory', NULL, NULL, NULL, N'commercial', NULL, N'mrgfactoryco@gmail.com', N'787-503-6100', 300, N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (414, N'commercial', N'Multy Medical Facilities CORP', NULL, NULL, NULL, N'commercial', NULL, N'jose.suarez@multymedical.com', NULL, 301, N'2026-05-22 16:33:41.1178105', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (415, N'commercial', N'Nampac', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-739-7401', 302, N'2026-05-22 16:33:41.1181245', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (416, N'commercial', N'National Engineering INC', NULL, NULL, NULL, N'engineering', NULL, N'nationalengineeringsales@gmail.com', N'787-795-0171', 303, N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (417, N'commercial', N'National Maintenance & Build Out Company', NULL, NULL, NULL, N'engineering', NULL, N'AR@NMBOC.COM', N'888-340-6900', 304, N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (418, N'commercial', N'National Park Service', NULL, NULL, NULL, N'commercial', NULL, N'anna_viego@nps.gov', N'(787) 729-6777', 305, N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (419, N'commercial', N'National Real Estate Management CORP', NULL, NULL, NULL, N'commercial', NULL, N'cesar.rivera4@gmail.com', N'314-787-5545', 306, N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (420, N'commercial', N'Native Energy & Technology INC', NULL, NULL, NULL, N'commercial', NULL, N'Luis.Rosado@native-energy.com', NULL, 307, N'2026-05-22 16:33:41.1198307', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (421, N'commercial', N'Newland Enterprises', NULL, NULL, NULL, N'commercial', NULL, N'jghuffman57@aol.com', N'1-417-859-5899', 308, N'2026-05-22 16:33:41.1198307', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (422, N'commercial', N'Normandie Hotel', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-729-3083', 309, N'2026-05-22 16:33:41.1198307', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (423, N'commercial', N'Novel Enterprises CORP', NULL, NULL, NULL, N'commercial', NULL, N'carlos.a.alvarado@novel-enterprises.com', N'787-432-7714', 310, N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (424, N'commercial', N'Novotech Dominicana', NULL, NULL, NULL, N'commercial', NULL, N'constantino.gonzalez@novotech.com.pr', NULL, 311, N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (425, N'commercial', N'NPS SER - South MABO', NULL, NULL, NULL, N'commercial', NULL, N'leonor_perez@nps.gov', NULL, 312, N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (426, N'commercial', N'O''Reilly Auto Parts', NULL, NULL, NULL, N'commercial', NULL, N'smcnally2@oreillyauto.com', NULL, 313, N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (427, N'commercial', N'OCM PR LLC', NULL, NULL, NULL, N'commercial', NULL, N'Jonathan.Padua@ocm-pr.com', N'662.695.3101', 314, N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (428, N'commercial', N'Ocyon Bio PR INC', NULL, NULL, NULL, N'commercial', NULL, N'ap@biosciencescorp.com', NULL, 315, N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (429, N'commercial', N'Omega Market Research CORP', NULL, NULL, NULL, N'commercial', NULL, N'jm@omegamr.com', NULL, 316, N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (430, N'commercial', N'ONE CONDADO LLC', NULL, NULL, NULL, N'commercial', NULL, N'jguerrero@creativedevelop.com', N'787-283-6969', 317, N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (431, N'commercial', N'Oneida Technical Solutions', NULL, NULL, NULL, N'commercial', NULL, N'e.cruz58@yahoo.com', N'787-830-1112', 318, N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (432, N'commercial', N'ONG Contractor INC', NULL, NULL, NULL, N'commercial', NULL, N'oortiz@ongpr.com', N'787-621-5641', 319, N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (433, N'commercial', N'OPHIRA CORP', NULL, NULL, NULL, N'commercial', NULL, N'ophira@ophiracorppr.com', NULL, 320, N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (434, N'commercial', N'Optima Contratista General', NULL, NULL, NULL, N'engineering', NULL, N'optimaid@prtc.net', N'787-287-1034', 321, N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (435, N'commercial', N'Orbitech CORP', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-704-2288', 322, N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (436, N'commercial', N'Oriental Bank', NULL, NULL, NULL, N'commercial', NULL, N'rosa.lopez@orientalbank.com', NULL, 323, N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (437, N'commercial', N'Orlando Carlo INC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-', 324, N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (438, N'commercial', N'Ortho Biologics', NULL, NULL, NULL, N'commercial', NULL, N'JRodrig2@its.jnj.com', NULL, 325, N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (439, N'commercial', N'OVERALL Contractors Group INC', NULL, NULL, NULL, N'commercial', NULL, N'j.ventura@overallcontractors.com', NULL, 326, N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (440, N'commercial', N'Pall Life Science PR LLC', NULL, NULL, NULL, N'commercial', NULL, N'cyt_vendor_invoice@cytiva.com', NULL, 327, N'2026-05-22 16:33:41.1258902', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (441, N'commercial', N'Patheon Puerto Rico INC', NULL, NULL, NULL, N'commercial', NULL, N'APscan.NAPatheon@cognizant.com', NULL, 328, N'2026-05-22 16:33:41.1258902', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (442, N'commercial', N'PAVARINI CONSTRUCTION & DEVELOPMENT INC', NULL, NULL, NULL, N'engineering', NULL, N'george@pavarinipr.com', N'(787)501-5505', 329, N'2026-05-22 16:33:41.1258902', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (443, N'commercial', N'Peerless Oil & Chemicals', NULL, NULL, NULL, N'commercial', NULL, N'APINVOICES@PEERLESSOIL.COM', NULL, 330, N'2026-05-22 16:33:41.1269256', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (444, N'commercial', N'Pegasus Trucking LLC', NULL, NULL, NULL, N'commercial', NULL, N'Lespinoza@fallasstores.com', N'310-617-8735', 331, N'2026-05-22 16:33:41.1272582', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (445, N'commercial', N'Pepsi Cola PR Distributing LL', NULL, NULL, NULL, N'commercial', NULL, N'cidra.accountspayable@pepsico.com, Dariana.Cordero@pepsico.com', N'787-739-8411 Ext.223', 332, N'2026-05-22 16:33:41.1272582', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (446, N'commercial', N'PF Consumer Healthcare B.V. PR Operations', NULL, NULL, NULL, N'commercial', NULL, N'gsk-consumer-NA@ironmountain.com', NULL, 333, N'2026-05-22 16:33:41.1272582', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (447, N'commercial', N'Pfizer Pharmaceuticals LLC', NULL, NULL, NULL, N'commercial', NULL, N'Gilberto.Inserni@pfizer.com', NULL, 334, N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (448, N'commercial', N'PFP100 Inspecciones Misc', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 335, N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (449, N'residential', NULL, NULL, N'Villafañe', NULL, N'individual', NULL, N'francesjvalentin@yahoo.com', NULL, 336, N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (450, N'residential', NULL, N'Plaza', N'Los Prados', NULL, N'individual', NULL, NULL, NULL, 337, N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (451, N'residential', NULL, N'Plaza', N'Matienzo', NULL, N'individual', NULL, NULL, NULL, 338, N'2026-05-22 16:33:41.1314456', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (452, N'commercial', N'Polymers International LTD', NULL, NULL, NULL, N'commercial', NULL, N'Jim.Pierson@polymersintl.com', N'1-242-352-3506', 339, N'2026-05-22 16:33:41.1314456', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (453, N'commercial', N'PONTIFICAL CATHOLIC UNIVERSITY', NULL, NULL, NULL, N'commercial', NULL, N'wicolon@pucpr.edu', N'787-841-2000', 340, N'2026-05-22 16:33:41.1314456', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (454, N'commercial', N'Powerhouse Retail Services', NULL, NULL, NULL, N'commercial', NULL, N'karla.alexander@powerhousenow.com', N'855-875-7436', 341, N'2026-05-22 16:33:41.1328280', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (455, N'commercial', N'PPC', NULL, NULL, NULL, N'commercial', NULL, N'afernandez@sconsultantsint.com', NULL, 342, N'2026-05-22 16:33:41.1334654', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (456, N'commercial', N'PPG Architectural Coatings PR INC', N'Cheryl McWhorter', N'Acct. Payable', NULL, N'commercial', NULL, N'ppg_ap@infostorerecords.com', NULL, 343, N'2026-05-22 16:33:41.1334654', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (457, N'commercial', N'PR HOSPITAL SUPPLY INC', NULL, NULL, NULL, N'commercial', NULL, N'eguilloty@primefire.us', N'787-622-5158', 344, N'2026-05-22 16:33:41.1334654', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (458, N'commercial', N'PR Maritime Group', NULL, NULL, NULL, N'commercial', NULL, N'jjimenez@pr-mar.com', NULL, 345, N'2026-05-22 16:33:41.1344219', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (459, N'commercial', N'Prime Fire Dominicana SRL', N'Jose Alberto', N'Rodriguez', NULL, N'commercial', NULL, N'edesueza@primefire.US', N'809-464-4653', 346, N'2026-05-22 16:33:41.1344219', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (460, N'commercial', N'PRIME FIRE LLC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 347, N'2026-05-22 16:33:41.1354855', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (461, N'commercial', N'Prime Fire Protection CORP', NULL, NULL, NULL, N'engineering', NULL, N'primefire@outlook.com', N'787-643-3660', 348, N'2026-05-22 16:33:41.1354855', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (462, N'commercial', N'Prime Services CORP', NULL, NULL, NULL, N'commercial', NULL, N'ehernandez@primefire.us', N'809-575-4300', 349, N'2026-05-22 16:33:41.1354855', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (463, N'commercial', N'Print 1 LLC', NULL, NULL, NULL, N'commercial', NULL, N'dcastro@print1pr.com', NULL, 350, N'2026-05-22 16:33:41.1364406', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (464, N'residential', NULL, N'Professional', N'Engineering Concepts', NULL, N'individual', NULL, N'marisol@pecprinc.com', NULL, 351, N'2026-05-22 16:33:41.1364406', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (465, N'commercial', N'Professional Facilties S.M.C', N'Miguel A. Cortez', N'Fernando Sumaza', NULL, N'commercial', NULL, N'miguel@mac-engineering.com', N'787-831-6030', 352, N'2026-05-22 16:33:41.1364406', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (466, N'commercial', N'ProHealth Infusion', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 353, N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (467, N'commercial', N'Project Engineering SP', NULL, NULL, NULL, N'engineering', NULL, N'carlos@proen.com', N'787-623-0008', 354, N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (468, N'commercial', N'Promech Mechanical', NULL, NULL, NULL, N'commercial', NULL, N'earroyo@promechpr.com', N'787-856-1414', 355, N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (469, N'commercial', N'PSC Misc 2014', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 356, N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (470, N'commercial', N'PSA Construction INC', N'William', N'Burgos', NULL, N'engineering', NULL, N'williamburgos69@gmail.com', N'787-557-1226', 357, N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (471, N'commercial', N'PSI Construction Co. INC', NULL, NULL, NULL, N'engineering', NULL, N'rsoler@psipuertorico.com', N'787-744-5810', 358, N'2026-05-22 16:33:49.1304003', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (472, N'commercial', N'Ralph''s Food Warehouse', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-733-0959', 359, N'2026-05-22 16:33:49.1311747', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (473, N'commercial', N'Range Developments', NULL, NULL, NULL, N'commercial', NULL, N'arodriguez@primefire.us', NULL, 360, N'2026-05-22 16:33:49.1317008', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (474, N'commercial', N'Rayos X Centro 4', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 361, N'2026-05-22 16:33:49.1320236', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (475, N'commercial', N'RC Professionals & Construction Service', N'Ramon', N'Correa Sanchez', NULL, N'engineering', NULL, N'rcconstructionpr@hotmail.com', N'787-260-1519', 362, N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (476, N'commercial', N'RC Specialties & Sheetmetal CORP', NULL, NULL, NULL, N'commercial', NULL, N'rcspecialtiessheetmetal@gmail.com', N'(787)842-6893', 363, N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (477, N'commercial', N'Reparto Industrial Barreras LLC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 364, N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (478, N'commercial', N'Reva Construction CORP', NULL, NULL, NULL, N'engineering', NULL, N'revaconstruction@gmail.com', N'787-828-3926', 365, N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (479, N'commercial', N'RF Management Solutions LL', N'Fernando', N'Santiago', NULL, N'commercial', NULL, N'fsantiago@fssurv.com', N'787-746-5039', 366, N'2026-05-22 16:33:49.1339377', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (480, N'commercial', N'RG Engineering INC', NULL, NULL, NULL, N'engineering', NULL, N'accounts.payable@rgepr.com', N'787-723-4623', 367, N'2026-05-22 16:33:49.1342507', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (481, N'commercial', N'RG Mechanical INC', NULL, NULL, NULL, N'commercial', NULL, N'rgmech@rgmech.com', N'787-821-1521', 368, N'2026-05-22 16:33:49.1342507', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (482, N'commercial', N'Rockwell Automation', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 369, N'2026-05-22 16:33:49.1342507', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (483, N'commercial', N'Roth Bros. INC', NULL, NULL, NULL, N'commercial', NULL, N'damaris.matos@citi.com', NULL, 370, N'2026-05-22 16:33:49.1342507', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (484, N'commercial', N'Royal Properties', NULL, NULL, NULL, N'commercial', NULL, N'royal@royalpropr.com', NULL, 371, N'2026-05-22 16:33:49.1359582', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (485, N'commercial', N'Royals Contractors INC', NULL, NULL, NULL, N'commercial', NULL, N'rci@royalsconstruction.com', N'(787) 675-7574', 372, N'2026-05-22 16:33:49.1367643', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (486, N'commercial', N'RR CONSTRUCTION', NULL, NULL, NULL, N'engineering', NULL, NULL, N'787-807-1529', 373, N'2026-05-22 16:33:49.1367643', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (487, N'commercial', N'RSEG CORP', NULL, NULL, NULL, N'commercial', NULL, N'contabilidad@rsegcorp.com', N'787-479-0965', 374, N'2026-05-22 16:33:49.1367643', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (488, N'commercial', N'SACHSE CONSTRUCTION', NULL, NULL, NULL, N'engineering', NULL, N'mstapleton@sachse.net', N'313-481-8200', 375, N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (489, N'commercial', N'Saint Luke''s Memorial Hospital INC', NULL, NULL, NULL, N'commercial', NULL, N'crystal.rivera@ssepr.org', NULL, 376, N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (490, N'commercial', N'SB Apartments INC', NULL, NULL, NULL, N'commercial', NULL, N'd.vila.zorrilla@gmail.com', N'787-502-3978', 377, N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (491, N'commercial', N'Schneider Electric', NULL, NULL, NULL, N'engineering', NULL, N'SE.MCS.PO@schneider-electric.com', N'787-865-4005', 378, N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (492, N'commercial', N'Seasons Construction LLC', NULL, NULL, NULL, N'engineering', NULL, N'jbueno@creativedevelop.com', N'787-733-8400', 379, N'2026-05-22 16:33:49.1394438', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (493, N'commercial', N'Serpa Fire Sprinkler', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 380, N'2026-05-22 16:33:49.1397607', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (494, N'commercial', N'Serralles Construction CORP', NULL, NULL, NULL, N'engineering', NULL, N'eddie@worksbyserralles.com', NULL, 381, N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (495, N'commercial', N'SG Construction & Management', NULL, NULL, NULL, N'engineering', NULL, NULL, N'787-727-6500', 382, N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (496, N'residential', NULL, N'SHARETECH', N'GROUP ENGINEERING PSC', NULL, N'individual', NULL, N'carlos.rodriguez@sharetechgroup.com', N'787-720-5869', 383, N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (497, N'commercial', N'Sheraton Puerto Rico Hotel & Casino', NULL, NULL, NULL, N'commercial', NULL, N'Hector.Ubior@sheraton.com', NULL, 384, N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (498, N'commercial', N'Sigari CORP', NULL, NULL, NULL, N'commercial', NULL, N'sigari@sigaricorp.com', N'(787) 313-3889', 385, N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (499, N'residential', NULL, N'Sigfrdo', N'Carrero', NULL, N'individual', NULL, NULL, NULL, 386, N'2026-05-22 16:33:49.1415830', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (500, N'commercial', N'Skalar Pharma LLC', NULL, NULL, NULL, N'commercial', NULL, N'kaura@skalarpharma.co', NULL, 387, N'2026-05-22 16:33:49.1420140', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (501, N'commercial', N'Skanska USA Building INC', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, 388, N'2026-05-22 16:33:49.1420140', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (502, N'commercial', N'SLSCO LTD', NULL, NULL, NULL, N'commercial', NULL, N'joserodriguez@slsco.com', N'787.200.7848', 389, N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (503, N'commercial', N'Smart Integrated Engineering Solutions', NULL, NULL, NULL, N'engineering', NULL, N'finance@smartengpr.com', NULL, 390, N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (504, N'residential', NULL, N'Sodexo', N'Citi', NULL, N'individual', NULL, N'CitiAPInbox.USA@sodexo.com', N'(787) 766-3765', 391, N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (505, N'residential', NULL, N'Sodexo', N'Pfizer Barceloneta', NULL, N'individual', NULL, N'Eric.Matson@sodexo.com', NULL, 392, N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (506, N'residential', NULL, N'Sodexo', N'Pfizer Guayama', NULL, N'individual', NULL, N'SodexoPfizerFMGuayamaAP.USA@sodexo.com', NULL, 393, N'2026-05-22 16:33:49.1440333', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (507, N'residential', NULL, N'South', N'Dade Air Conditioning', NULL, N'individual', NULL, N'lfigueroa@sdac8a.com', N'334-872-2228 x 108', 394, N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (508, N'commercial', N'St Jude Medical PR', NULL, NULL, NULL, N'commercial', NULL, N'jlopez03@sjm.com', N'787-650-1750', 395, N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (509, N'commercial', N'Stantec', N'Pedro', NULL, NULL, N'commercial', NULL, N'pedro.diaz@stantec.com', N'787-641-0879', 396, N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (510, N'commercial', N'Starmec Contractors INC', NULL, NULL, NULL, N'commercial', NULL, N'fmedina@starmecpr.com', N'787-852-8800', 397, N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (511, N'commercial', N'Stop Fire CORP', NULL, NULL, NULL, N'commercial', NULL, N'stopfirepr@gmail.com', N'787-690-3232', 398, N'2026-05-22 16:33:49.1460521', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (512, N'commercial', N'Supermercado Selectos Salinas', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 399, N'2026-05-22 16:33:49.1460521', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (513, N'commercial', N'Supermercados Econo', N'Jose', N'Serrano', NULL, N'commercial', NULL, N'jserrano@superecono.com', N'787-925-8900', 400, N'2026-05-22 16:33:49.1460521', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (514, N'commercial', N'Sustech LLC', NULL, NULL, NULL, N'commercial', NULL, N'oalquiza@sustechpr.com', NULL, 401, N'2026-05-22 16:33:49.1473669', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (515, N'commercial', N'Swedish Match Dominicana SAS', NULL, NULL, NULL, N'commercial', NULL, N'edesueza@primefire.us', N'809-575-4300', 402, N'2026-05-22 16:33:49.1476954', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (516, N'commercial', N'Swidish Match - Nevera', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 403, N'2026-05-22 16:33:49.1483956', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (517, N'commercial', N'SYNOVOS PUERTO RICO CORP', NULL, NULL, NULL, N'commercial', NULL, N'EINVOICING@SYNOVOS.COM', N'570-278-4040', 404, N'2026-05-22 16:33:49.1483956', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (518, N'commercial', N'Taller 06', NULL, NULL, NULL, N'commercial', NULL, N'taller06.info@gmail.com', N'787-998-8600', 405, N'2026-05-22 16:33:49.1492325', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (519, N'commercial', N'TCG The Cornerstone Group INC', N'Lillian', N'Connor', NULL, N'commercial', NULL, NULL, N'787-890-3784', 406, N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (520, N'commercial', N'TCM Group LLC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 407, N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (521, N'commercial', N'Technical Distributors INC', NULL, NULL, NULL, N'commercial', NULL, N'betty@tech-dist.com', N'787-274-1818', 408, N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (522, N'commercial', N'Teksol Integration Group INC', NULL, NULL, NULL, N'commercial', NULL, N'purchases@teksolpr.com', N'787-652-4225', 409, N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (523, N'commercial', N'Terrasol Engineering Group LLC', NULL, NULL, NULL, N'engineering', NULL, N'jaltreche@terrasolpr.com', N'787-692-1100', 410, N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (524, N'commercial', N'Teva Puerto Rico LLC', NULL, NULL, NULL, N'commercial', NULL, N'fajardo.ap@actavis.com', NULL, 411, N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (525, N'commercial', N'The Lofts 2014', NULL, NULL, NULL, N'commercial', NULL, N'thelofts2014@gmail.com', N'787-396-20234', 412, N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (526, N'residential', NULL, N'The', N'Reliable Sprinkler Co', NULL, N'individual', NULL, N'mnieves@reliablesprinkler.com', NULL, 413, N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (527, N'commercial', N'The Sembler Company', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-745-4805', 414, N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (528, N'commercial', N'TOPS Enterprises CORP', NULL, NULL, NULL, N'commercial', NULL, N't_olmo@topsenterprises.com', N'787 789 9198', 415, N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (529, N'commercial', N'TURTLE & HUGHES INC', NULL, NULL, NULL, N'commercial', NULL, N'accountspayable@turtle.com', NULL, 416, N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (530, N'commercial', N'TV Educational Park Management', NULL, NULL, NULL, N'commercial', NULL, N'mortiz@toroverdepdc.com', NULL, 417, N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (531, N'commercial', N'Unimec INC', NULL, NULL, NULL, N'commercial', NULL, N'ruisanchez@unimecpr.com', N'787-585-9585', 418, N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (532, N'commercial', N'Universidad Ana G. Méndez', NULL, NULL, NULL, N'commercial', NULL, N'eguilloty@primefire.us', NULL, 419, N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (533, N'commercial', N'Universidad Interamericana INC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'787-766-1912', 420, N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (534, N'commercial', N'VA Caribbean Healthcare System', N'Nestor', N'Rivera', NULL, N'commercial', NULL, N'francisco.rivera-davila@va.gov', N'787-641-7582', 421, N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (535, N'commercial', N'VE Electrical Group INC', NULL, NULL, NULL, N'engineering', NULL, N'electricalgroup@gmail.com', N'787-689-2657', 422, N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (536, N'commercial', N'Venergy Group LLC', NULL, NULL, NULL, N'commercial', NULL, N'dserrano@venergygroup.com', N'(772) 468-0053', 423, N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (537, N'commercial', N'Viatris Pharmaceuticals LLC', NULL, NULL, NULL, N'commercial', NULL, N'PRI.AP@viatris.com', NULL, 424, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (538, N'commercial', N'Vidre Energias INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 425, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (539, N'commercial', N'Villavicencio & Associates Construction', NULL, NULL, NULL, N'engineering', NULL, N'accounting@va-contractor.com', NULL, 426, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (540, N'commercial', N'Water Based Fire Protection', NULL, NULL, NULL, N'engineering', NULL, NULL, N'787-286-2087', 427, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (541, N'commercial', N'West Fire & Safety Equipment', NULL, NULL, NULL, N'commercial', NULL, N'victorvillarubia@gmail.com', N'787-868-1589', 428, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (542, N'residential', NULL, N'Windsor', N'Fashion', NULL, N'individual', NULL, N'eloyl@windsorstore.com', N'562-561-7694', 429, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (543, N'commercial', N'Wovenware', NULL, NULL, NULL, N'commercial', NULL, N'bumpierre@wovenware.com', NULL, 430, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (544, N'commercial', N'Yang Enterprises INC', NULL, NULL, NULL, N'commercial', NULL, N'ap@yangenterprises.com', NULL, 431, N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (545, N'commercial', N'Yonkers Industries INC', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 432, N'2026-05-22 16:33:49.1579073', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (546, N'residential', NULL, N'Yumac', N'Home Furniture', NULL, N'individual', NULL, NULL, N'(787) 820-6811', 433, N'2026-05-22 16:33:49.1579073', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (547, N'commercial', N'Renaissance-Jaragua Hotel & Casino', N'Huascar', N'Soto', NULL, N'commercial', NULL, N'HUASCAR.SOTO@RENAISSANCEHOTELS.COM', NULL, 434, N'2026-05-22 16:33:55.7486604', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (548, N'commercial', N'SYSTEMIO, SRL', N'Milka', N'Carvajal', NULL, N'commercial', NULL, N'mcarvajal@systemiord.com', N'809-332-1202', 435, N'2026-05-22 16:33:55.7486604', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (549, N'commercial', N'Vendomática Dominicana, SRL', N'Carlos', N'Olivero', NULL, N'commercial', NULL, NULL, NULL, 436, N'2026-05-22 16:33:55.7492586', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (550, N'commercial', N'ICONELSA, SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 437, N'2026-05-22 16:33:55.7492586', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (551, N'commercial', N'GILDAN DR', N'Keyme', N'Cuevas', NULL, N'commercial', NULL, N'kcuevas@gildan.com', NULL, 438, N'2026-05-22 16:33:55.7492586', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (552, N'commercial', N'Prime Services, Corp', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 439, N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (553, N'commercial', N'Prime Fire Protection Corp', NULL, NULL, NULL, N'engineering', NULL, NULL, NULL, 440, N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (554, N'commercial', N'Prime Fire Dominicana SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 441, N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (555, N'commercial', N'Pisan Electronic & Asoc., S.R.L', NULL, NULL, NULL, N'commercial', NULL, N'Infopisan.elec@gmail.com', NULL, 442, N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (556, N'commercial', N'Compañia Dominicana de Teléfono,S.A', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 443, N'2026-05-22 16:33:55.7522568', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (557, N'commercial', N'Cristian Data Service CDS, SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 444, N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (558, N'residential', NULL, N'RAFAEL', N'ANTONIO ACEVEDO MARTE', NULL, N'individual', NULL, N'rafaelacevedo_m@outlook.com', NULL, 445, N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (559, N'commercial', N'Care Fusion D.R. 203 LTD', N'Pedro', N'Guillen', NULL, N'commercial', NULL, N'Luciana.medrano.cuello@bd.com', N'(809) 549 - 2222', 446, N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (560, N'commercial', N'CHT HOLDINGS DOMINICANA SAS', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 447, N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (561, N'commercial', N'MP Servicio, SRL', N'José', N'Peguero', NULL, N'commercial', NULL, N'mpservicio@claro.net.do', N'809-533-9961', 448, N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (562, N'commercial', N'Inversiones Terrassa, SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 449, N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (563, N'commercial', N'Twenty-One Technology EIRL', N'Robert Richard', N'Rodriguez', NULL, N'commercial', NULL, NULL, N'(809) 653-7501', 450, N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (564, N'commercial', N'Frito Lay Dominicana,S.A', N'Victor', N'Inoa', NULL, N'commercial', NULL, N'RUT.LORENZO.Contractor@pepsico.com', N'829-257-6938', 451, N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (565, N'residential', NULL, N'Carlos', N'J. Benitez De Jesus', NULL, N'individual', NULL, N'benitefire74@gmail.com', NULL, 452, N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (566, N'commercial', N'Weir Minerals Caribe, SRL', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 453, N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (567, N'commercial', N'MRJ Multiservices Solutions', NULL, NULL, NULL, N'commercial', NULL, N'contabilidad@grupomrj.com', NULL, 454, N'2026-05-22 16:33:55.7564442', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (568, N'residential', NULL, N'Jesus', N'Almonte', NULL, N'individual', NULL, N'anibalelfuelte1.7@hotmail.com', NULL, 455, N'2026-05-22 16:33:55.7564442', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (569, N'commercial', N'SAEG Engineering Group, SA', NULL, NULL, NULL, N'engineering', NULL, NULL, N'(809) 540-7234', 456, N'2026-05-22 16:33:55.7564442', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (570, N'commercial', N'Puerto del Rey Boat Specialists', N'Ernesto', N'Villanueva', NULL, N'commercial', NULL, NULL, NULL, 457, N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (571, N'commercial', N'Induveca, S.A', NULL, NULL, NULL, N'commercial', NULL, N'William.acosta@induveca.com.do', N'(809) 737-2500', 458, N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (572, N'commercial', N'Getinge Dominican Republic, S.A', NULL, NULL, NULL, N'commercial', NULL, N'joaquin.peignand@getinge.com', N'(829) 204-0067', 459, N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (573, N'commercial', N'ClickTeck, SRL', N'Jose', N'Beltre', NULL, N'commercial', NULL, N'jbeltre@clickteckrd.com', N'(809) 567-1916', 460, N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (574, N'commercial', N'Prime Fire LLC', NULL, NULL, NULL, N'commercial', NULL, NULL, N'512-262-6110', 461, N'2026-05-22 16:33:55.7584643', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (575, N'commercial', N'FirePro', N'Erodia', N'Bertre', NULL, N'commercial', NULL, N'ebertre@fireprord.com', N'(809) 508-1059', 462, N'2026-05-22 16:33:55.7584643', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (576, N'commercial', N'Constructora Jimbrosa, SRL', N'Juana', N'Tapia', NULL, N'engineering', NULL, N'operaciones@rdpalmar.com', N'(809) 794-7331', 463, N'2026-05-22 16:33:55.7584643', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (577, N'commercial', N'Reservas del PalmarDR SRL', N'Juana', N'Tapia', NULL, N'commercial', NULL, N'Operaciones@rdpalmar.com', N'(809) 794-7331', 464, N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (578, N'commercial', N'Dirección General de Impuestos Internos', NULL, NULL, NULL, N'commercial', NULL, NULL, N'(809) 689-2181', 465, N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (579, N'commercial', N'IGT', N'Beatriz', N'Rey', NULL, N'commercial', NULL, N'Beatriz.Rey@IGT.com', N'809 489 2538', 466, N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (580, N'commercial', N'Engineering & Fire Service, SRL', N'Edward', N'Brito', NULL, N'engineering', NULL, NULL, N'(809) 683-8016', 467, N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (581, N'commercial', N'CASA NADER, C por A', N'Angel', N'Nadel', NULL, N'commercial', NULL, NULL, NULL, 468, N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (582, N'commercial', N'Swisher Dominicana Inc', N'Rafael', N'Perez', NULL, N'commercial', NULL, N'ypena@swisherdominicana.com', NULL, 469, N'2026-05-22 16:33:55.7604849', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (583, N'commercial', N'Fire Technologies, S.R.L', NULL, NULL, NULL, N'commercial', NULL, NULL, NULL, 470, N'2026-05-22 16:33:55.7604849', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (584, N'commercial', N'Inversiones Omega, SRL', N'Samuel', N'Beato', NULL, N'commercial', NULL, NULL, NULL, 471, N'2026-05-22 16:33:55.7604849', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (585, N'commercial', N'General Cigars Dominicana, S.A.S', N'Jorge', N'Nuñez', NULL, N'commercial', NULL, N'jorge.nunez@st-group.com', N'(809) 226-2500', 472, N'2026-05-22 16:33:55.7615405', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (586, N'commercial', N'Los Orígenes Power Plant, S.R.L', N'Julio', N'Lockhart', NULL, N'commercial', NULL, N'j.lockhart@losorigenes.com.do', N'809-852-8333', 473, N'2026-05-22 16:33:55.7621621', NULL, 27)
INSERT [dbo].[customers] ([customer_id], [customer_type], [company_name], [first_name], [last_name], [additional_name], [market], [dtd_potential], [primary_email], [primary_phone], [primary_address_id], [created_at], [updated_at], [created_by]) VALUES (587, N'commercial', N'Rockwell Automation Technologies Inc', N'Pedro', N'Bona', NULL, N'commercial', NULL, N'p.bona@a.rockwell.com', NULL, 474, N'2026-05-22 16:33:55.7621621', NULL, 27)

SET IDENTITY_INSERT [dbo].[customers] OFF
GO


-- Data for customer_alternate_contacts (1 records)
SET IDENTITY_INSERT [dbo].[customer_alternate_contacts] ON
GO

INSERT [dbo].[customer_alternate_contacts] ([customer_alternate_contact_id], [customer_id], [name], [email], [phone], [created_at], [updated_at]) VALUES (1, 1, N'Roel Villanueva', N'roel.villanueva@demo.com', NULL, N'2026-02-19 16:30:38.0000000', NULL)

SET IDENTITY_INSERT [dbo].[customer_alternate_contacts] OFF
GO


-- customer_attachments: No data to insert


-- Data for customer_notes (578 records)
SET IDENTITY_INSERT [dbo].[customer_notes] ON
GO

INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (1, 1, N'Demo', N'2026-02-19 16:30:34.0000000', NULL, 21)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (2, 2, N'RNC: 130-86136-6 | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: GEMPRO- General Electromechanical Project | Bill To: GEMPRO- General Electromechanical Project; RNC: 130-86136-6; C. Rafael Augusto Sánchez 92,; Santo Domingo, Rep. Dom. 10129 | Ship To: GEMPRO- General Electromechanical Project; RNC: 130-86136-6; C. Rafael Augusto Sánchez 92,; Santo Domingo, Rep. Dom. 10129', N'2026-05-22 16:32:44.9241181', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (3, 3, N'RNC: 131-20780-4 | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: TALBOT LIMITED | Bill To: TALBOT LIMITED; RNC: 131-20780-4; Dir: Emilio A. Morel #15; Ensance La Fe; Santo Domingo, Rep. Dom. | Ship To: TALBOT LIMITED; RNC: 131-20780-4; Dir: Emilio A. Morel #15; Ensance, La Fe; Santo Domingo, Rep. Dom.', N'2026-05-22 16:32:44.9281446', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (4, 4, N'RNC: 133-20222-2 | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 3 | Original Customer field: Conecta Mer SRL. | Bill To: CONECTA MER SRL; RNC: 133-20222-2; DIR CASIMIRO DE MOYA; EDIF. E, APTO 102 GAZCUE; REPUBLICA DOMINICANA', N'2026-05-22 16:32:44.9281446', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (5, 5, N'Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Hotel JW Marriott | Bill To: Hotel JW Marriott; Ave. Wiston Churchill no. 53; Santo Domingo, República Dominicana; Phone: (809) 807-1717 | Ship To: Hotel JW Marriott; Ave. Wiston Churchill no. 53; Santo Domingo, República Dominicana; Phone: (809) 807-1717', N'2026-05-22 16:32:44.9285114', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (6, 6, N'RNC: 102-32476-1 | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 4 | Original Customer field: ABI KARRAM MORILLA INGENIEROS ARQUITECTOS | Bill To: ABI KARRAM MORILLA INGENIEROS ARQUITECTOS; RNC: 102-32476-1; Calle Pablo Pumarol 14, Santo Domingo,; TEl.: (809) 747-6836; E-mail: m.shu@amina.com.do', N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (7, 7, N'RNC: 101-77091-2 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Grupo de Inversiones Lunar S.R.L. | Bill To: Grupo de Inversiones Lunar S.R.L.; RNC: 101-77091-2; Playa Arena Gorda,; Carr. El Macao-Arena Gorda; La Altagracia, República Dominicana | Ship To: Grupo de Inversiones Lunar S.R.L.; RNC: 101-77091-2; Playa Arena Gorda,; Carr. El Macao-Arena Gorda; La Altagracia, República Domini', N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (8, 8, N'RNC: 132-81733-8 | Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: NON-TAXED | Sub-jobs in source: 4 | Original Customer field: Eastern Developers Investment S.A.S. | Bill To: Eastern Developers Investment S.A.S.; Domicilio Social Av. Abraham Lincoln #960; Paraiso, D.N.; RNC: 132-81733-8; Tel: 809-959-2714 | Ship To: Eastern Developers Investment S.A.S.; Domicilio Social Av. Abraham Lincoln #960; Paraiso, D.N.; RNC: 132-81733-8; Tel: 809-959-2714', N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (9, 9, N'Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Certified Fire Protection Certifire SRL | Bill To: Certified Fire Protection Certifire SRL; Santo Domingo, DN,; República Dominicana; Tel: +1 (809) 924 -1333 | Ship To: Certified Fire Protection Certifire SRL; Santo Domingo, DN,; República Dominicana; Tel: +1 (809) 924 -1333', N'2026-05-22 16:32:44.9289325', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (10, 10, N'Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Wyndham Garden by Super 8 | Bill To: Wyndham Garden by Super 8; Aut. Duarte KM 1.8, Montecristi,; República Dominicana; Tel: (809) 733-8257 | Ship To: Wyndham Garden by Super 8; Aut. Duarte KM 1.8, Montecristi,; República Dominicana; Tel: (809) 733-8257', N'2026-05-22 16:32:44.9301539', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (11, 11, N'Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: Quantum CCS. | Bill To: Quantum CCS; (Consultoría Compras y Servicios); Avda. George Washington 500; Hilton Santo Domingo; Tel: +1 (809) 412-5034 | Ship To: Quantum CCS; (Consultoría Compras y Servicios); Avda. George Washington 500; Hilton Santo Domingo; Tel: +1 (809) 412-5034', N'2026-05-22 16:32:44.9305318', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (12, 12, N'RNC: 133-39150-3 | Currency: USD | Tax Item: Tax | Prefix: LITHIUM OPTIMIZACION DE PROCESOS INDUSTR" | Original Customer field: LITHIUM OPTIMIZACION DE PROCESOS INDUSTR | Bill To: LITHIUM OPTIMIZACION DE PROCESOS; INDUSTRIALES SRL; RNC: 133-39150-3; Bonao, Rep. Dom | Ship To: LITHIUM OPTIMIZACION DE PROCESOS; INDUSTRIALES SRL; RNC: 133-39150-3; Bonao, Rep. Dom.', N'2026-05-22 16:32:44.9309480', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (13, 13, N'RNC: 101-09214-9 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 4 | Original Customer field: Corporación Aeroportuaria Del Este S.A.S. | Bill To: Corporación Aeroportuaria Del Este S.A.S.; Av. Abraham Lincoln #960, Santo Domingo; RNC: 101-09214-9; Tel: 809-959-2376', N'2026-05-22 16:32:44.9309480', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (14, 14, N'Address note: [extra] Teléfono (809) 901-4648 | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: AC Hotel Santiago | Bill To: AC Hotel Santiago; C. Del Sol 32-34,; Santiago de los Caballeros,; Rep. Dom.; Teléfono (809) 901-4648 | Ship To: AC Hotel Santiago; C. Del Sol 32-34,; Santiago de los Caballeros,; Rep. Dom.; Teléfono (809) 901-4648', N'2026-05-22 16:32:44.9309480', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (15, 15, N'RNC: 1-01-60246-5 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Super Mercado Bravo Winston Churchill | Bill To: Super Mercado Bravo Winston Churchill; RNC: 1-01-60246-5; Av. Winston Churchill 1452,; Santo Domingo, Rep. Dom. | Ship To: Super Mercado Bravo Winston Churchill; RNC: 1-01-60246-5; Av. Winston Churchill 1452,; Santo Domingo, Rep. Dom.', N'2026-05-22 16:32:44.9321656', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (16, 16, N'RNC: 1-33-26275-4 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: SAHDALA JORGE INGENIERIA S.R.L | Bill To: SAHDALA JORGE INGENIERIA S.R.L.; RNC: 1-33-26275-4; Calle del Sol No. 51, Centro de la Ciudad; Santiago, Rep. Dom; Tel: (829) 341-4336', N'2026-05-22 16:32:44.9321656', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (17, 17, N'RNC: 101-73611-9 | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Mr | Sub-jobs in source: 2 | Original Customer field: Piarcon SRL | Bill To: Piarcon SRL; RNC: 101-73611-9; C. Francisco Prats Ramírez 877,; Santo Domingo, Rep. Dom. | Ship To: Piarcon SRL; RNC: 101-73611-9; C. Francisco Prats Ramírez 877,; Santo Domingo, Rep. Dom.', N'2026-05-22 16:32:44.9325562', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (18, 18, N'RNC: 132-452951 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 3 | Original Customer field: Atlambar Management S.A.S | Bill To: Atlambar Management S.A.S; RNC: 132-452951; Av. Winston Churchill, Esq. Gustavo Mejia; Torre Blue Mall, Piso 23; 809-770-0076', N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (19, 19, N'RNC: 130799997 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: INGYOSA Ingeneira EIRL | Bill To: Ingyosa Ingenieria EIRL; RNC: 130799997; Calle Estado de Israel, Plaza Centro del; Reparto del Este, Santiago, R.D.; Tel. 8092762013', N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (20, 20, N'RNC: 1-11-15719-6 | Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: Celso Cabrera & Asociados SRL | Bill To: Celso Cabrera & Asociados SRL (TRANCELCA); RNC: 1-11-15719-6; Carr. Ramón Santana Proyecto Esperanza; Ingenio Santa Fe, San Pedro de Macorís; Rep. Dom | Ship To: Celso Cabrera & Asociados SRL (TRANCELCA); RNC: 1-11-15719-6; Carr. Ramón Santana Proyecto Esperanza; Ingenio Santa Fe, San Pedro de Macorís; Rep. Dom.', N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (21, 21, N'RNC: 101004843 | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: METALDOM | Bill To: METALDOM SA; RNC:101004843; Autopista Duar Km. 22 1/2; Parque industrial  Duarte.; Tel: (809) 568-2270, Santo Domingo R.D | Ship To: METALDOM SA; RNC:101004843; Autopista Duar Km. 22 1/2; Parque industrial  Duarte.; Tel: (809) 568-2270, Santo Domingo, R.D.', N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (22, 22, N'RNC: 131144691 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Mr | Original Customer field: Ingeniería Domingo Montás SRL | Bill To: Ingeniería Domingo Montás SRL; RNC: 131144691; Pueblo Nuevo, San Cristóbal; Rep. Dom. | Ship To: Ingeniería Domingo Montás SRL; RNC: 131144691; Pueblo Nuevo, San Cristóbal; Rep. Dom.', N'2026-05-22 16:32:44.9329657', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (23, 23, N'RNC: 132577299 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: G2EL SRL | Bill To: G2EL; RNC: 132577299; Santiago de Los Caballeros; Rep. Dom. | Ship To: G2EL; RNC: 132577299; Santiago de Los Caballeros; Rep. Dom.', N'2026-05-22 16:32:44.9341750', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (24, 24, N'RNC: 10167181-5 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Contratistas Civiles y Mecánicos | Bill To: Contratistas Civiles y Mecánicos (CCM); RNC: 10167181-5; Av 27 de Febrero 1760, Alameda; Santo Domingo, Rep. Dom.; +1 (809) 372 2474 | Ship To: Contratistas Civiles y Mecánicos (CCM); RNC: 10167181-5; Av 27 de Febrero 1760, Alameda; Santo Domingo, Rep. Dom.; +1 (809) 372-2474', N'2026-05-22 16:32:44.9345752', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (25, 25, N'Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: Jefe de Seguridad | Prefix: Mr | Sub-jobs in source: 3 | Original Customer field: Hotel Sheraton Santo Domingo | Bill To: Hotel Sheraton Santo Domingo; 365 George Washington Avenue; Santo Domingo; Dominican Republic, 10205 | Ship To: Hotel Sheraton Santo Domingo; 365 George Washington Avenue; Santo Domingo; Dominican Republic, 10205', N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (26, 26, N'RNC: 131-51648-3 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: Hotel Discovery. | Bill To: Hotel Discovery; No. 402, C/ Arzobispo Nouel, Santo Doming; RNC: 131-51648-3; Renzo Saavedra; 829-660-5186', N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (27, 27, N'RNC: 132-04557-2 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Mr | Original Customer field: Ingemati SRL | Bill To: Ingemati SRL; RNC: 132-04557-2; Tel: (829) 209-8186; mario@ingemati.com | Ship To: Ingemati SRL; RNC: 132-04557-2; Tel: (829) 209-8186; mario@ingemati.com', N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (28, 28, N'RNC: 132136063 | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Vemp Design Solutions | Bill To: Vemp Design Solutions; RNC: 132136063; Calle César A. Canó #32; Santo Domingo; Rep. Dom. | Ship To: Vemp Design Solutions; RNC: 132136063; Calle César A. Canó #32; Santo Domingo; Rep. Dom.', N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (29, 29, N'Address note: [extra] Rep. Dom | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: MercaSID | Bill To: MercaSID; Av. Máximo Gómez, Esq.; Pedro Livio Cedeño,; DN, Santo Domingo; Rep. Dom | Ship To: MercaSID; Av. Máximo Gómez, Esq.; Pedro Livio Cedeño,; DN, Santo Domingo; Rep. Dom', N'2026-05-22 16:32:44.9349864', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (30, 30, N'Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Ing. | Original Customer field: Laesa LTD | Bill To: Laesa LTD; Av. Sarasota 20,; Santo Domingo 10109; Rep. Dom.', N'2026-05-22 16:32:44.9361856', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (31, 31, N'Address note: [extra] Rep. Dom. | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Ing. | Original Customer field: Big Brothers Company | Bill To: Big Brothers Company; Calle 3ra NO.19; Edificio R,; El Millón, D.N.; Rep. Dom. | Ship To: Laesa Limited; Av. Sarasota #20; Torre Empresarial Aird, 8vo Piso; La Julia, Santo Domingo; Rep. Dom', N'2026-05-22 16:32:44.9361856', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (32, 32, N'Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: RK Power. | Bill To: RK Power; C. Francisco del Rosario Sánchez; San Pedro De Macorís 21000; Rep. Dom. | Ship To: RK Power; C. Francisco del Rosario Sánchez; San Pedro De Macorís 21000; Rep. Dom.', N'2026-05-22 16:32:44.9365933', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (33, 33, N'RNC: 102-32363-1 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Mr | Original Customer field: Contratistas Eléctricos de Santiago SRL | Bill To: Contratistas Eléctricos de Santiago SRL; RNC: 102-32363-1; Roberto Pastoriza 15, Santiago de los Cab', N'2026-05-22 16:32:44.9370069', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (34, 34, N'Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Sub-jobs in source: 7 | Original Customer field: Grupo Punta Cana | Bill To: Grupo Punta Cana; •Contact: Orlando Javier; •E-mail: ojavier@puntacana.com; Av. Abraham Lincoln 960; DN, Sannto Domingo 11202 | Ship To: Grupo Punta Cana; •Contact: Orlando Javier; •E-mail: ojavier@puntacana.com; Av. Abraham Lincoln 960; DN, Sannto Domingo 11202', N'2026-05-22 16:32:44.9370069', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (35, 35, N'RNC: 101-50311-4 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: ALARM CONTROLS SEGURIDAD SAS | Bill To: WARECOMM; Av. John F. Kennedy, Distrito Nacional; RNC: 101-50311-4; Tel: 809-537-9577; Martin Calderon - mcalderon@warecomm.net', N'2026-05-22 16:32:44.9370069', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (36, 36, N'RNC: 130-43509-1 | Terms: Net 30 | Currency: USD | Tax Code: Non | Sub-jobs in source: 52 | Original Customer field: Swedish Match Dominicana, S.A.S.:PFD19-02 | Bill To: Swedish Match Dominicana, S.A.S.; RNC: 130-43509-1; Ext. III Zona Franca Industrial; Santiago, República Dominicana; (809) 575 - 4300 | Ship To: HW CARGO & CUSTOM S.R.L.; C/O PRIME FIRE LLC; 8400 NW 25 ST SUITE 100; DORAL FL 33198', N'2026-05-22 16:32:44.9381949', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (37, 37, N'RNC: 131-85119-3 | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 5 | Original Customer field: Design & Build by Javier Rafel SRL | Bill To: Design & Build by Javier Rafel SRL; RNC: 131-85119-3; Calle Capitán Eugenio de Marchena 22La Es; Santo Domingo, RD. | Ship To: Design & Build by Javier Rafel SRL; RNC: 131-85119-3; Calle Capitán Eugenio de Marchena 22La Es; Santo Domingo, RD.', N'2026-05-22 16:32:44.9390318', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (38, 38, N'RNC: 1-31-07642-4 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Ing. | Original Customer field: MeraFondeur Ingenieria y Proyectos | Bill To: MeraFondeur Ingenieria y Proyectos; RNC 1-31-07642-4; Urb. Los Rosales, Santiago, Rep, Dominica; Tel. 809-769-8061', N'2026-05-22 16:32:44.9397729', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (39, 39, N'RNC: 102614423 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Ing. | Sub-jobs in source: 4 | Original Customer field: Panaderia Pasteleria Lumijor SRL | Bill To: Panaderia Pasteleria Lumijor SRL; RNC: 102614423; Av. Rafael Vidal, El Embrujo I, Santago,; Rep. Dominicana; 809-233-3434/35', N'2026-05-22 16:32:44.9406416', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (40, 40, N'RNC: 101-60433-6 | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: InciFire SRL | Bill To: InciIFire SRL; Calle Espiritu Santo No. 2,; Sector Gala, Santo Domingo, RD; RNC: 101-60433-6', N'2026-05-22 16:32:44.9409633', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (41, 41, N'Terms: Contra entrega | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Ing. | Original Customer field: Casa de Campo Resort & Villas | Bill To: Casa de Campo Resort & Villas; Autopista Higuey, La Romana,; República Domicana; Tel. (809) 523 - 3142', N'2026-05-22 16:32:44.9409633', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (42, 42, N'Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 5 | Original Customer field: Sems:PFD23-10 | Bill To: Sems (Ingeniería y Consultoría); Calle 14 No. 16 A, Ensanche Julieta,;  Santo Domingo, Rep. Dominicana; 809-683-6655; info@semsrd.com', N'2026-05-22 16:32:44.9419662', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (43, 43, N'Tax: Non | Bill To: Adjustment 12-31-16', N'2026-05-22 16:32:54.7099498', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (44, 44, N'Terms: Due on receipt | Sub-jobs: 2 | Bill To: Advance Marine Solutions', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (45, 45, N'Tax: Non | Bill To: Ajuste CPA', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (46, 46, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Amec Foster Wheeler E&C Services, Inc.', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (47, 47, N'Terms: Due on receipt | Tax: Non | Bill To: Antonio Roig Sucesores, Inc.', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (48, 48, N'Terms: Due on receipt | Tax: Non | Bill To: Apex Mechanical Corp.', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (49, 49, N'Terms: Net 30 | Balance: 0, Total: 25170 | Sub-jobs: 4 | Bill To: ASI Mechanical, LLC.', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (50, 50, N'Terms: Net 30 | Tax: Non | Bill To: Asociación de Garantías de Seguros Misc.', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (51, 51, N'Tax: Non | Bill To: AUDIT', N'2026-05-22 16:32:54.7105650', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (52, 52, N'Tax: Non | Bill To: Audit 2018', N'2026-05-22 16:32:54.7119574', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (53, 53, N'Tax: Non', N'2026-05-22 16:32:54.7119574', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (54, 54, N'Terms: Due on receipt | Tax: Non | Bill To: B Boutique', N'2026-05-22 16:32:54.7119574', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (55, 55, N'Tax: Non', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (56, 56, N'Terms: Due on receipt | Tax: Non | Balance: 260, Total: 260 | Bill To: Bayamón Endodontics', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (57, 57, N'Terms: Due on receipt | Tax: Non | Bill To: Bermary Velázquez', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (58, 58, N'Tax: Non | Bill To: BMS12-16', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (59, 59, N'Tax: Non | Bill To: Building Improvement 2015', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (60, 60, N'Bill To: Building Improvement 2016', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (61, 61, N'Terms: Net 30 | Tax: Non | Bill To: Casa BACARDÍ Puerto Rico', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (62, 62, N'Terms: Due on receipt | Tax: Non | Bill To: CCS LLC', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (63, 63, N'Tax: Non', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (64, 64, N'Terms: Due on receipt | Tax: Non | Bill To: CEL Fire', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (65, 65, N'Terms: Due on receipt | Tax: Non | Bill To: CONDOMINIO BLUE', N'2026-05-22 16:32:54.7124267', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (66, 66, N'Tax: Non | Bill To: Condominio Bosque del Río', N'2026-05-22 16:32:54.7139672', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (67, 67, N'Terms: Net 30 | Tax: Non | Balance: 28.8, Total: 28.8 | Sub-jobs: 2 | Bill To: Condominio Santa María', N'2026-05-22 16:32:54.7139672', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (68, 68, N'Terms: Due on receipt | Tax: Non | Bill To: Costco Wholesale Logistics', N'2026-05-22 16:32:54.7139672', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (69, 69, N'Terms: Due on receipt | Tax: Non | Bill To: CR Construction', N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (70, 70, N'Terms: Due on receipt | Tax: Non | Bill To: Cruz Fire Protection', N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (71, 71, N'Tax: Non | Balance: 10852.9, Total: 10852.9 | Bill To: Cuadre 2021 - Update', N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (72, 72, N'Terms: Due on receipt | Tax: Non | Bill To: Divisions Maintenance Group', N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (73, 73, N'Tax: Non | Balance: 1, Total: 1 | Bill To: Dommie', N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (74, 74, N'Terms: Due on receipt | Tax: Non | Bill To: El Arca Infantil, Inc.', N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (75, 75, N'Tax: Non', N'2026-05-22 16:32:54.7144445', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (76, 76, N'Terms: Due on receipt | Tax: Non | Bill To: Eng. Blair White', N'2026-05-22 16:32:54.7155375', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (77, 77, N'Terms: Net 30 | Bill To: Eng. Jorge E Perez Ruiz, PE', N'2026-05-22 16:32:54.7155375', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (78, 78, N'Terms: Net 30 | Tax: Non', N'2026-05-22 16:32:54.7159831', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (79, 79, N'Terms: Due on receipt | Tax: Non | Bill To: Fire Mechanical Service', N'2026-05-22 16:32:54.7159831', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (80, 80, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Fundación Luis Muñoz Marín', N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (81, 81, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Gallery Plaza', N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (82, 82, N'Bill To: Gastos Robo', N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (83, 83, N'Terms: Due on receipt | Tax: Non | Bill To: GB Project Management, LLC', N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (84, 84, N'Terms: Due on receipt | Tax: Non | Bill To: GJ FIRE BURGLARY EQUIPMENT INC.', N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (85, 85, N'Terms: Due on receipt | Tax: Non | Bill To: Gorgas Security Group', N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (86, 86, N'Terms: Due on receipt | Tax: Non | Bill To: Hogar Ciudad Dorada', N'2026-05-22 16:32:54.7164631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (87, 88, N'Bill To: Hornblower Ferries Ceiba', N'2026-05-22 16:32:54.7179941', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (88, 89, N'Tax: Non', N'2026-05-22 16:32:54.7179941', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (89, 90, N'Tax: Non', N'2026-05-22 16:32:54.7184827', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (90, 91, N'Terms: Net 30 | Balance: 10317.5, Total: 10317.5 | Sub-jobs: 2 | Bill To: Inversiones Clínica Las Américas, S.E.', N'2026-05-22 16:32:54.7184827', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (91, 92, N'Bill To: IRC Construction', N'2026-05-22 16:32:54.7188489', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (92, 93, N'Tax: Non | Bill To: Jirah General Contractors', N'2026-05-22 16:32:54.7191677', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (93, 94, N'Tax: Non | Bill To: José Alberto Rodríguez', N'2026-05-22 16:32:54.7191677', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (94, 95, N'Tax: Non', N'2026-05-22 16:32:54.7194691', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (95, 96, N'Terms: Due on receipt | Tax: Non | Bill To: Mamis Pizza and Bar Corp.', N'2026-05-22 16:32:54.7194691', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (96, 97, N'Tax: Non', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (97, 98, N'Terms: Due on receipt | Tax: Non | Bill To: Matías Plumbing', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (98, 99, N'Terms: Net 30 | Tax: Non | Bill To: Mercantil Mayaguez Associates', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (99, 100, N'Terms: Due on receipt | Tax: Non | Bill To: Morgan Facility Services', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (100, 101, N'Tax: Non | Bill To: Mylan, Inc.', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (101, 102, N'Terms: Due on receipt | Tax: Non | Bill To: Oasis C.O.G.O.P.', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (102, 103, N'Terms: Due on receipt | Tax: Non | Bill To: Ornis, Corp.', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (103, 104, N'Tax: Non', N'2026-05-22 16:32:54.7197873', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (104, 105, N'Tax: Non | Bill To: Overhead Cost', N'2026-05-22 16:32:54.7211789', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (105, 106, N'Bill To: PFP-GENERAL', N'2026-05-22 16:32:54.7211789', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (106, 107, N'Tax: Non | Bill To: PFP Misc 2012', N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (107, 108, N'Tax: Non | Bill To: PFP Misc', N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (108, 109, N'Tax: Non | Bill To: PFP1305', N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (109, 110, N'Bill To: PFP14-01', N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (110, 112, N'Bill To: Misc 2016', N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (111, 113, N'Bill To: Misc 2017', N'2026-05-22 16:32:54.7215208', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (112, 118, N'Balance: 250, Total: 250', N'2026-05-22 16:32:54.7235294', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (113, 119, N'Bill To: PFP22-03 Misc Sodexo Bta, GMA, Citi', N'2026-05-22 16:32:54.7235294', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (114, 120, N'Bill To: Misc 2023', N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (115, 121, N'Terms: Net 60 | Bill To: Sodexo Misc 2023', N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (116, 122, N'Bill To: Misc 2024', N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (117, 123, N'Bill To: Misc 2025', N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (118, 124, N'Bill To: Sodexo Misc Bta, Guayama & Citi', N'2026-05-22 16:32:54.7241378', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (119, 126, N'Terms: Due on receipt | Bill To: Plaza Matienzo - Karate', N'2026-05-22 16:32:54.7255370', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (120, 127, N'Terms: Net 30 | Bill To: Ponte Fresco', N'2026-05-22 16:32:54.7255370', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (121, 128, N'Terms: Net 30 | Tax: Non | Bill To: Pro Welding', N'2026-05-22 16:32:54.7262102', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (122, 129, N'Tax: Non | Bill To: Pfizer Guayama', N'2026-05-22 16:32:54.7262102', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (123, 130, N'Tax: Non | Bill To: Ps Misc 2013', N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (124, 131, N'Tax: Non | Bill To: Puerto Rico Telephone Company', N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (125, 132, N'Terms: Due on receipt | Tax: Non | Bill To: RESOURCE RECYCLING, LLC.', N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (126, 133, N'Terms: Net 30 | Tax: Non | Contact: PRESIDENT | Bill To: RIFCO Manufacturing', N'2026-05-22 16:32:54.7275443', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (127, 134, N'Tax: Non', N'2026-05-22 16:32:54.7285105', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (128, 136, N'Terms: Due on receipt | Tax: Non | Bill To: Sin Mesura', N'2026-05-22 16:32:54.7285105', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (129, 137, N'Tax: Non', N'2026-05-22 16:32:54.7285105', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (130, 138, N'Bill To: Sucursal Caguas', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (131, 139, N'Bill To: Sucursal Guaynabo', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (132, 140, N'Bill To: Sucursal Trujillo Alto', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (133, 141, N'Tax: Non', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (134, 142, N'Tax: Non | Bill To: Taller de Mecanica La Gloria', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (135, 143, N'Terms: Due on receipt | Tax: Non | Bill To: TD Iron', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (136, 144, N'Terms: Due on receipt | Tax: Non | Bill To: Test Environmental', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (137, 145, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Torcon, Inc.', N'2026-05-22 16:32:54.7295519', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (138, 146, N'Tax: Non | Bill To: Unassinged', N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (139, 147, N'Tax: Non | Bill To: United States Treasury', N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (140, 149, N'Terms: Due on receipt | Tax: Non | Bill To: William Burgos, P.E.', N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (141, 150, N'Terms: Due on receipt | Tax: Non | Bill To: Xtreme Perfomance Martial Arts', N'2026-05-22 16:32:54.7315684', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (142, 151, N'Terms: Due on receipt | Tax: Non | Bill To: Xtreme Performance Matial Arts', N'2026-05-22 16:32:54.7326697', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (143, 152, N'RNC: 130-00921-1 | Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 3 | Original Customer field: Punta Cana Beach & Golf, SAS | Bill To: Punta Cana Beach & Golf, SAS; RNC: 130-00921-1', N'2026-05-22 16:33:03.1017438', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (144, 153, N'RNC: 133-51251-3 | Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Original Customer field: Southside International Packaging SRL | Bill To: Southside International Packaging SRL; RNC: 133-51251-3 | Ship To: Southside International Packaging SRL; RNC: 133-51251-3', N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (145, 154, N'RNC: 1-31-26588-1 | Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Terms: Due on receipt | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 8 | Original Customer field: Novotech Dominicana. | Bill To: Novotech Dominicana.; RNC: 1-31-26588-1', N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (146, 155, N'RNC: 130-14478-8 | Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: Acuario Tropical SRL | Bill To: Acuario Tropical; RNC: 130-14478-8', N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (147, 156, N'RNC: 133037612 | Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: SERVICIOS Y VENTAS E Y R ALONSO EIRL | Bill To: SERVICIOS Y VENTAS E Y R ALONSO EIRL; RNC: 133037612', N'2026-05-22 16:33:03.1020735', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (148, 157, N'RNC: 122-02856-2 | Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Energía 2000, SA | Bill To: Energía 2000, SA; RNC: 122-02856-2', N'2026-05-22 16:33:03.1034018', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (149, 158, N'RNC: 132-50921-8 | Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Terms: Net 60 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: Fermont Group, SRL | Bill To: Fermont Group, SRL; RNC: 132-50921-8', N'2026-05-22 16:33:03.1034018', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (150, 159, N'Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Currency: USD | Tax Code: Tax | Original Customer field: Jose Alberto Rodriguez Riveras | Bill To: Jose Alberto Rodriguez Riveras', N'2026-05-22 16:33:03.1040953', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (151, 160, N'Terms: Due on receipt | Currency: USD | Tax Code: Tax | Original Customer field: Cliente US$ | Bill To: Luis Brett; Cel.: 1 (829) 839-9758; Santo Domingo, Rep. Dom.', N'2026-05-22 16:33:03.1045457', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (152, 161, N'Address note: SIN DIRECCIÓN | SIN DIRECCIÓN | Terms: Due on receipt | Currency: DOP | Tax Code: Non | Tax Item: ITIBIS | Sub-jobs in source: 4 | Original Customer field: Prime Fire Dominica | Bill To: Prime Fire Dominica; Tel.: 1 (787) 221-2121', N'2026-05-22 16:33:03.1048507', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (153, 162, N'Address note: [extra] República Dominicana | Terms: Due on receipt | Currency: DOP | Tax Code: Non | Tax Item: ITIBIS | Original Customer field: Prime Fire Dominica:Administration | Bill To: 20259 Plaza Lincoln; Av Abraham Lincoln; Santo Domingo 221-2121; República Dominicana | Ship To: 20259 Plaza Lincoln; Av Abraham Lincoln; Santo Domingo 221-2121; República Dominicana', N'2026-05-22 16:33:03.1054646', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (154, 163, N'Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 2 | Original Customer field: Administración:2019 | Bill To: Prime Fire Dominicana, SRL; Av. Abraham Lincoln, Plaza Comercial; Lincoln, Sector La Julia 10108; Santo Domingo, República Dominicana; Phone: (809) 501-1900', N'2026-05-22 16:33:03.1054646', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (155, 164, N'Address note: [extra] Cel.:: (829)204-006 | [extra] Parque Industrial Itabo, SA, Haina | Terms: Due on receipt | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Sub-jobs in source: 14 | Original Customer field: Miscelaneos:PFD18-01 | Bill To: Ing. Joaquin Peignand; Sr. EHS & Security Engineer; Cel.:: (829)204-006; Tel.: (809) 908-0055 ext 330; Parque Industrial Itabo, SA, Haina', N'2026-05-22 16:33:03.1054646', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (156, 165, N'Terms: Due on receipt | Balance: 2142, Total: 2142 | Bill To: 1606 Ponce de León, Inc.; Calle del Parque 607; San Juan, PR 00909', N'2026-05-22 16:33:11.1068941', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (157, 166, N'Terms: Due on receipt | Sub-jobs: 2 | Bill To: 504 Construction Managers; Pmb 302 - 1353 Rd.19; Guaynabo, PR 00966', N'2026-05-22 16:33:11.1079280', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (158, 167, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: A&A Steri-Tec Contractors, Inc.; HC40 Box 44355; San Lorenzo, PR 00754', N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (159, 168, N'Terms: Net 30 | Sub-jobs: 4 | Bill To: A3 Services; PO Box 810061; Carolina PR', N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (160, 169, N'Terms: Net 90 days | Sub-jobs: 16 | Bill To: Industrial C&S of P.R. LLC; URB Parc Ponderosa; 800 Calle 18; Vega Alta PR 00692-5735', N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (161, 170, N'Terms: Net 90 days | Sub-jobs: 3 | Bill To: INDUSTRIAL C&S OF P.R. LLC; URB Parc Ponderosa; 800 Calle 18; Vega Alta PR 00692-5735', N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (162, 171, N'Terms: Net 90 days | Balance: 0, Total: 37248 | Sub-jobs: 7 | Bill To: ABB Installation Products Caribe LLC; Cabo Caribe Ind. Park; Vega Baja PR 00694-4058', N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (163, 172, N'Terms: Net 90 days | Tax: Non | Sub-jobs: 2 | Bill To: Abbott Diagnostics International, Ltd.; Vascular Business Unit; PO Box 1410; Abbott Park, IL 60064-8410', N'2026-05-22 16:33:11.1083543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (164, 173, N'Terms: Net 45 days | Sub-jobs: 57 | Bill To: Abbvie Knoll LLC; PO Box 3030; Barceloneta, PR 00617', N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (165, 174, N'Tax: Non | Bill To: Bo. Palmas; Cataño; PR', N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (166, 175, N'Terms: Net 30 | Balance: -52, Total: -52 | Bill To: Academia San Ignacio de Loyola; 1909, 1893 Cll Narciso; SanJuan, PR 00927', N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (167, 176, N'Terms: Net 30 | Tax: Non | Sub-jobs: 3 | Bill To: Academy Fire Life Safety, LLC; 42 Broadway 2nd Floor; Lynbrook, NY 11563', N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (168, 177, N'Terms: Net 30 | Balance: 1422.75, Total: 1422.75 | Sub-jobs: 2 | Bill To: ACESCO; 284 Calle B Parque Industrial Luchetti; Bayamon, PR 0096', N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (169, 178, N'Terms: Due on receipt | Tax: Non | Bill To: Advanced Industrial Contractors, Inc.; PO Box 1271; Saint Just, PR 00978', N'2026-05-22 16:33:11.1099391', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (170, 179, N'Terms: Net 15 | Tax: Non | Contact: Supervisor Mantenimiento | Sub-jobs: 2 | Bill To: AEELA; 463 Ave Ponce de Leon; Hato Rey, PR 00936-4508', N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (171, 180, N'Terms: Net 30 | Tax: Non | Bill To: AeroMetalica; 119 El Tuque Industrial Park; Ponce, Pr 00728', N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (172, 181, N'Terms: Net 30 | Tax: Non | Balance: 3200, Total: 3200 | Sub-jobs: 5 | Bill To: AEROSTAR AIRPORT HOLDINGS LLC; PO BOX 38085; SAN JUAN, PR 00937-1085', N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (173, 182, N'Tax: Non | Bill To: PO Box 1890; Guayama; PR; 785', N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (174, 183, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: AGM Group Engineering Corp.; RR5 Box 8418 Suite #3; Bayamon, PR 00956', N'2026-05-22 16:33:11.1118374', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (175, 184, N'Terms: Due on receipt | Bill To: Aguayo Sheet Metal, Inc; PO Box 2559; Toa Baja, PR 00951.', N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (176, 185, N'Terms: Due on receipt | Bill To: AIP Holdings, LLC; 270 PR I Unit #2; 250 Munoz Rivera Suite 320; San Juan, PR 00918', N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (177, 186, N'Terms: Net 30 | Tax: Non | Contact: Accounts Payable | Sub-jobs: 15 | Bill To: Aireko Construction; PO Box 2128; San Juan, PR 00922-2128', N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (178, 187, N'Terms: Net 30 | Tax: Non | Bill To: Aires & Servicios Contratistas; PO BOX 1776; San Lorenzo, PR 00754-1776', N'2026-05-22 16:33:11.1139814', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (179, 188, N'Terms: Due on receipt | Tax: Non | Contact: Accounts Payable | Sub-jobs: 3 | Bill To: AKZONOBEL Paints PR, Inc.; PO Box 94995; Cleveland, OH 44101-4995', N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (180, 189, N'Terms: Net 30 | Bill To: ALPLA Caribe, Inc.; Bo. Puente de Jobos; Carr. #3 KM 144.7; Guayama, PR 00784', N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (181, 190, N'Terms: Net 30 | Tax: Non | Sub-jobs: 37 | Bill To: Alproem Engineering Contractors, Corp.; PMB #419 - 90; Ave. Rio Hondo; Bayamon, PR 00961', N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (182, 191, N'Tax: Non | Bill To: PO Box 893; Humacao; PR; 00791-0893', N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (183, 192, N'Terms: Net 60 | Balance: 0, Total: 21478.68 | Sub-jobs: 12 | Bill To: Amgen Manufacturing Limited; PO Box 427; Newbury Park, CA 91319', N'2026-05-22 16:33:11.1158621', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (184, 193, N'Terms: Net 30 | Tax: Non | Sub-jobs: 5 | Bill To: Surgical Specialties PR, Inc.; Accounts Payable Department; PO Box 3915; Aguadilla, PR 00605', N'2026-05-22 16:33:11.1171961', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (185, 194, N'Terms: Net 30 | Tax: Non | Bill To: Ara Security Integrators; 1836 C Reina de las Flores; San Juan, PR 00927', N'2026-05-22 16:33:11.1175134', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (186, 195, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Arco Caribe Architects, PSC; PO Box 9084; San Juan, PR 00908-1084', N'2026-05-22 16:33:11.1178468', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (187, 196, N'Terms: Net 30 | Tax: Non | Bill To: ASEM; PO BOX 2129; San Juan, PR 00922-2129', N'2026-05-22 16:33:11.1178468', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (188, 197, N'Tax: Non | Bill To: Asplundh Tree Experts; P.O. Box 808; Juncos PR 00777', N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (189, 198, N'Terms: Net 30 | Tax: Non | Bill To: AT CONSTRUCTION SOLUTIONS LLC; PO BOX 2128; SAN JUAN PR 00922-2128', N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (190, 199, N'Terms: Net 30 | Tax: Non | Bill To: Atlantic Marine Construction Company, Inc; 3465 Chandler Creek Road; Virginia Beach, VA 23453', N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (191, 200, N'Terms: Net 30 | Tax: Non | Sub-jobs: 18 | Bill To: Mylan, Inc.; P.O. Box 2648; Portland, OR 97208-2648', N'2026-05-22 16:33:11.1184623', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (192, 201, N'Terms: Due on receipt | Tax: Non | Bill To: AUTOMATIC SUPPRESSION ENGINEERING, INC.; PO Box 16575; San Juan, PR 00908', N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (193, 202, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: Autoridad de Energía Eléctrica; Apartado 364267; Correo General; San Juan, PR 00936-4267', N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (194, 203, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Autoridad de Transporte Marítimo de PR y; Las Islas Municipio; PO Box 41267; San Juan, PR 00940', N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (195, 204, N'Terms: Net 90 days | Balance: 10257, Total: 172419.4 | Sub-jobs: 10 | Bill To: Bacardi Corporation; State Road 165 KM 2.6; Cataño, PR', N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (196, 205, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: CR Bard C/O BD; 1 Becton Drive; Franklin Lake NJ 07417; Mail Room MC 001', N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (197, 206, N'Terms: Net 60 | Sub-jobs: 22 | Bill To: BASF Agricultural Products de Puerto Rico; 00 PARK AVENUE,; FLORHAM PARK, NJ 07932-0685', N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (198, 207, N'Terms: Net 60 | Tax: Non | Sub-jobs: 18 | Bill To: BAXTER HEALTHCARE OF PUERTO RICO; BAS-COSTA RICA; PO BOX 999; DEERFIELD, IL 60015; UNITED STATES', N'2026-05-22 16:33:11.1196762', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (199, 208, N'Terms: Net 60 | Tax: Non | Sub-jobs: 31 | Bill To: Baxter Health Care of Puerto Rico; Accounts Payable Dept.; Call Box 2200; Aibonito, PR 00705-2200', N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (200, 209, N'Terms: Net 60 | Tax: Non | Sub-jobs: 14 | Bill To: BAXTER HEALTHCARE OF PUERTO RICO; BAS-COSTA RICA; PO BOX 999; DEERFIELD, IL 60015; UNITED STATES', N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (201, 210, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: Baxter Healthcare, SA; PO Box 2002; Cataño, PR 00963', N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (202, 211, N'Terms: Net 30 | Sub-jobs: 4 | Bill To: BD Puerto Rico LLC; PO Box 5200; Rantoul, IL 61866-5200', N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (203, 212, N'Terms: Due on receipt | Tax: Non | Bill To: Berlitz Hato Rey; Suite 103, Plaza El Amal Building; 282 J.T. Piñero Ave.; San Juan, PR 00927', N'2026-05-22 16:33:11.1216861', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (204, 213, N'Terms: Net 30 | Tax: Non | Balance: 0, Total: 89450 | Sub-jobs: 5 | Bill To: Best Solutions Eng & Maintenance Services; PO Box 402; Juncos, PR 00777-0402', N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (205, 214, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: BGC PROJECT MANAGEMENT, INC.; PMB 398 200 AVE. RAFAEL CORDERO; CAGUAS PR 00725', N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (206, 215, N'Sub-jobs: 2 | Bill To: Bilgla Construction, Inc.; Urb. Palacios del Rio II; 692 Calle Guajataca; Toa Alta, PR 00961-3105', N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (207, 216, N'Tax: Non | Bill To: Los Jardines Shopping Center; 130 Marginal St Suite 11; Guaynabo; PR; 00969-3470', N'2026-05-22 16:33:11.1236976', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (208, 217, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Bonneville Contracting and Tech Group,Inc; PO Box 193476; San Juan, PR 00919-3476', N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (209, 218, N'Terms: Net 30 | Tax: Non | Balance: 2060, Total: 2060 | Bill To: Borinken Marine Goup, LLC; 211161 Brisas del Bosque; Cayey, PR 00736', N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (210, 219, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: BR&A LLC; 3100 Carr. 199, Suite 203; San Juan, Puerto Rico, 00926', N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (211, 220, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: Brandenburg Industrial Service Company; 501 West Lake St, Suite 104; Elmhurst, IL 60126-1419', N'2026-05-22 16:33:11.1257159', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (212, 221, N'Terms: Net 90 days | Balance: 825, Total: 825 | Sub-jobs: 32 | Bill To: BMS Manufacturing Company; ATTN: Accounts Payable; PO Box 25277; Tampa, FL 33622', N'2026-05-22 16:33:11.1277274', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (213, 222, N'Terms: Net 30 | Sub-jobs: 6 | Bill To: NG&G Facility Services Intl; 263 Jenckes Hill Rd; Lincoln, RI 02865-4415', N'2026-05-22 16:33:11.1277274', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (214, 223, N'Terms: Due on receipt | Bill To: Cabrits Resort & Spa Kempinski Dominica; Bell Hall Road, Cabrits · Douglas Bay; Portsmouth · Commonwealth of Dominica', N'2026-05-22 16:33:11.1290900', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (215, 224, N'Terms: Due on receipt | Bill To: Cadillac Uniform & Linen Supply; PO Box 601893; Bayamón, PR 00960-1893', N'2026-05-22 16:33:11.1290900', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (216, 225, N'Terms: Net 30 | Tax: Non | Contact: A/Payable | Sub-jobs: 12 | Bill To: Caguas Mechanical Contractor; Calle Nebraska U-4; Caguas Norte; Caguas, PR 00725', N'2026-05-22 16:33:11.1297394', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (217, 226, N'Terms: Net 30 | Sub-jobs: 4 | Bill To: CamuyCoop; 300 Ave. Baltazar Jiménez Méndez; Camuy, PR 00627', N'2026-05-22 16:33:11.1297394', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (218, 227, N'Terms: Net 30 | Tax: Non | Bill To: Capital Services LLC; US Food & Drugs Administration; 466 Fdz Juncos Ave. San Juan PR 00901', N'2026-05-22 16:33:11.1297394', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (219, 228, N'Terms: Net 10 Days | Tax: Non | Sub-jobs: 13 | Bill To: Cardinal Health PR, Inc.; GPO Box 366211; San Juan, PR 00936-6211', N'2026-05-22 16:33:11.1313035', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (220, 229, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Caribbean Construction Partners Corp.; PO Box 10578; San Juan, PR 00922', N'2026-05-22 16:33:11.1317494', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (221, 230, N'Terms: Net 30 | Tax: Non | Bill To: Caribbean Energy; P.O. Box 29155; San Juan, PR 00929-0155', N'2026-05-22 16:33:11.1317494', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (222, 231, N'Tax: Non | Bill To: PO 29726; San Juan; PR; 00929-0726', N'2026-05-22 16:33:11.1317494', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (223, 232, N'Tax: Non | Bill To: PO Box 9024051; San Juan; PR; 00902-4010', N'2026-05-22 16:33:11.1328687', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (224, 233, N'Terms: Net 30 | Tax: Non | Sub-jobs: 8 | Bill To: Caribbean Property Group, LLC; PO Box 338; Cataño, PR 0963', N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (225, 234, N'Terms: Net 60 | Tax: Non | Sub-jobs: 77 | Bill To: Caribbean Refrescos; PO Box 11999; Cidra; PR; 00739-1999', N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (226, 235, N'Terms: Net 30 | Tax: Non | Bill To: Caribe Hydroblasting Corp.; PO BOX 790; Peñuelas, PR 00624-0790', N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (227, 236, N'Terms: Net 30 | Tax: Non | Bill To: Caribe Pro Services Inc.; PO Box 116; Manati, PR 00674', N'2026-05-22 16:33:11.1335715', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (228, 237, N'Tax: Non | Bill To: PO Box 25070; San Juan; PR; 00928-5070', N'2026-05-22 16:33:11.1354310', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (229, 238, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: CBRE GWS OF Puerto Rico, Inc.; Tax ID-66-0827285; JCI-AP-BMS Contract-M60A; 507 E. Michigan St; Milwaukee, WI 53202-0000', N'2026-05-22 16:33:11.1354310', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (230, 239, N'Terms: Net 60 | Sub-jobs: 15 | Bill To: CBRE GWS OF Puerto Rico, Inc.; Tax ID-66-0827285; JCI-AP-M60A Pfizer Contract; PO Box 2942; Milwaukee, WI 53201', N'2026-05-22 16:33:11.1361108', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (231, 240, N'Terms: Net 30 | Balance: 22994, Total: 22994 | Sub-jobs: 2 | Bill To: CCl Puerto Rico, Inc.; PO Box 1681; Sabana Grande, PR 00637', N'2026-05-22 16:33:11.1366315', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (232, 241, N'Terms: Net 15 | Tax: Non | Sub-jobs: 3 | Bill To: CE Plumbing Corp.; Calle Leone #1655; Com Punta Diamante; Ponce, PR 00728', N'2026-05-22 16:33:11.1366315', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (233, 242, N'Terms: Net 30 | Tax: Non | Sub-jobs: 9 | Bill To: Cervecera de Puerto Rico; ACCOUNT PAYABLES DEPT.; PO BOX 1690; Mayaguez, PR 00681', N'2026-05-22 16:33:20.5757619', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (234, 243, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Cesar Castillo, Inc.; PO Box 191149; San Juan, PR 00919-1149', N'2026-05-22 16:33:20.5760974', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (235, 244, N'Tax: Non | Bill To: CG Construction Corp.; Urb. Baralt; Ave. Principal I-10; Fajardo, PR 00738', N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (236, 245, N'Balance: 37937.2, Total: 37937.2 | Sub-jobs: 9 | Bill To: CIC Construction Group, LLC; State Road #1 Km.23.0 Rio Ward; Guaynabo, Puerto Rico 00971', N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (237, 246, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: Cimetric Engineering & Contractor; P.O. Box 1009; Gurabo, PR 00778', N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (238, 247, N'Terms: Net 15 | Bill To: Clary Corp of PR, Inc.; PO Box 9752; San Juan, PR 00908', N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (239, 248, N'Terms: Net 90 days | Sub-jobs: 2 | Bill To: CLPG SJIP 1 LLC; PO BOX 11924; SAN JUAN, PUERTO RICO 00922', N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (240, 249, N'Terms: Net 30 | Balance: 16047.62, Total: 16047.62 | Sub-jobs: 2 | Bill To: CMGC Building Corp.; 360 Harvey Road; Manchester, NH 03103', N'2026-05-22 16:33:20.5764382', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (241, 250, N'Terms: Net 30 | Sub-jobs: 10 | Bill To: Colgate-Palmolive Company Distr. LLC.; PO Box 363865; San Juan, PR 00936-3865', N'2026-05-22 16:33:20.5780252', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (242, 251, N'Tax: Non | Bill To: PO Box 363865; San Juan; PR; 00936-3865', N'2026-05-22 16:33:20.5780252', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (243, 252, N'Terms: Net 30 | Sub-jobs: 4 | Bill To: Columbia Care LLC; 2381 Boulevard Luis A, Ferr; Ponce, PR 00717-0762', N'2026-05-22 16:33:20.5780252', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (244, 253, N'Terms: Net 30 | Tax: Non | Sub-jobs: 4 | Bill To: Combe Products, Inc.; PO Box 1208; Naguabo PR 00718-1208', N'2026-05-22 16:33:20.5788877', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (245, 254, N'Tax: Non | Bill To: PO Box 362983; San Juan; PR; 00936-2983', N'2026-05-22 16:33:20.5788877', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (246, 255, N'Terms: Net 30 | Sub-jobs: 4 | Bill To: Comprehensive Fire Technologies; 108 Liberty Street; Metuchen, NJ 08840', N'2026-05-22 16:33:20.5788877', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (247, 256, N'Terms: Net 30 | Tax: Non | Balance: 557.5, Total: 557.5 | Bill To: Concorde Metro Seguros; Centro de Seguros, Suite 208; #701 Ponce de León Avenue; San Juan, Puerto Rico 00907', N'2026-05-22 16:33:20.5800441', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (248, 257, N'Terms: Net 30 | Balance: 0, Total: 2842.5 | Sub-jobs: 2 | Bill To: Cond. Bayside Cove; #105 Ave. Arterial Hostos; Buzon 266; San Juan, PR 00918', N'2026-05-22 16:33:20.5800441', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (249, 258, N'Terms: Due on receipt | Tax: Non | Contact: Accounts Payable | Sub-jobs: 2 | Bill To: Congar International Corp.; PO BOX 373100; Cayey, PR 00737', N'2026-05-22 16:33:20.5809110', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (250, 259, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: Constructora DIROVI Corp.; Calle Luis Muñoz Rivera #71; Yabucoa, PR 00767', N'2026-05-22 16:33:20.5809110', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (251, 260, N'Tax: Non | Bill To: PO Box 561; Punta Santiago; Humacao; PR', N'2026-05-22 16:33:20.5820568', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (252, 261, N'Balance: 20359.75, Total: 20359.75 | Sub-jobs: 4 | Bill To: Constructora Santiago II Corp.; PO 364925; San Juan, PR 00936-4925', N'2026-05-22 16:33:20.5820568', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (253, 262, N'Tax: Non | Bill To: 425 Carr. 693 PMB 210; Dorado; PR; 00646-4802', N'2026-05-22 16:33:20.5829316', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (254, 263, N'Tax: Non | Bill To: C/C #1 Esq. C/5-S Residencial; Los Rosales Km 10 Carr Mella; Santo Domingo; RD', N'2026-05-22 16:33:20.5829316', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (255, 264, N'Terms: Due on receipt | Tax: Non | Bill To: Converged Systems & Solutions; No 38 Pine Road,; Belleville Corporate Center; St. Michael - Barbados', N'2026-05-22 16:33:20.5840665', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (256, 265, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: Cooperativa Las Piedras; Box 100; Las Piedras, PR 00771', N'2026-05-22 16:33:20.5840665', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (257, 266, N'Terms: Net 45 days | Tax: Non | Balance: 0, Total: 85180.8 | Sub-jobs: 8 | Bill To: CooperVision MFG Puerto Rico; 500 State Road 584; Juana Diaz, PR 00795', N'2026-05-22 16:33:20.5840665', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (258, 267, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Copan Industries, Inc.; Carr 110 KM 28.8; San Antonio Industrial Park; Aguadialla, PR 00603', N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (259, 268, N'Terms: Net 30 | Tax: Non | Balance: 0, Total: 84975 | Sub-jobs: 2 | Bill To: Cornerstone Industrial Group Corp; PO Box 9144; San Juan, PR 00908', N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (260, 269, N'Sub-jobs: 2 | Bill To: Cotto Incorporado; P.O. Box 303; Aguas Buenas, P.R. 00703', N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (261, 270, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: COTTON INTERNATIONAL; 5443 Katy Hockley Cut Off Rd,; Katy, TX 77493', N'2026-05-22 16:33:20.5849529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (262, 271, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: CREATIVE DEVELOPMENTS CORP.; URB INDUSTRIAL VICTOR FERNANDEZ; # 340 CALLE 3 Ste-1; SAN JUAN PR 00926', N'2026-05-22 16:33:20.5860754', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (263, 272, N'Terms: Due on receipt | Tax: Non | Bill To: CrossFit Purpose; Plaza Matienzo; Trujillo Alto, PR 00976', N'2026-05-22 16:33:20.5860754', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (264, 273, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Crowley Maritime Corporation; 9487 Regency Square Blvd.; Jacksonville, FL 32225', N'2026-05-22 16:33:20.5867789', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (265, 274, N'Terms: Net 30 | Tax: Non | Sub-jobs: 21 | Bill To: Cruybelt Contractor; PO Box 97; Las Piedras, PR 00771', N'2026-05-22 16:33:20.5867789', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (266, 275, N'Terms: Due on receipt | Tax: Non | Sub-jobs: 2 | Bill To: Converged Systems and Solutions; #38 Pine Road; Belleville, St. Michael; Barbados – BB11113', N'2026-05-22 16:33:20.5867789', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (267, 276, N'Terms: Due on receipt | Bill To: CSS Contractors Corp.; 89 De Diego Ave.; PMB 580 Suite 105; San Juan, PR 00921', N'2026-05-22 16:33:20.5875741', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (268, 277, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: CytoImmune Therapeutics Puerto Rico LLC; Carr. 865 KM 5.4; Toa Baja, PR 00949', N'2026-05-22 16:33:20.5875741', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (269, 278, N'Terms: Net 30 | Tax: Non | Bill To: Damiani Contractors, Inc.; HC04 Box 23646; Lajas, PR 00667', N'2026-05-22 16:33:20.5880840', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (270, 279, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Dentsply Ceramco Puerto Rico; C/O Dentsply Sirona, Inc..; PO Box 2846; York, PA 17405', N'2026-05-22 16:33:20.5880840', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (271, 280, N'Terms: Net 30 | Tax: Non | Sub-jobs: 6 | Bill To: DEPARTAMENTO DE; CORRECCION Y REHABILITACION; PO Box 71308; San Juan, PR 00936-8408', N'2026-05-22 16:33:20.5880840', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (272, 281, N'Terms: Net 30 | Sub-jobs: 16 | Bill To: Department of Veterans Affairs; Financial Services Center; P.O. Box 149971; Austin TX 78714-9971', N'2026-05-22 16:33:20.5890014', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (273, 282, N'Terms: Net 30 | Balance: 0, Total: 1635 | Sub-jobs: 2 | Bill To: Designed Temperatures Inc.; Villa Alegría; Calle Topacio #259; Aguadilla, PR 00603', N'2026-05-22 16:33:20.5890014', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (274, 283, N'Tax: Non | Bill To: 1919 Gallows Rd. Suite 950; Vienna; VA; 22182-4038', N'2026-05-22 16:33:20.5895813', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (275, 284, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: DIVISION 16 LLC.; PO BOX 3941; GUAYNABO, PR 00970', N'2026-05-22 16:33:20.5895813', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (276, 285, N'Terms: Due on receipt | Tax: Non | Balance: 260, Total: 260 | Bill To: Doctor''s Cancer Center; Metro Medical Center Bldg; Torre B Piso 7, suite 701; Bayamon, PR', N'2026-05-22 16:33:20.5895813', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (277, 286, N'Tax: Non | Bill To: Norte Shopping Center; San Juan; PR', N'2026-05-22 16:33:20.5910247', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (278, 287, N'RNC: 132-81733-8 | Sub-jobs: 2 | Bill To: Eastern Developers Investment, S. A. S.; Domicilio social Av. Abraham Lincoln #960; República Dominicana; RNC: 132-81733-8', N'2026-05-22 16:33:20.5917979', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (279, 288, N'Terms: Net 30 | Sub-jobs: 9 | Bill To: Eco Building Solutions, Inc.; PMB 133, 405 Ave. Esmeralda Suite 102; Guaynabo, PR 00969', N'2026-05-22 16:33:20.5921057', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (280, 289, N'Terms: Net 30 | Contact: Purchasing Manager | Sub-jobs: 27 | Bill To: EcoEléctrica, L.P.; Firm Delivery; 641 Road 337; Peñuelas, PR 00624-9804', N'2026-05-22 16:33:20.5927309', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (281, 290, N'Terms: Due on receipt | Tax: Non | Bill To: Eileen Medina; Honeywell', N'2026-05-22 16:33:20.5927309', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (282, 291, N'Terms: Net 30 | Balance: 0, Total: 14400 | Sub-jobs: 12 | Bill To: EM Contractor, Inc.; HC-03 Box 6413; Humacao, PR 00791', N'2026-05-22 16:33:20.5936097', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (283, 292, N'Terms: Net 15 | Bill To: Endeavor Construction Group, Inc.; PO Box 194111; San Juan, PR 00919-4111', N'2026-05-22 16:33:20.5939115', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (284, 293, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: Enersys Engineering Corporation; Centro Internacional de Mercadeo II; Carr. 165 Torre 90 Of. 312; Guaynabo, PR 00968', N'2026-05-22 16:33:20.5939115', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (285, 294, N'Terms: Net 30 | Sub-jobs: 5 | Bill To: ER Building Solutions, LLC; PO BOX 193201; San Juan, PR 00919', N'2026-05-22 16:33:20.5939115', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (286, 295, N'Terms: Due on receipt | Tax: Non | Bill To: Essentials; Cupey, PR', N'2026-05-22 16:33:20.5960854', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (287, 296, N'Terms: Net 90 days | Balance: 2230, Total: 45410 | Sub-jobs: 9 | Bill To: Ethicon LLC; PO Box 16571; New Brunswick, NJ 08906-6571', N'2026-05-22 16:33:20.5963926', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (288, 297, N'Terms: Due on receipt | Tax: Non | Bill To: EVS, Inc.; 10250 Valley Rd.; Suite 123; Eden Prairie, MN 55344', N'2026-05-22 16:33:20.5963926', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (289, 298, N'Terms: Net 30 | Bill To: Executive Homesearch & Realty; Services, Inc.; PO Box 195288; San Juan, PR 00919-5288', N'2026-05-22 16:33:20.5963926', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (290, 299, N'Terms: Due on receipt | Balance: 7528, Total: 7528 | Bill To: FAA San Juan; 5000 Carretera 190; Carolina, PR, 00979', N'2026-05-22 16:33:20.5976359', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (291, 300, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: FAA San Juan (CERAP); 5000 Carretera 190; Carolina, PR, 00979', N'2026-05-22 16:33:20.5981083', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (292, 301, N'Terms: Due on receipt | Tax: Non | Bill To: FDA; 466 Fernández Juncos Ave; San Juan, PR 00901-3223', N'2026-05-22 16:33:20.5988882', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (293, 302, N'Terms: Due on receipt | Tax: Non | Bill To: FHC; PO Box 9976 Cotto Station; Arecibo, PR 00613', N'2026-05-22 16:33:20.5988882', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (294, 303, N'Terms: Due on receipt | Tax: Non | Balance: 108, Total: 108 | Sub-jobs: 2 | Bill To: Fire Proof, Inc.; Calle AA bloque AA #24 Alturas; Vega Baja PR 00693', N'2026-05-22 16:33:20.5994951', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (295, 304, N'Terms: Net 30 | Tax: Non | Bill To: Fire Safe, Inc.; PO Box 699; Trujillo Alto, PR 00977-0699', N'2026-05-22 16:33:20.6001280', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (296, 305, N'Terms: Net 30 | Tax: Non | Balance: 300, Total: 300 | Bill To: FireProof, Inc.; Calle AA #24 AA  Alturas de Vega Baja; Vega Baja, PR 00693', N'2026-05-22 16:33:20.6001280', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (297, 306, N'Terms: Net 30 | Tax: Non | Bill To: First Hospital Panamericano; Box 1400; Cidra, PR 00739-1400', N'2026-05-22 16:33:20.6009137', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (298, 307, N'Tax: Non | Bill To: Torre Chardón #350 Ste. 1244; Ave. Chardón; San Juan; PR; 918', N'2026-05-22 16:33:20.6015031', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (299, 308, N'Terms: Net 30 | Tax: Non | Sub-jobs: 4 | Bill To: Four Seasons Environmental, Inc.; 1324 Calle Canada; San Juan, PR 00920', N'2026-05-22 16:33:20.6021481', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (300, 309, N'Terms: Net 30 | Tax: Non | Bill To: Fox Engineering & Construction; 377 Ave. Domenech; San Juan, PR 00918-3721', N'2026-05-22 16:33:20.6021481', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (301, 310, N'Terms: Net 30 | Tax: Non | Bill To: G-Con Manufacturing, Inc.; 6161 Imperial Loop; College Station, TX 77845', N'2026-05-22 16:33:20.6028774', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (302, 311, N'Terms: Due on receipt | Tax: Non | Bill To: G&N General Contractors, Inc.; Alturas del Encanto N 21; Juana Díaz; PR; 795', N'2026-05-22 16:33:20.6028774', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (303, 312, N'Tax: Non | Bill To: PO Box 363866; San Juan; PR; 936', N'2026-05-22 16:33:20.6028774', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (304, 313, N'Terms: Net 90 days | Tax: Non | Balance: 5865, Total: 5865 | Sub-jobs: 6 | Bill To: GENCO General Contractors of Puerto Rico; 3623 Avenida Militar PMB 331; Isabela, Puerto Rico 00662', N'2026-05-22 16:33:20.6041693', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (305, 314, N'Terms: Due on receipt | Tax: Non | Bill To: General Cigars Dominicana, S.A.; Zona Franca Industrial; Victor Manuel Espaillat; Santiago, RD; RD', N'2026-05-22 16:33:20.6041693', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (306, 315, N'Tax: Non | Bill To: PMB 635M 267; Calle Sierra Morena; San Juan; PR; 00926-5583', N'2026-05-22 16:33:20.6049490', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (307, 316, N'Tax: Non | Bill To: PO Box 29726; San Juan; PR; 00929-0726', N'2026-05-22 16:33:20.6049490', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (308, 317, N'Terms: Due on receipt | Tax: Non | Bill To: Gilbane Building Company; 661 University Blvd.; Jupiter, FL 3345', N'2026-05-22 16:33:20.6049490', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (309, 318, N'Terms: Net 15 | Sub-jobs: 2 | Bill To: GK Pharmaceuticals CMO LLC.; Barrio Coto Norte; Carr. 2 Km 45.7; Manati, PR 00674', N'2026-05-22 16:33:20.6061917', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (310, 319, N'Tax: Non | Bill To: PO Box 143801; Arecibo; PR; 614', N'2026-05-22 16:33:31.4442109', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (311, 320, N'Terms: Due on receipt | Tax: Non | Bill To: Gobierno Municipal Autónomo de Carolina; Apartado Postal 8; Carolina, PR 00986-0008', N'2026-05-22 16:33:31.4448387', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (312, 321, N'Terms: Net 15 | Tax: Non | Bill To: Green Energy Systems Corp.; PO Box 2017, PMB 189; Las Piedras, PR 00771', N'2026-05-22 16:33:31.4451793', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (313, 322, N'Terms: Due on receipt | Bill To: GSG; PO Box 9431; Cotto Station; Arecibo, PR 00613', N'2026-05-22 16:33:31.4455992', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (314, 323, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Guardia Nacional de Puerto Rico; ATTN Servicios Administrativos del Estado; 552 Borinqueneer TRL; Guaynabo, PR, 00934', N'2026-05-22 16:33:31.4459074', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (315, 324, N'Terms: Net 30 | Sub-jobs: 4 | Bill To: H&E Development, LLC; Urb Sagrado Corazón; Ave. San Claudio #358; San Juan, PR 00926', N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (316, 325, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: HACIENDA DEL MAR OWNERS'' ASSOCIATION, INC; 9002 San Marco Court; Orlando, Florida 32819', N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (317, 326, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: HBA Contractors, Inc.; P.O. Box 9220; San Juan, P.R.  00908-9220', N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (318, 327, N'Terms: Net 30 | Bill To: HCCM Corp.; PO Box 8808; Ponce, PR 00732', N'2026-05-22 16:33:31.4462268', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (319, 328, N'Tax: Non | Bill To: PO Box 3982; San Juan; PR; 00936-3982', N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (320, 329, N'Tax: Non | Bill To: Hernandez Signs; Jardines de Carolina; Calle C #A9; Carolina, PR 00987', N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (321, 330, N'Terms: Due on receipt | Tax: Non | Bill To: HMS Ferries - Puerto Rico; PO Box 8539; Fernandez Juncos Station; San Juan PR 00910', N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (322, 331, N'Terms: Due on receipt | Tax: Non | Bill To: Hogar Benaina; Carmelo Ortiz; Carr. 852 Km 1.7; Trujillo Alto, PR 00977', N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (323, 332, N'Tax: Non | Bill To: PO Box 9321; Humacao; PR; 972', N'2026-05-22 16:33:31.4479235', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (324, 333, N'Sub-jobs: 26 | Bill To: Home Depot Support, Inc.; 2455 Paces Ferry Rd SE; Atlanta, GA 30339, US', N'2026-05-22 16:33:31.4492690', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (325, 334, N'Terms: Due on receipt | Tax: Non | Bill To: Honeywell Puerto Rico; 400 Suite 100 Calle C; Rexco industrial Park; Guaynabo PR 00968', N'2026-05-22 16:33:31.4492690', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (326, 335, N'Terms: Net 30 | Balance: 0, Total: 5612.4 | Sub-jobs: 2 | Bill To: Hospital Damas, Inc.; 2213 Ponce By Pass; Ponce,  Puerto Rico 00717', N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (327, 336, N'Terms: Net 30 | Balance: 0, Total: 12266.66 | Sub-jobs: 6 | Bill To: HOSPITAL REGIONAL BAYAMON; DIV. CUENTAS A PAGAR, DEPTO. FINANZAS; AVE. LAUREL STA. JUANITA; BAYAMON, PR 00956', N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (328, 337, N'Terms: Due on receipt | Tax: Non | Sub-jobs: 2 | Bill To: Hospitality Management; Goods & Services; P. O box 502751; St. Thomas USVI 00805 | Ship To: Hospitality Management; Goods & Services; P.O. Box 502751; St. Thomas USVI 00805', N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (329, 338, N'Terms: Net 60 | Sub-jobs: 24 | Bill To: Hubbell Caribe Limited; P.O. Box 4138; Road 686 Km. 17.3; Vega Baja, PR 00694-4138', N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (330, 339, N'Terms: Net 30 | Balance: 0, Total: 13104 | Sub-jobs: 2 | Bill To: Hyatt Regency; 200 Coco Beach Blvd; Rio Grande, PR 00745', N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (331, 340, N'Terms: Net 30 | Tax: Non | Sub-jobs: 4 | Bill To: Hyatt Residence Club Dorado, Hac del Mar; 301 Hwy 693; Dorado, PR 00646', N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (332, 341, N'Terms: Due on receipt | Tax: Non | Contact: Accounts Payable | Sub-jobs: 4 | Bill To: ICS, Inc.; PMB 216; 405 Esmeralda Ave.; Guaynabo, PR 00969', N'2026-05-22 16:33:31.4499434', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (333, 342, N'Terms: Due on receipt | Sub-jobs: 3 | Bill To: IDAVIE Contractors, Inc.; HC-02 Box 6859; Ciales, PR 00638-9655', N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (334, 343, N'Tax: Non | Bill To: St. Rd. 950 Km 3; Bo. Higuerillo; Naguabo; PR; 0', N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (335, 344, N'Terms: Due on receipt | Tax: Non | Bill To: Iglesia Evangelica Unida; 516 Calle Alfredo Carbonell; San Juan, PR 00918', N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (336, 345, N'Terms: Net 30 | Tax: Non | Bill To: IKEA; Santa Rosa Mall, 1455, 402; Av. Aguas Buenas; Bayamón, PR 00959', N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (337, 346, N'Terms: Net 30 | Balance: 0, Total: 520 | Sub-jobs: 2 | Bill To: Image First/DUI, Inc.; Carr PR 744 K1.1; Bo Machete Parque Industrial#67; Edificio T-0889; Guayama, PR 00784', N'2026-05-22 16:33:31.4519529', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (338, 347, N'Tax: Non | Bill To: PO Box 3204; Mayaguez; PR; 00681-3204', N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (339, 348, N'Sub-jobs: 2 | Bill To: Inducom Group LLC; 138 Winston Churchill Ave. PMB 153; San Juan, PR 00926-6013', N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (340, 349, N'Terms: Net 30 | Sub-jobs: 9 | Bill To: INDUPRO, S.E.; PO Box 363232; San Juan, PR 00936-3232', N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (341, 350, N'Terms: Due on receipt | Tax: Non | Sub-jobs: 4 | Bill To: Industrial Fire; Reparto Marquez E-9 Calle 5; Arecibo, PR 00612-3913', N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (342, 351, N'Terms: Due on receipt | Bill To: Industrial Process Supply; PO BOX 51565; TOA BAJA, PR 00950', N'2026-05-22 16:33:31.4539609', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (343, 352, N'Terms: Due on receipt | Tax: Non | Balance: 150, Total: 150 | Bill To: Innova Fire Protection, Inc.; Metropolis, 47 CII Isarael; Carolina PR 00987', N'2026-05-22 16:33:31.4559745', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (344, 353, N'Terms: Due on receipt | Tax: Non | Bill To: Inova Fire Protection; HC645 PO Box 7185; Trujillo Alto, PR 00976', N'2026-05-22 16:33:31.4559745', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (345, 354, N'Terms: Net 15 | Tax: Non | Sub-jobs: 2 | Bill To: Integrated Business Solutions PO Box 6857; Caguas; PR; 00726-6857', N'2026-05-22 16:33:31.4559745', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (346, 355, N'Terms: Due on receipt | Tax: Non | Bill To: Integrated Health Systems of Guaynabo; PO Box 195615; San Juan, PR 00919-5615', N'2026-05-22 16:33:31.4571071', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (347, 356, N'Terms: Due on receipt | Tax: Non | Balance: 192, Total: 192 | Bill To: Inverco; P.O. Box 10908; Caparra Heights Sta.; San Juan, Puerto Rico 00922', N'2026-05-22 16:33:31.4577278', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (348, 357, N'Terms: Due on receipt | Tax: Non | Bill To: Inversiones Grinne, Inc.; Calle 15 J10 Fairview; Trujillo Alto; PR; 976', N'2026-05-22 16:33:31.4581165', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (349, 358, N'Terms: Due on receipt | Sub-jobs: 2 | Bill To: INVERSIONES OMEGA, SRL; Santo Domingo, República Dominicana', N'2026-05-22 16:33:31.4581165', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (350, 359, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: IPQOZB LLC; Ave. Ponce de Leon 1259; San Juan, PR 00907', N'2026-05-22 16:33:31.4581165', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (351, 360, N'Terms: Net 75 days | Sub-jobs: 74 | Bill To: iPR Pharmaceuticals, Inc.; Accounts Payable Section; PO Box 1624; Canóvanas, PR 00729-1624', N'2026-05-22 16:33:31.4591921', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (352, 361, N'Bill To: Iron Mountain; PR 887 Interior B1,; Martin Gonzales Industrial Park; Carolina, PR', N'2026-05-22 16:33:31.4594934', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (353, 362, N'Terms: Due on receipt | Tax: Non | Bill To: ISN; PO Box 1089; Florida, PR 00650', N'2026-05-22 16:33:31.4594934', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (354, 363, N'Terms: Net 30 | Balance: 12500, Total: 12500 | Sub-jobs: 2 | Bill To: J&E Construction Developers LLC.; Parque de torrimar calle 8 c-3; Bayamon PR 00959', N'2026-05-22 16:33:31.4605773', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (355, 364, N'Terms: Net 30 | Tax: Non | Sub-jobs: 6 | Bill To: Juan F. García, Inc.; PO Box 1549; Guaynabo, PR 00970-1549', N'2026-05-22 16:33:31.4605773', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (356, 365, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: Jays and Fancy Management Services LLC; 450 Ave. Esmeralda, Suite 3; Guaynabo, PR 00969-3463', N'2026-05-22 16:33:31.4605773', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (357, 366, N'Terms: Net 30 | Tax: Non | Sub-jobs: 6 | Bill To: JCR Electrical Contractor; Po Box 2352; Vega Baja, PR 00694', N'2026-05-22 16:33:31.4615102', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (358, 367, N'Tax: Non | Bill To: Suite 112 MSC 428; 400 Gran Boulevard Paseo; San Juan; PR; 00926-5955', N'2026-05-22 16:33:31.4615102', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (359, 368, N'Tax: Non | Bill To: PO BOX 1908; Carolina; PR; 00984-1908', N'2026-05-22 16:33:31.4622323', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (360, 369, N'Terms: Net 30 | Tax: Non | Bill To: JJC Industrial Services, Inc.; Las Violetas #3-C; Vega Alta, PR 00692', N'2026-05-22 16:33:31.4622323', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (361, 370, N'Terms: Due on receipt | Tax: Non | Bill To: John Bader; Ritz Carlton Reserve-Villa 2100, 200; Dorado Beach Drive; Dorado, PR', N'2026-05-22 16:33:31.4622323', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (362, 371, N'Terms: Net 75 days | Sub-jobs: 4 | Bill To: Johnson Controls; 1405 Calle Rio Danubio; Sabana Abajo Ind. Park; Carolina, PR 00982-1705', N'2026-05-22 16:33:31.4635301', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (363, 372, N'Terms: Net 75 days | Balance: 7500, Total: 32370 | Sub-jobs: 26 | Bill To: Jones Lang LaSalle Puerto Rico Inc; MailStop#42103-1618068; Mail Bin CSCF; 700 Oakmont Lane, 3rd Floor; Westmont IL 60559', N'2026-05-22 16:33:31.4642563', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (364, 373, N'Terms: Net 75 days | Tax: Non | Sub-jobs: 19 | Bill To: Jones Lang LaSalle Puerto Rico Inc; Jones Lang LaSalle Puerto Rico Inc; Mailstop: 486765-1618068; #27 Calle Gonzalez Giusti; Suite 101 Guaynabo', N'2026-05-22 16:33:31.4642563', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (365, 374, N'Terms: Net 75 days | Balance: 2400, Total: 38832.5 | Sub-jobs: 14 | Bill To: Jones Lang LaSalle; MailStop: 47112-1618068; 700 Oakmont Lane, 3rd Floor; Westmont IL 60559', N'2026-05-22 16:33:31.4642563', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (366, 375, N'Terms: Net 105 Days | Tax: Non | Sub-jobs: 6 | Bill To: Jones Lang LaSalle Puerto Rico Inc; Mail Stop #49904-1618068; Ethicon LLC, San Lorenzo, PR; PR 183 Km 8.3; San Lorenzo, PR', N'2026-05-22 16:33:31.4655412', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (367, 376, N'Terms: Net 75 days | Sub-jobs: 6 | Bill To: Jones Lang LaSalle; Mailstop 49904- 1618068; 27 Gonzalez Giusti St.; Suite 101 Guaynabo, PR 00968', N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (368, 377, N'Terms: Net 75 days | Tax: Non | Sub-jobs: 49 | Bill To: Jones Lang LaSalle Puerto Rico, Inc.; Mailstop# 47112-1618068; Mail Bin CSCF; 700 Oakmont Lane 3rd Floor; Westmont, IL 60559', N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (369, 378, N'Terms: Net 30 | Balance: 7300, Total: 7300 | Sub-jobs: 2 | Bill To: L&R Engineering Group, LLC; 1519 Ave. Ponce de Leon Suite 1120; San Juan, PR 00909', N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (370, 379, N'Tax: Non | Bill To: PO Box 444; Saint Just Station; Saint Just; PR; 978', N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (371, 380, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: Las Brisas Property Management; Metro Office Park 8 St 1 Suite 300; Guaynabo, PR 00968-1713', N'2026-05-22 16:33:31.4660086', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (372, 381, N'Tax: Non | Bill To: PO Box 3669999; San Juan; PR', N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (373, 382, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Lemartec USVI; 4002 Raphune Hill Rd; Suite 401; St. Thomas, VI 00802', N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (374, 383, N'Terms: 1% 10 Net 30 | Sub-jobs: 48 | Bill To: Lilly del Caribe, Inc.; Post Office Box 1198; Carolina, PR 00986-1198', N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (375, 384, N'Terms: Net 60 | Sub-jobs: 6 | Bill To: Lord Electric Co. of Puerto Rico, Inc.; PO Box 363408; San Juan,PR 00936-3408', N'2026-05-22 16:33:31.4675479', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (376, 385, N'Terms: Due on receipt | Tax: Non | Bill To: Los Orígenes Power Plant; Calle César Iglesias #1; Punta Garza; San Pedro de Macorís; República Dominicana', N'2026-05-22 16:33:31.4687128', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (377, 386, N'Terms: Net 30 | Bill To: Luis A. Ayala Colon Tucrs Inc.; PO BOX 7066; PONCE, PUERTO RICO 00732', N'2026-05-22 16:33:31.4687128', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (378, 387, N'Terms: Net 45 days | Sub-jobs: 2 | Bill To: LUMA ENERGY SERVCO, LLC; 1250 Avenida de la Constitución,; 8th Floor; San Juan, PR 00907', N'2026-05-22 16:33:31.4695543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (379, 388, N'Tax: Non | Bill To: Mac Climber Rental; PO Box 1577; Guaynabo, PR 00970', N'2026-05-22 16:33:31.4695543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (380, 389, N'Terms: Due on receipt | Tax: Non | Bill To: Maderera Donestevez; PO Box 29228; San Juan, PR 00929', N'2026-05-22 16:33:31.4695543', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (381, 390, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: Maglez Engineering and Contractors Corp.; Box 1174; Florida, PR 00650', N'2026-05-22 16:33:31.4708141', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (382, 391, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: MAKRO, Corp.; # 1761 PR-8838; San Juan, PR 00926', N'2026-05-22 16:33:31.4714935', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (383, 392, N'Terms: Net 30 | Tax: Non | Bill To: MARBELLA CLUB OF HOMEOWNERS ASSOCIATION', N'2026-05-22 16:33:31.4714935', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (384, 393, N'Tax: Non | Bill To: Marriott Hotel', N'2026-05-22 16:33:31.4714935', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (385, 394, N'Terms: Net 30 | Tax: Non | Bill To: Marriott''s Frenchman''s Cove; 7338 Estate Bakkeroe; St. Thomas, Virgin Islands 00802-3011', N'2026-05-22 16:33:31.4730639', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (386, 395, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: MARRIOTT''S ST. KITTS BEACH CLUB; 858 Zenway Boulevard; Frigate Bay, St. Kitts.', N'2026-05-22 16:33:41.1103577', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (387, 396, N'Terms: Due on receipt | Tax: Non | Bill To: Marvel Designs; 161 Calle San Jorge; San Juan, PR 00911', N'2026-05-22 16:33:41.1103577', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (388, 397, N'Terms: Due on receipt | Bill To: Mastec Renewables Puerto Rico, LLC; 8 Rosendo Vela Acosta Ave.; Carolina, PR 00987', N'2026-05-22 16:33:41.1112844', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (389, 398, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Matosantos Commercial Corp.; D. Cabo Caribe Industrial Park; Calle A Lote 23; Vega baja, PR 00693', N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (390, 399, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Mattcon General Contractors, Inc.; 5460 W 84th St.; Indianapolis, IN 46268', N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (391, 400, N'Tax: Non | Bill To: Maximo Solar Industries, Inc.; PO Box 3062; Aguadilla, PR 00605', N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (392, 401, N'Terms: Net 90 days | Balance: 0, Total: 8105 | Sub-jobs: 2 | Bill To: McNeil Healthcare LLC; Kenvue Invoice Mailroom; 700 Distribution Drive; Atlanta, GA 30336', N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (393, 402, N'Terms: Net 90 days | Balance: 2622.5, Total: 2622.5 | Sub-jobs: 7 | Bill To: Medtronic Puerto Rico Operations Co.; PO Box 778; Minneapolis , MN 55440', N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (394, 403, N'Terms: Net 30 | Balance: 850, Total: 850 | Sub-jobs: 23 | Bill To: Mentor Technical Group; PO Box 6857; Caguas, PR 00726-6857', N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (395, 404, N'Terms: Net 30 | Tax: Non | Balance: 2015, Total: 2015 | Bill To: MERCANTIL SAN PATRICIO ASSOCIATES; PO Box 11924; San Juan, PR 00922-1924', N'2026-05-22 16:33:41.1119008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (396, 405, N'Terms: Net 15 | Tax: Non | Sub-jobs: 2 | Bill To: Merck Las Piedras Operations; PO Box 2013; Las Piedras, PR 00771', N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (397, 406, N'Terms: Net 30 | Sub-jobs: 17 | Bill To: Metro Health Care Management System, Inc.; PO Box 9976 Cotto Station; Arecibo, PR 00613', N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (398, 407, N'Tax: Non | Bill To: Office 301-B; Metro Medical Center Bldg B; Bayamon; PR', N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (399, 408, N'Tax: Non | Bill To: Urb Dos Pinos; Calle Lince #820; San Juan; PR', N'2026-05-22 16:33:41.1137719', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (400, 409, N'Tax: Non | Bill To: 100 Airside Drive; Moon Twp.; PA; 15108', N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (401, 410, N'Terms: Net 30 | Tax: Non | Balance: 2080, Total: 2080 | Bill To: Millennium Institute For Advance Nursing; Care, Inc.; Calle Cosme Reparto | San Lucas, Entrada; Sector Canejas, San Juan, PR', N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (402, 411, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Molina Healthcare of Puerto Rico; 654 Plaza Luis Muñoz Rivera Avenue; San Juan, Puerto Rico 00918', N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (403, 412, N'Tax: Non | Bill To: 1121 Américo Miranda Ave.; San Juan; PR; 00921-8322', N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (404, 413, N'Terms: Due on receipt | Tax: Non | Bill To: MRG Factory; Estadio Roberto Clemente Walker Marginal; Trujillo Bajo; Carolina, PR 00985', N'2026-05-22 16:33:41.1157915', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (405, 414, N'Terms: Due on receipt | Sub-jobs: 2 | Bill To: Multy Medical Facilities Corp.; PO Box 191643; San Juan, PR 00919-1643', N'2026-05-22 16:33:41.1181245', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (406, 415, N'Tax: Non | Bill To: PO Box 1806; Cidra; PR; 739', N'2026-05-22 16:33:41.1181245', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (407, 416, N'Terms: Net 30 | Balance: 1420, Total: 1420 | Sub-jobs: 2 | Bill To: National Engineering, Inc.; Ave Boulevard #1559; Toa Baja, PR 00949', N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (408, 417, N'Terms: Due on receipt | Tax: Non | Balance: 850, Total: 850 | Sub-jobs: 2 | Bill To: National Maintenance & Build Out Company; 1044 Pulinski Road; Ivyland, PA 18974', N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (409, 418, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: National Park Service; 501 Calle Norzagaray; San Juan PR 00901', N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (410, 419, N'Terms: Net 30 | Sub-jobs: 5 | Bill To: National Real Estate Management Corp; 9986 Manchester Road; Glendale, MO 63122', N'2026-05-22 16:33:41.1185706', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (411, 420, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Native Energy & Technology, Inc.; 12793 Cogburn Ave.; San Antonio, TX 78249', N'2026-05-22 16:33:41.1198307', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (412, 421, N'Tax: Non | Bill To: 5142 State Hwy FF; Fordland; MO; 65652', N'2026-05-22 16:33:41.1198307', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (413, 422, N'Tax: Non | Bill To: 499 Avenida Munoz Rivera esq.; San Juan; PR; 901', N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (414, 423, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Novel Enterprises Corp; 352 Ave San Clauidio; PMB 172; San Juan, PR 00926', N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (415, 424, N'Terms: Net 60 | Balance: 3823, Total: 3823 | Sub-jobs: 2 | Bill To: NOVOTECH PUERTO RICO, INC.; PO Box 8230; San Juan, PR 00910-0230', N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (416, 425, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: NPS, SER - South MABO; 40001 SR 9336; Homestead FL 33034', N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (417, 426, N'Terms: Net 30 | Sub-jobs: 4 | Bill To: O''Reilly Auto Parts; 233 South Patterson Ave.; Springfield, MO. 65802', N'2026-05-22 16:33:41.1205042', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (418, 427, N'Terms: Net 30 | Bill To: OCM PR LLC; Zeno Gandia Industrial Park; Road 129, Km 41.0; Arecibo, PR 00612', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (419, 428, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Ocyon Bio PR Inc.; Calle George Sanders; Aguadilla, PR 00603 US', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (420, 429, N'Terms: Net 30 | Tax: Non | Bill To: Omega Market Research Corp.; Angora Industrial Park Bldg 3; km 33.3 Road 1 Avenue Bairoa Ward; Caguas PR 00725', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (421, 430, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: ONE CONDADO LLC; Urb. Industrial Víctor Fernández; 340 Calle 3 Suite 1; San Juan, PR 00926', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (422, 431, N'Terms: Due on receipt | Tax: Non | Balance: 5248.88, Total: 5248.88 | Bill To: Oneida Technical Solutions; 1710 Tablonal; Carr. 4441 Km. 0.6; Aguada, PR 00602', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (423, 432, N'Terms: Net 30 | Tax: Non | Bill To: ONG Contractor, Inc.; PO Box 1724; Manatí, PR 00674', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (424, 433, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: OPHIRA Corp.; Villa Caribe 279; Via Canada; Caguas, PR 00727', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (425, 434, N'Tax: Non | Bill To: PMB 705; 89 De Diego Ave. Suite 105; San Juan; PR; 927', N'2026-05-22 16:33:41.1218508', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (426, 435, N'Tax: Non | Bill To: PO Box 363232; San Juan; PR; 00936-3232', N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (427, 436, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Oriental Bank; PO box 195115; San Juan, PR 00919-5115', N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (428, 437, N'Tax: Non | Bill To: PO Box 1120; Mayaguez; PR; 681', N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (429, 438, N'Terms: Net 90 days | Sub-jobs: 6 | Bill To: Ortho Biologics; PO Box 16571; New Brunswick, NJ 08906-6571', N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (430, 439, N'Terms: Net 30 | Balance: 0, Total: 6800 | Sub-jobs: 3 | Bill To: OVERALL Contractors Group, Inc.; PO Box 9195; Caguas, PR 00726-9195', N'2026-05-22 16:33:41.1238705', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (431, 440, N'Terms: Net 90 days | Sub-jobs: 21 | Bill To: Pall Life Science PR, LLC; PO Box 729; Fajardo, PR 00738', N'2026-05-22 16:33:41.1258902', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (432, 441, N'Terms: Net 75 days | Sub-jobs: 42 | Bill To: Patheon Puerto Rico Inc.; c/o Thermo Fisher Scientific; PO Box 40017; College Station, TX 77842', N'2026-05-22 16:33:41.1258902', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (433, 442, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: PAVARINI CONSTRUCTION & DEVELOPMENT, INC; SUITE 102; 165 PONCE DE LEON AVE.; SAN JUAN, PUERTO RICO 00918', N'2026-05-22 16:33:41.1258902', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (434, 443, N'Terms: Net 30 | Balance: 0, Total: 4160 | Sub-jobs: 3 | Bill To: Attn: Cuentas a Pagar Peerless; Oil and Chemicals, Inc. 671; Carretera 337; Peñuelas, PR 00624', N'2026-05-22 16:33:41.1269256', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (435, 444, N'Tax: Non | Balance: 343.63, Total: 343.63 | Bill To: Pegasus Trucking LLC; 15001 S. Figueroa St.; Gardena, CA 90248', N'2026-05-22 16:33:41.1272582', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (436, 445, N'Terms: Net 30 | Tax: Non | Contact: Accounts Payable | Sub-jobs: 12 | Bill To: Pepsi-Cola Manufacturing Limited; PO Box 1558; Cidra, PR 00739-1558', N'2026-05-22 16:33:41.1272582', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (437, 446, N'Terms: Net 90 days | Tax: Non | Sub-jobs: 30 | Bill To: PF Consumer Healthcare B. V.; (Puerto Rico Operations) LLC; State Road No. 3, KM. 141.3; Guayama, PR 00784', N'2026-05-22 16:33:41.1272582', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (438, 447, N'Terms: Net 30 | Sub-jobs: 24 | Bill To: Pfizer Pharmaceuticals, LLC; GFSS-Americas; PO Box 34600; Barlett, TN 38184-0600', N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (439, 448, N'Bill To: Inspecciones Misc.', N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (440, 449, N'Terms: Net 30 | Tax: Non | Contact: Encargado Edificio | Bill To: Plaza Escorial; Calle Américo Capó 6811; Ponce, PR', N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (441, 450, N'Tax: Non | Bill To: Santa Isabel; PR', N'2026-05-22 16:33:41.1294232', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (442, 451, N'Tax: Non | Bill To: Plaza Matienzo; Trujillo Alto; PR; 976', N'2026-05-22 16:33:41.1314456', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (443, 452, N'Terms: Net 30 | Tax: Non | Bill To: Polymers International Ltd.; Queen''s Highway, PO Box F-42684; Freeport, Grand Bahama Island,; The Bahamas', N'2026-05-22 16:33:41.1314456', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (444, 453, N'Terms: Due on receipt | Tax: Non | Bill To: PONTIFICAL CATHOLIC UNIVERSITY OF PR; 2250 Boulevard Luis A. Ferré Suite 524; Ponce, PR 00717-0655', N'2026-05-22 16:33:41.1314456', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (445, 454, N'Terms: Due on receipt | Tax: Non | Balance: 150, Total: 150 | Bill To: Powerhouse Retail Services; 812 South Crowley Road, Suite A; Crowley, TX 76036', N'2026-05-22 16:33:41.1328280', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (446, 455, N'Terms: Due on receipt | Tax: Non | Sub-jobs: 2 | Bill To: PPC; 6 Carr. 696 Dorado,; PR 00646-3306', N'2026-05-22 16:33:41.1334654', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (447, 456, N'Terms: Net 15 | Tax: Non | Sub-jobs: 9 | Bill To: PPG Architectural Coatings PR, Inc.; PO Box 94995; Cleveland, OH 44101-4995', N'2026-05-22 16:33:41.1334654', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (448, 457, N'Terms: Net 30 | Tax: Non | Sub-jobs: 7 | Bill To: PR Hospital Supply, Inc.; PO BOX 158; Carolina; PR 00986-0158', N'2026-05-22 16:33:41.1344219', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (449, 458, N'Terms: Net 30 | Bill To: PR Maritime Group, LLC; 151 Calle de San Francisco; STE 200 PMB 1651; San Juan, PR 00901', N'2026-05-22 16:33:41.1344219', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (450, 459, N'Terms: Net 30 | Tax: Non | Balance: 186684.13, Total: 186684.13 | Contact: President | Bill To: Prime Fire Dominicana, S.R.L.; RNC#: 130680622; Ave. Abraham Lincoln Centro Comercial; Plaza Lincoln. Local #12; Santo Domingo, República Dominicana', N'2026-05-22 16:33:41.1344219', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (451, 460, N'Tax: Non | Bill To: PRIME FIRE LLC; AUSTIN, TX', N'2026-05-22 16:33:41.1354855', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (452, 461, N'Terms: 2% 10 Net 30 | Tax: Non | Bill To: PO Box 1288; Trujillo Alto, PR; 00977-1288 | Ship To: Carr. # 3 km 142.5; Guayama, PR 00784-0000; Postal:; PO Box 1290; Guayama, PR 00785-1290', N'2026-05-22 16:33:41.1354855', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (453, 462, N'Terms: Due on receipt | Balance: 5128.57, Total: 5128.57 | Sub-jobs: 7 | Bill To: Prime Services Corp.; PO Box 1288; Trujillo Alto, PR 00977-1288', N'2026-05-22 16:33:41.1364406', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (454, 463, N'Terms: Net 30 | Tax: Non | Bill To: Print 1, LLC; PO Box 98; Las Piedras, PR 00771-0098', N'2026-05-22 16:33:41.1364406', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (455, 464, N'Terms: Net 30 | Tax: Non | Sub-jobs: 3 | Bill To: Professional Engineering Concepts; 100 Road 165 Suite 601; Guaynabo PR 00968', N'2026-05-22 16:33:41.1364406', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (456, 465, N'Tax: Non | Contact: President | Bill To: Metro Medical Center; Carr. 2 Km 12.3 Hnas Davila; Bayamon; PR; 959 | Ship To: Claim Metro Medical,Bayamon Due 1-31-2013', N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (457, 466, N'Terms: Net 15 | Tax: Non | Bill To: ProHealth Infusion; Metro Medical Center Edificio B; Suite 303; Bayamón, PR 00959', N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (458, 467, N'Terms: Net 30 | Balance: 0, Total: 19700 | Sub-jobs: 4 | Bill To: Project Engineering SP; PO Box 11619; Caparra Heights Sta.; San Juan, PR 00922', N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (459, 468, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Promech Mechanical; PO Box 851; Yauco, PR 00698', N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (460, 469, N'Tax: Non | Bill To: BMS', N'2026-05-22 16:33:41.1375058', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (461, 470, N'Terms: Due on receipt | Tax: Non | Sub-jobs: 2 | Bill To: PSA Construction, Inc.; William Burgos; Urb Vista Mar C 33; Guayama, Puerto Rico 00784', N'2026-05-22 16:33:41.1395260', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (462, 471, N'Terms: Due on receipt | Tax: Non | Bill To: PSI Construction Co., Inc.; PMB 1183; PO Box 4956; Caguas, PR 00726-4956', N'2026-05-22 16:33:49.1311747', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (463, 472, N'Tax: Non | Bill To: PO Box 730; Las Piedras; PR; 771', N'2026-05-22 16:33:49.1311747', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (464, 473, N'Terms: Net 28 days | Sub-jobs: 2 | Bill To: Range Development; 33 Kennedy Avenue,; P O Box 1976,; Roseau, Commonwealth of Dominica', N'2026-05-22 16:33:49.1317008', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (465, 474, N'Terms: Net 15 | Tax: Non | Bill To: Rayos X Centro 4; Edif Centro 4; Exp Trujillo Alto; TRUJILLO ALTO, PR 00977', N'2026-05-22 16:33:49.1320236', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (466, 475, N'Terms: Net 30 | Tax: Non | Contact: President | Sub-jobs: 8 | Bill To: RC Professionals & Construction Service; PO Box 427; Coamo, PR 00769', N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (467, 476, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: RC Specialties & Sheetmetal, Corp.; PO Box 338; Mercedita, PR 00715', N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (468, 477, N'Terms: Due on receipt | Tax: Non | Bill To: Reparto Industrial Barreras, LLC; PO Box 190406; San Juan, PR 00919', N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (469, 478, N'Terms: Net 30 | Balance: 191.9, Total: 191.9 | Sub-jobs: 6 | Bill To: Reva Construction Corp.; PO Box 1338; Jayuya,PR 00664', N'2026-05-22 16:33:49.1323371', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (470, 479, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: RF Management Solutions, LL; Fernando Santiago; PO Box 2075; Aibonito, PR 00705', N'2026-05-22 16:33:49.1339377', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (471, 480, N'Terms: Net 30 | Bill To: RG Engineering, Inc.; 605 Condado St. Ste. 322; San Juan, PR 00907', N'2026-05-22 16:33:49.1342507', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (472, 481, N'Terms: Due on receipt | Sub-jobs: 2 | Bill To: RG Mechanical, Inc.; Calle B Buzon 26; Ensenada, PR 00647', N'2026-05-22 16:33:49.1342507', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (473, 482, N'Terms: Net 30 | Tax: Non | Bill To: Rockwell Automation; Zona Franca; Santo Domingo; Dominican Republic', N'2026-05-22 16:33:49.1342507', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (474, 483, N'Terms: Net 30 | Tax: Non | Bill To: Roth Bros., Inc.; 3847 Crum Road; Youngstown, OH 44515', N'2026-05-22 16:33:49.1359582', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (475, 484, N'Terms: Due on receipt | Tax: Non | Bill To: Royal Properties; Carr Royal Industrial Park #869; Bo. Palmas; Cataño, PR 00968', N'2026-05-22 16:33:49.1359582', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (476, 485, N'Terms: Net 30 | Tax: Non | Bill To: Royals Contractors, Inc.; P.O. Box 10069; Humacao, Puerto Rico 00792', N'2026-05-22 16:33:49.1367643', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (477, 486, N'Tax: Non | Bill To: PO BOX 4574; VEGA BAJA; PR; 00694-4574', N'2026-05-22 16:33:49.1367643', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (478, 487, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: RSEG Corp.; 405 Esmeralda Ave. PMB 418; Guaynabo, PR 00969', N'2026-05-22 16:33:49.1367643', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (479, 488, N'Terms: Net 30 | Tax: Non | Bill To: SACHSE CONSTRUCTION; 1528 Woodward Suite 600; Detroit, MI 48226', N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (480, 489, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: Saint Luke''s Memorial Hospital, Inc; Att Acct. Payable; PO Box 332031; Ponce, PR 00733-6810', N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (481, 490, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: SB Apartments, Inc.; PO Box 957; Manatí, PR 00674', N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (482, 491, N'Terms: Net 30 | Tax: Non | Bill To: Schneider Electric; 1215 San Dario Ave. Ste. 4-702; Laredo, TX 78040', N'2026-05-22 16:33:49.1379774', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (483, 492, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Seasons Construction LLC; PO Box 193899; San Juan, PR 00919-3899', N'2026-05-22 16:33:49.1394438', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (484, 493, N'Terms: Due on receipt | Bill To: Serpa Fire Sprinkler Systems; Emilia Ab 11 Urb Villa Rica; Bayamón, PR 00959', N'2026-05-22 16:33:49.1397607', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (485, 494, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Serralles Construction Corp.; P. O. BOX 801072; COTO LAUREL, P.R. 00780', N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (486, 495, N'Tax: Non | Bill To: PO Box 1904010; San Juan; PR; 00919-0410', N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (487, 496, N'Terms: Net 30 | Balance: 0, Total: 12000 | Sub-jobs: 5 | Bill To: SHARETECH GROUP ENGINEERING , PSC; PO BOX 1330; Caguas, PR 00726-1330', N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (488, 497, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: Sheraton PR Convention Center; 200 Convention Blvd; San Juan, PR 00907; USA', N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (489, 498, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Sigari, Corp.; P.O. BOX 330627; Ponce,PR 00733-0627', N'2026-05-22 16:33:49.1401281', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (490, 499, N'Terms: Due on receipt | Tax: Non | Bill To: Sigfredo Carrero', N'2026-05-22 16:33:49.1415830', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (491, 500, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Skalar Pharma, LLC; State Road 53, KM 82 Bo. Jobos Exit 83; Guayama, PR 00784', N'2026-05-22 16:33:49.1420140', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (492, 501, N'Tax: Non | Bill To: PO Box 8780; San Juan; PR; 910', N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (493, 502, N'Terms: Net 30 | Balance: 0, Total: 43230 | Sub-jobs: 2 | Bill To: SLSCO, LTD; Akyna Pro Building Suite 301; San Juan, PR 00927', N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (494, 503, N'Terms: Net 30 | Tax: Non | Bill To: Smart Integrated Engineering Solutions; PO Box 4956 PMB 1115; Caguas, PR 00726 US', N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (495, 504, N'Terms: Net 30 | Tax: Non | Bill To: Sodexo Citi; 235 Federico Costa,; San Juan, PR 00918', N'2026-05-22 16:33:49.1425468', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (496, 505, N'Terms: Net 30 | Sub-jobs: 70 | Bill To: Sodexo c/o Pfizer; Attn. Edgard Quinones; Carr 2 KM 58.2; Barceloneta PR 00617', N'2026-05-22 16:33:49.1440333', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (497, 506, N'Terms: Net 30 | Sub-jobs: 17 | Bill To: Sodexo c/o Pfizer; Carr. 3, Km. 142.1; Guayama 00784-4119; Puerto Rico', N'2026-05-22 16:33:49.1440333', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (498, 507, N'Terms: Net 30 | Sub-jobs: 3 | Bill To: South Dade Air Conditioning; & Refrigeration, Inc.', N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (499, 508, N'Tax: Non | Bill To: PO Box 998; Caguas; PR; 00726-0998', N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (500, 509, N'Terms: Net 15 | Tax: Non | Bill To: Stantec Engineering PR P.S.C.; Metro Office Park Suite 305 Calle 1; Guaynabo, PR 00968-1705', N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (501, 510, N'Terms: Due on receipt | Tax: Non | Sub-jobs: 2 | Bill To: Starmec Contractors Inc.; PO Box 851; PMB 274; Humacao, PR 00972-0851', N'2026-05-22 16:33:49.1445697', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (502, 511, N'Terms: Due on receipt | Sub-jobs: 2 | Bill To: Stop Fire Corp.; Bayamon, PR 00957', N'2026-05-22 16:33:49.1460521', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (503, 512, N'Tax: Non | Bill To: Atn. Javier Rivera; Salinas; PR', N'2026-05-22 16:33:49.1460521', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (504, 513, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Supermercados Econo; PO Box 4819; Carolina, PR 00984', N'2026-05-22 16:33:49.1460521', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (505, 514, N'Terms: Net 30 | Balance: 0, Total: 9550 | Sub-jobs: 3 | Bill To: Sustech, LLC; PO Box 1 4 9 3; T ruj i l lo A l to, PR 0 0 9 7 6', N'2026-05-22 16:33:49.1473669', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (506, 515, N'Terms: Due on receipt | Bill To: Swedish Match Dominicana S.A.; Cigar Division; Santiago Industrial Free Zone, Stage III; Santiago, DR PO Box 773', N'2026-05-22 16:33:49.1480038', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (507, 516, N'Terms: Due on receipt | Tax: Non | Sub-jobs: 2 | Bill To: Swidish Match Nevera', N'2026-05-22 16:33:49.1483956', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (508, 517, N'Terms: Net 45 days | Tax: Non | Balance: 150, Total: 150 | Bill To: SYNOVOS PUERTO RICO; 16888 State Route 706; Montrose, PA 18801', N'2026-05-22 16:33:49.1483956', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (509, 518, N'Terms: Net 15 | Bill To: Taller 06; 305 Villamil St Apt 510; San Juan, PR 00907', N'2026-05-22 16:33:49.1492325', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (510, 519, N'Sub-jobs: 2 | Bill To: TCG The Cornerstone Group, Inc; PO Box 3913Aguadilla, PR 00605', N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (511, 520, N'Sub-jobs: 2 | Bill To: TCM Group LLC; Caribe Office Center 2004; Carr 506 Suite 203; Ponce, PR 00780', N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (512, 521, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: Technical Distributors; PO Box 3826; Guaynabo, PR 00970', N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (513, 522, N'Terms: Net 60 | Balance: 0, Total: 15550 | Sub-jobs: 5 | Bill To: Teksol Integration Group, Inc.; PO Box 3308; Marina Station; Mayagüez, PR 00681-3308', N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (514, 523, N'Terms: Net 30 | Tax: Non | Bill To: Terrasol Engineering Group, LLC; PO Box 193852; San Juan, PR 00919-3852', N'2026-05-22 16:33:49.1496628', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (515, 524, N'Terms: Net 30 | Tax: Non | Sub-jobs: 33 | Bill To: Warner Chilcott Company, LLC; PO Box 1055; Manatí, PR 00674', N'2026-05-22 16:33:49.1518440', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (516, 525, N'Terms: Net 30 | Tax: Non | Bill To: The Lofts 2014; Calle Las Violetas; San Juan, PR 00915', N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (517, 526, N'Tax: Non | Bill To: The Reliable Sprinkler Co; 9591 Premier Parkway; Miramar, FL 33025', N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (518, 527, N'Tax: Non | Bill To: The Sembler Company; PO Box 110; Carolina, PR 00986', N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (519, 528, N'Terms: Net 30 | Sub-jobs: 2 | Bill To: TOPS Enterprises Corp.; 405 Ave. Esmeralda, Suite 2; Guaynabo, Puerto Rico 00969-4457', N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (520, 529, N'Terms: Net 45 days | Tax: Non | Balance: 0, Total: 7225 | Sub-jobs: 9 | Bill To: TURTLE & HUGHES INC.; 100 WALNUT AVE FL 4; CLARK, NJ 07066-1253', N'2026-05-22 16:33:49.1523631', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (521, 530, N'Terms: Due on receipt | Tax: Non | Bill To: TV Educational Park Management; Parque de las Ciencias 1550 Ave. Comerio; Bayamon, PR 00961', N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (522, 531, N'Tax: Non | Bill To: PO Box 11197; San Juan; PR; 00922-1197', N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (523, 532, N'Terms: Due on receipt | Bill To: Universidad Ana G. Méndez; Apartado 21150; San Juan, PR 00928-1150', N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (524, 533, N'Tax: Non | Bill To: PO Box 363255; San Juan; PR; 00936-3255', N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (525, 534, N'Terms: Net 30 | Bill To: VA Caribbean Healthcare System; 10 Casia Street; San Juan, PR 00921-3201', N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (526, 535, N'Tax: Non | Bill To: Ave. Wiston Churchill #175; San Juan; PR; 926', N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (527, 536, N'Terms: Net 30 | Tax: Non | Balance: 63250, Total: 63250 | Sub-jobs: 2 | Bill To: Venergy Group LLC; 3130 Seminole Road; Fort Pierce, Florida 34951', N'2026-05-22 16:33:49.1538651', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (528, 537, N'Terms: Net 90 days | Sub-jobs: 5 | Bill To: Viatris Pharmaceuticals LLC; KM 1.9 Road #689; Vega Baja, PR 00693', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (529, 538, N'Terms: Net 30 | Tax: Non | Bill To: Vidre Energias, Inc.; PMB 717 89 Ave De Diego Ste 105; San Juan, PR 00927', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (530, 539, N'Terms: Net 30 | Balance: 0, Total: 3206 | Sub-jobs: 7 | Bill To: Villavicencio & Associates Construction; PMB 303; 35 Juan C Borbon Ste 67; Guaynabo, PR 00969-5375', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (531, 540, N'Tax: Non | Bill To: PO Box 5403; Caguas; PR; 726', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (532, 541, N'Terms: Net 30 | Tax: Non | Bill To: West Fire & Safety Equipment; Carr #2 Km 135.3; Aguada, PR 00602', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (533, 542, N'Terms: Due on receipt | Bill To: Windsor Fashion; 1 Premium Outlets Blvd.; Barceloneta, PR 00617', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (534, 543, N'Terms: Net 30 | Tax: Non | Bill To: Wovenware; 1000 Calle Los Ángeles Suite 100; San Juan, PR 00909', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (535, 544, N'Terms: Net 30 | Tax: Non | Sub-jobs: 2 | Bill To: Yang Enterprises Inc.; HC 03 Box 53995; Arecibo, PR 00612', N'2026-05-22 16:33:49.1558867', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (536, 545, N'Terms: Net 15 | Tax: Non | Bill To: A/P Project No. 1110630; 2000 Regency Parkway, St 300; Cary; NC; 27518-8508', N'2026-05-22 16:33:49.1579073', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (537, 546, N'Terms: Due on receipt | Tax: Non | Bill To: Yumac Home Furniture; Bo. Puente Carr. 119 Km. 4.8 Zona Industr; Camuy, PR 00627-1035', N'2026-05-22 16:33:49.1579073', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (538, 547, N'Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: Diector of Engineering | Prefix: Ing. | Sub-jobs in source: 7 | Original Customer field: Renaissance-Jaragua Hotel & Casino | Bill To: Renaissance-Jaragua Hotel & Casino; Ave. George Washington 367, Santo Domingo; República Dominicana', N'2026-05-22 16:33:55.7486604', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (539, 548, N'RNC: 132-18353-3 | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: CEO | Prefix: Ms. | Original Customer field: SYSTEMIO, SRL | Bill To: SYSTEMIO, SRL; RNC: 132-18353-3; Ave. John F. Keneddy No. 88; Santo Domingo, Rep. Dominicana; (809) 332 - 1202', N'2026-05-22 16:33:55.7492586', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (540, 549, N'RNC: 101-63597-5 | Terms: Due on receipt | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Mr. | Original Customer field: Vendomática Dominicana, SRL | Bill To: Vendomática Dominicana, SRL; RNC:101-63597-5; Av. John F. Kennedy, Santo Domingo,; República Dominicana; (809) 542 - 7756', N'2026-05-22 16:33:55.7492586', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (541, 550, N'RNC: 102336669 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: ICONELSA, SRL | Bill To: ICONELSA, SRL; RNC:102336669; Av. Rincon Largo. Esq. 6, No. 6, Santiago; de los Caballeros, Rep. Dominicana; Tel. (809) 613 - 7312', N'2026-05-22 16:33:55.7492586', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (542, 551, N'RNC: 130-05080-5 | Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Contact Title: Buyer | Prefix: Mr. | Original Customer field: GILDAN DR | Bill To: Gildan DR; Zona Franca Bella Vista,Santo Domingo Est; República Dominicana; RNC: 130-05080-5', N'2026-05-22 16:33:55.7502477', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (543, 552, N'Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Original Customer field: Prime Services, Corp. | Bill To: Prime Services, Corp.; PO Box 1288, Trujillo Alto, PR; 00977-1288; Tel. (787) 761-3180', N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (544, 553, N'Terms: Due on receipt | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Original Customer field: Prime Fire Protection Corp. | Bill To: Prime Fire Protection, Corp.; PO Box 1288, Trujillo Alto, PR; 00977-1288; Tel. (787) 761-3180', N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (545, 554, N'RNC: 130-68062-2 | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 4 | Original Customer field: Administración | Bill To: Prime Fire Dominicana, SRL; RNC: 130-68062-2; Av. Abraham Lincoln Esq. Av. 27 de Febrer; Plaza Comercial Lincoln, Local #12; Phone: (809) 501-1900', N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (546, 555, N'RNC: 130-99490-2 | Terms: Net 30 | Currency: USD | Tax Code: Tax | Original Customer field: Pisan Electronic & Asoc., S.R.L. | Bill To: Pisan Electronic & Asoc., S.R.L.; RNC: 130-99490-2; Santiago de los Caballeros, R.D.; Tel.: (829) 296-8189; Infopisan.elec@gmail.com', N'2026-05-22 16:33:55.7506693', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (547, 556, N'RNC: 101-00157-7 | Terms: Net 30 | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 4 | Original Customer field: Compañia Dominicana de Teléfono,S.A. | Bill To: Compañia Dominicana de Teléfono, S.A.; RNC 101-00157-7; Av. John F. Kennedy #54, Santo Domingo; TEL (809) 220-1111', N'2026-05-22 16:33:55.7522568', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (548, 557, N'RNC: 130-24812-5 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Terms: Contra entrega | Currency: DOP | Tax Code: Tax | Original Customer field: Cristian Data Service CDS, SRL | Bill To: Cristian Data Service CDS, SRL; RNC: 130-24812-5; Tel.: (809) 697-4875; Santo Domingo, Rep.Dom.', N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (549, 558, N'Terms: Contra entrega | Currency: USD | Tax Code: Tax | Original Customer field: RAFAEL ANTONIO ACEVEDO MARTE | Bill To: Rafael A. Acevedo Marte; Ced.: 001-1708743-7; rafaelacevedo_m@outlook.com', N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (550, 559, N'RNC: 101-77200-1 | Address note: [extra] Industrial Free Zone, Las Américas, | Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Prefix: Ing. | Sub-jobs in source: 7 | Original Customer field: Care Fusion D R 203 LTD:PFD19-06 | Bill To: Becton, Dickinson and Company; CareFusion D R 203 LTD, RNC: 101-77200-1; Industrial Free Zone, Las Américas,; Santo Domingo, Dominican Republic; (809) 549 - 2222', N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (551, 560, N'RNC: 131-75300-2 | Terms: 100% in advance | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: CHT HOLDINGS DOMINICANA SAS | Bill To: CHT HOLDINGS DOMINICANA SAS; RNC: 131-75300-2; Bavaro, Punta Cana; Republica Dominicana', N'2026-05-22 16:33:55.7526855', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (552, 561, N'RNC: 114-07962-2 | Address note: [extra] mpservicios@claro.net.do | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: CEO | Prefix: Mr. | Sub-jobs in source: 14 | Original Customer field: MP Servicios, S.R.L. | Bill To: MP Servicios, SRL; RNC: 114-07962-2; C/ Cerifo #18, Buenos Aires, Mirador Sur,; Santo Domingo, D.N. República Dominicana; mpservicios@claro.net.do', N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (553, 562, N'RNC: 130-13374-3 | Terms: Contra entrega | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Inversiones Terrassa, SRL | Bill To: Inversiones Terrassa, SRL; RNC: 130-13374-3; Av. Romulo Betancourt, No. 1208,; Plaza Sahira 2Do Piso; Santo Domingo, República Dominicana', N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (554, 563, N'RNC: 130-88964-3 | Terms: Contra entrega | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Mr. | Sub-jobs in source: 2 | Original Customer field: Twenty-One Technology, EIRL | Bill To: Twenty-One Technology, EIRL; Robert Richard Rodriguez; RNC: 130-88964-3; Manzana 29, Local 27-B, Sto. Dgo.; Tel.: (809) 653-7501', N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (555, 564, N'RNC: 101-60117-5 | Terms: Net 60 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Ing. | Sub-jobs in source: 39 | Original Customer field: Frito Lay Dominicana, S.A.:PFD19-04 | Bill To: Frito Lay Dominicana, S.A.; RNC: 101-60117-5; Carr. Duarte, Km. 22 1/2, Zona Franca; Duarte, Santo Domingo, Rep. Dominicana; (829) 257 - 6938', N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (556, 565, N'Terms: Due on receipt | Currency: USD | Tax Code: Tax | Original Customer field: Carlos J. Benitez De Jesus | Bill To: Carlos J. Benitez De Jesus; Tel.: (849) 850-0122; Ced.: 402-2193705-1; benitefire74@gmail.com', N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (557, 566, N'RNC: 131-37801-3 | Terms: Contra entrega | Currency: DOP | Tax Code: Tax | Original Customer field: Weir Minerals Caribe, SRL | Bill To: Weir Minerals Caribe, SRL; RNC: 131-37801-3; Aut. Duarte Km. 22.5 Parque Ind. Duarte; Nave 4, Parque de Naves, Santo Domingo; Teléfono: (809) 330-8825', N'2026-05-22 16:33:55.7544254', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (558, 567, N'Terms: Due on receipt | Currency: USD | Tax Code: Tax | Original Customer field: MRJ Multiservices Solutions | Bill To: MRJ Multiservices Solutions, SRL; Rafael Morillo C.; Tel.:(809) 475-4200 / Mob.:(809) 440-8034; E-mail: rmorillo@grupomrj.com; www.grupomrj.com', N'2026-05-22 16:33:55.7564442', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (559, 568, N'Terms: Due on receipt | Currency: USD | Tax Code: Tax | Original Customer field: Jesus Almonte | Bill To: Jesus Almonte; Tel.: (829) 437-0471; anibalelfuelte1.7@hotmail.com', N'2026-05-22 16:33:55.7564442', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (560, 569, N'RNC: 101-58013-5 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: SAEG Engineering Group, SA | Bill To: SAEG Engineering Group, S.A.; RNC: 101-58013-5; Av. Tiradentes 21, Santo Domingo; Tel.: (809) 540-7234', N'2026-05-22 16:33:55.7564442', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (561, 570, N'Terms: Due on receipt | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Prefix: Mr. | Original Customer field: Puerto del Rey Boat Specialists | Bill To: Puerto del Rey Boat Specialists; Mr. Emilio Villanueva; Fajardo Puerto Rico.', N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (562, 571, N'RNC: 122-01122-6 | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Sub-jobs in source: 10 | Original Customer field: Induveca, S.A. | Bill To: Induveca, S.A.; RNC: 122-01122-6; Ave. Pedro A. Rivera Km. 3,; La Vega, Republica Dominicana; Phone: (809) 737-2500', N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (563, 572, N'RNC: 131-39827-8 | Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Sub-jobs in source: 3 | Original Customer field: Getinge Dominican Republic, S.A. | Bill To: Getinge Dominican Republic, S.A.; RNC: 131-39827-8; Km.18½, Carretera Sanchez, Parque; Industrial ITABO Haina, San Cristobal; Phone: (829) 204-0067', N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (564, 573, N'RNC: 130-29966-8 | Terms: Due on receipt | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: ClickTeck, SRL | Bill To: ClickTeck, SRL; RNC: 130-29966-8; Tel.: (809) 567-1916; C/ Santa Rosa # 646; Santo Domingo, Rep. Dom', N'2026-05-22 16:33:55.7572121', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (565, 574, N'Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Sub-jobs in source: 5 | Original Customer field: Prime Fire LLC | Bill To: PRIME FIRE LLC; 340 TRAYNOR DR; Kyle, TX 78640; Tel. 512-262-6110', N'2026-05-22 16:33:55.7584643', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (566, 575, N'RNC: 1-30-93138-2 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Terms: Due on receipt | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: FirePro | Bill To: FirePro, SRL; RNC: 1-30-93138-2; C/Lorenzo Despradel #12, Los Prados; Santo Domingo, Republica Dominicana', N'2026-05-22 16:33:55.7584643', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (567, 576, N'RNC: 1-30-90341-7 | Terms: Due on receipt | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Prefix: Lic. | Original Customer field: Constructora Jimbrosa, SRL | Bill To: Constructora Jimbrosa, SRL; Av Los Próceres 1, Santo Domingo,; RNC: 1-30-90341-7; operaciones@rdpalmar.com', N'2026-05-22 16:33:55.7584643', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (568, 577, N'RNC: 1-31-65690-2 | Address note: [extra] operaciones@rdpalmar.com | Terms: Due on receipt | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Reservas del PalmarDR SRL | Bill To: Reservas del Palmar DR SRL; (Promotora Inmobiliaria); Diamond Mall, C/Euclides Morillo,; RNC: 1-31-65690-2, Santo Domingo; operaciones@rdpalmar.com', N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (569, 578, N'Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Original Customer field: Dirreccion General de Impuestos Internos | Bill To: DGII', N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (570, 579, N'RNC: 130-52928-2 | Terms: Net 30 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: Administrative Assistant II | Prefix: Ms | Sub-jobs in source: 2 | Original Customer field: IGT | Bill To: IGT; RNC: 130-52928-2; Avenida Estrella Sadhalá esquina Luperón; Edificio Haché, 1er nivel, Santiago; República Dominicana', N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (571, 580, N'Terms: Net 15 | Currency: USD | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: CEO | Prefix: Ing. | Original Customer field: Engineering & Fire Service, SRL | Bill To: Engineering & Fire Service, SRL; C/ Rosendo Alvarez #8A,, Ens. Claret,; Santo Domingo, República Dominicana; (809) 683-8016', N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (572, 581, N'RNC: 101-00099-6 | Terms: Net 30 | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: Owner | Prefix: Mr. | Original Customer field: CASA NADER, C por A | Bill To: CASA NADER, C por A; RNC: 101-00099-6; Av. Tiradentes No. 40, Santo Domingo,; República Dominicana; Tel.: (809) 566 - 6111', N'2026-05-22 16:33:55.7592231', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (573, 582, N'RNC: 1-31-08219-1 | Terms: Net 90 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Contact Title: 809-295-6555 | Prefix: Ing. | Sub-jobs in source: 17 | Original Customer field: Swisher Dominicana, Inc.:PFD19-03 | Bill To: SWISHER DOMINICANA, INC; RNC: 1-31-08219-1; C/ Central Manzana A. Edificios 4,5 y 6.; Zona Franca Industrial De Santiago; Tel: 809-295-6555', N'2026-05-22 16:33:55.7604849', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (574, 583, N'RNC: 101-87475-9 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Currency: DOP | Tax Code: Tax | Original Customer field: Fire Technologies, S.R.L | Bill To: Fire Technologies, S.R.L; RNC: 101-87475-9; Calle Mauricio Baez 262, Santo Domingo; Tel.: (809) 472-6633', N'2026-05-22 16:33:55.7604849', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (575, 584, N'RNC: 101-89118-1 | Address note: DIRECCIÓN INFERIDA DE BILL TO | Terms: Due on receipt | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: Owner | Prefix: Lic | Sub-jobs in source: 4 | Original Customer field: Inversiones Omega, SRL | Bill To: Inversiones Omega, S.R.L.; RNC: 101-89118-1; Santo Domingo, Rep. Dominicana', N'2026-05-22 16:33:55.7604849', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (576, 585, N'RNC: 102-01007-2 | Terms: Net 30 | Currency: USD | Tax Code: Non | Tax Item: ITIBIS | Prefix: Ing. | Sub-jobs in source: 7 | Original Customer field: General Cigars Dominicana, S.A.S:PFD19-05 | Bill To: General Cigars Dominicana, S.A.S; RNC: 102-01007-2; C/ Jesus Alvarez Bogaert, 1ra Etapa; Zona Franca Industrial Santiago, R.D.; (809) 226 -2500', N'2026-05-22 16:33:55.7615405', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (577, 586, N'Terms: Net 30 | Currency: DOP | Tax Code: Tax | Tax Item: ITIBIS | Contact Title: Gerente de Operaciones | Prefix: Eng. | Sub-jobs in source: 2 | Original Customer field: Los Orígenes Power Plant, S.R.L. | Bill To: Los Orígenes Power Plant, S.R.L.; San PedroDe Macorís, República Dominicana', N'2026-05-22 16:33:55.7621621', NULL, 27)
INSERT [dbo].[customer_notes] ([customer_note_id], [customer_id], [note_text], [created_at], [updated_at], [created_by]) VALUES (578, 587, N'RNC: 101-56194-7 | Terms: Due on receipt | Currency: DOP | Tax Code: Non | Tax Item: ITIBIS | Contact Title: EHS&S Manager | Prefix: Eng. | Sub-jobs in source: 3 | Original Customer field: Rockwell Automation Technologies Inc. | Bill To: Rockwell Automation Technologies Inc.; RNC: 101-56194-7; Ave. Las Americas, Km. 22, Lot B-1 & B-2; Santo Domingo, República Dominicana', N'2026-05-22 16:33:55.7621621', NULL, 27)

SET IDENTITY_INSERT [dbo].[customer_notes] OFF
GO


-- departments: No data to insert


-- Data for roles (7 records)
SET IDENTITY_INSERT [dbo].[roles] ON
GO

INSERT [dbo].[roles] ([role_id], [role_name], [description]) VALUES (1, N'Admin', N'System Administrator with full access')
INSERT [dbo].[roles] ([role_id], [role_name], [description]) VALUES (2, N'Manager', N'Department manager with elevated permissions')
INSERT [dbo].[roles] ([role_id], [role_name], [description]) VALUES (3, N'User', N'Standard user with basic access')
INSERT [dbo].[roles] ([role_id], [role_name], [description]) VALUES (5, N'Jobs ', N'Administrador modulo Jobs')
INSERT [dbo].[roles] ([role_id], [role_name], [description]) VALUES (8, N'Admin_Tenants', N'Tenants')
INSERT [dbo].[roles] ([role_id], [role_name], [description]) VALUES (9, N'Beta_Tester', N'Grants access to selected in-development or preview features before they are generally available.')
INSERT [dbo].[roles] ([role_id], [role_name], [description]) VALUES (10, N'Business Proposals', N'Business Proposals')

SET IDENTITY_INSERT [dbo].[roles] OFF
GO


-- Data for employee_roles (79 records)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (1, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (2, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (2, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (3, 1)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (3, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (4, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (5, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (5, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (6, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (7, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (8, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (8, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (9, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (10, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (10, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (10, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (11, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (11, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (12, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (12, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (13, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (14, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (15, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (16, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (16, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (17, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (18, 1)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (18, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (18, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (18, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (19, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (20, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (21, 1)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (21, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (21, 8)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (22, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (23, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (24, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (25, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (26, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (27, 1)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (27, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (27, 8)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (27, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (28, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (28, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (29, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (30, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (31, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (32, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (33, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (33, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (34, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (35, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (36, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (37, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (38, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (39, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (39, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (39, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (40, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (41, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (42, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (42, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (43, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (43, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (44, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (44, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (45, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (46, 2)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (46, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (49, 1)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (49, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (49, 5)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (49, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (52, 3)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (54, 1)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (54, 9)
INSERT [dbo].[employee_roles] ([employee_id], [role_id]) VALUES (55, 3)
GO


-- Data for tenants (2 records)
SET IDENTITY_INSERT [dbo].[tenants] ON
GO

INSERT [dbo].[tenants] ([tenant_id], [name], [db_connection_key], [description], [is_active], [created_at]) VALUES (1, N'CLIENTE_A', N'CLIENTE_A', N'Created via user registration', 0, '2025-12-21 20:11:39')
INSERT [dbo].[tenants] ([tenant_id], [name], [db_connection_key], [description], [is_active], [created_at]) VALUES (3, N'DEVROMO', N'DEVROMO', N'Developers Romo', 1, '2026-01-12 00:00:00')

SET IDENTITY_INSERT [dbo].[tenants] OFF
GO


-- Data for external_users (2 records)
SET IDENTITY_INSERT [dbo].[external_users] ON
GO

INSERT [dbo].[external_users] ([external_user_id], [email], [password_hash], [tenant_id], [created_at]) VALUES (9, N'jcarlos.villa.rivera@gmail.com', N'$2b$12$86/wa5zSinRGMtad4BiNrO77K9zNAUPRTpQl3KtGABf6/E3LqS5hq', 3, '2026-01-14 03:02:16')
INSERT [dbo].[external_users] ([external_user_id], [email], [password_hash], [tenant_id], [created_at]) VALUES (10, N'info@devromo.com', N'$2b$12$Zq0QadTdL/6ESgImpwBxT.zKkVns1Wrqrj8W9LkKrSxYRHoEswynC', 3, '2026-01-14 13:19:21')

SET IDENTITY_INSERT [dbo].[external_users] OFF
GO


-- Data for hardware_inventory (26 records)
SET IDENTITY_INSERT [dbo].[hardware_inventory] ON
GO

INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (5, N'405QCSF568390', N'LG', N'LG PC', N'Laptop', N'Intel(R) Core(TM) Ultra 7 155H (1.4 GHz)', NULL, N'SSD', 1000, NULL, N'Windows 11 Pro', N'2025-01-01', N'2025-01-01', N'2025-01-01', 46, N'Trujillo  Alto', N'Active', N'Computadora de Kevin Lopez', '2025-11-17 22:13:57', '2025-11-25 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (6, N'601-7E07-030B2212003338', N'MILLENIUM', N'MILLENIUM', N'Laptop', N'13th Gen Intel(R) Core(TM)  i9-13900K (3.00 GHz)', NULL, N'SSD', 4000, NULL, N'Windows 11 Pro', N'2024-01-01', N'2026-01-01', N'2024-01-01', 45, N'Republica Dominicana', N'Active', N'es maquina de Luis Belliard', '2025-11-19 22:45:00', '2025-11-25 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (7, N'6CSMVN0', N'MS-7D07', N'MS-7D07', N'Desktop', N'Intel(R) Core(TM) i9-10850K CPU @ 3.60Ghz  ( 3.60Ghz)', NULL, N'SSD', 464, NULL, N'Windows 11 Pro', N'2025-01-01', N'2025-12-31', N'2025-12-31', 35, N'Guaynabo PR', N'Active', N'Esta com putadora es una maquina armada ', '2025-11-25 14:37:51', '2025-11-25 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (8, N'55F9HTU', N'MS-7E06', N'MS-7E06', N'Desktop', N'Intel iCore I9-14900K(3.20 Ghz)', NULL, N'SSD', 8000, NULL, N'Windows 11 Pro', N'2025-01-01', N'2025-12-31', N'2025-12-31', 23, N'Republica Dominicana', N'Active', N'Maquina Armada', '2025-11-26 00:21:51', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (9, N'KVBN8DJ', N'Z490 UD AC-Y1', N'Z490 UD AC-Y1', N'Desktop', N'Intel(R) Core-i7 10700K', NULL, N'SSD', 1375, NULL, N'Windows 10 Pro', N'2025-01-01', N'2025-12-31', N'2025-01-01', 19, N'Republica Dominicana', N'Active', N'Maquina on Hold desktop (diseño) en Republica Dominicana. Compuitadora Armada', '2025-11-28 16:38:03', '2025-12-20 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (10, N'5CD243JJ42', N'HP', N'Pavilion Laptop 15', N'Laptop', N'12th Gen Intel(R) Core(TM) i7-1255U', NULL, N'SSD', 475, NULL, N'Windows 11 Pro', N'2025-12-01', N'2025-12-01', N'2025-12-01', 16, N'Republica Dominicana', N'Active', N'Laptop de Geurys ', '2025-12-04 21:21:40', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (12, N'2MO4271TGM', N'HP', N'ENVY TE TE01', N'Laptop', N'Intel(R) Core(TM) i5-14400 (2.50 GHz)', NULL, N'SSD', 466, NULL, N'Windows 11 Pro', N'2025-01-01', N'2025-12-31', N'2025-01-01', 28, N'Trujillo Alto', N'Active', N'', '2025-12-08 15:30:11', '2025-12-22 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (13, N'PF5Z0QV1', N'Lenovo', N'Legión 5 16IAX10', N'Laptop', N'Intel(R) Core(TM) Ultra 9 275HX (2.7 GHz)', NULL, N'SSD', 951, NULL, N'Windows 11 Pro', N'2025-12-12', N'2026-12-14', N'2025-12-14', 43, N'República Dominicana ', N'Active', N'Laptop compartida William y Joskayra', '2025-12-16 14:39:23', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (14, N'0027234201758', N'DSK', N'Corsair Vengeance', N'Desktop', N'13th Gen Intel(R) Core(TM) i9-13900K (3.00 GHz)', NULL, N'SSD', 1820, NULL, N'Windows 11 Pro', N'2025-01-01', N'2025-12-31', N'2025-01-01', 2, N'Orlando, Florida', N'Active', N'Maquina desktop de Adolfo', '2025-12-22 13:53:29', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (15, N'et8259-2152', N'CiberPowerPC', N'Gaming PC ', N'Desktop', N'Intel(R) Core(TM) Ultra 9 285K (3.7 GHz)', NULL, N'SSD', 1810, NULL, N'Windows 11 Pro', N'2025-01-01', N'2025-12-31', N'2025-01-01', 38, N'Guaynabo', N'Active', N'Máquina de Escritorio ', '2025-12-22 14:14:36', '2025-12-22 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (16, N'7FJBYS3', N'DELL', N'Inspirion 3910', N'Laptop', N'12th Gen Intel(R) Core(TM) i5-12400 (2.50 Ghz)', NULL, N'SSD', 1140, NULL, N'Windows 11 Pro', N'2025-01-01', N'2025-12-31', N'2025-12-01', 44, N'Guaynabo', N'Active', N'Laptop de Wilnelia', '2025-12-22 17:55:58', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (17, N'0F34MHY25013HJ', N'Micrsosoft Surface', N'7 Edition', N'Laptop', N'Snapdragon(R) X 12-core X1E80100 @ 3.40 GHz (3.42 GHz)', NULL, N'NVMe', 954, NULL, N'Windows 11 Pro', N'2025-06-01', N'2026-06-01', N'2025-06-01', 12, N'Trujillo Alto', N'Active', N'Laptop de Elizaud', '2025-12-23 14:01:15', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (19, N'NA ', N'NA - Pending', N'NA - Pending ', N'Desktop', N'Intel(R) Core (TM) i5-8400 CPU @ 2.800Ghz ', NULL, N'HDD', 224, NULL, N'Windows 10 Pro', N'2023-01-01', N'2024-01-01', N'2023-01-01', 12, N'Trujillo Alto', N'Active', N'Desktop de Elizaud Pc de Gabinete pero no viene Marca, Serial Ni Modelo', '2025-12-23 14:24:58', '2025-12-23 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (20, N'TL0PHNT', N'Micro-Star International', N'MS-7C08', N'Desktop', N'Intel(R) Core (TM) i3-8100 CPU @ 3.6 Ghz', NULL, N'SSD', 224, NULL, N'Windows 10 Pro', N'2023-01-01', N'2024-01-01', N'2023-01-01', 11, N'Trujillo ', N'Active', N'Maquina desktop de Edwin', '2025-12-23 15:36:51', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (21, N'T5PFAG00N805214', N'Asus', N'ROG G700TF', N'Desktop', N'Intel(R) Core (TM)', NULL, N'SSD', 1860, NULL, N'Windows 11 Pro', N'2025-05-13', N'2026-05-13', N'2025-05-13', 43, N'Republica Dominicana', N'Active', N'Desktop de Willian ', '2025-12-23 18:32:54', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (22, N'ET8226-1657', N'GamingPC', N'GamingPC', N'Desktop', N'AMD Ryzen 9 7900X 12-Core Processor (4.70 GHz)', NULL, N'SSD', 1820, NULL, N'Windows 11 Pro', N'2025-02-24', N'2026-02-24', N'2025-02-24', 32, N'Trujillo Alto', N'Active', N'Maquina desktop Luis Nieves ', '2025-12-23 20:21:22', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (23, N'408QCUK573870', N'LG', N'PC', N'Laptop', N'Intel(R) Core(TM) Ultra 7 155H (1.4 Ghz)', NULL, N'SSD', 954, NULL, N'Windiws 11 Pro', N'2023-11-12', N'2024-11-12', N'2023-11-12', 24, N'Guaynabo', N'Active', N'Laptop en uso', '2025-12-29 16:36:46', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (24, N'Default', N'MS-7D91', N'MS-7D91', N'Desktop', N'13Th Intel (R) Core(TM) i9-13900k (3.00 Ghz)', NULL, N'SSD', 2730, NULL, N'Windows 11 Pro', N'2024-08-13', N'2025-08-13', N'2024-08-13', 34, N'Trujillo Alto', N'Active', N'Computadora de Marcos Quiles', '2025-12-29 17:55:40', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (25, N'DQM57J2', N'Dell', N'Optiplex 3040', N'Laptop', N'Intel(R) Core(TM) i5 6500-T CPU @ 2.50 GHz', NULL, N'SSD', 477, NULL, N'Windows 11 Pro', N'2022-04-02', N'2023-04-04', N'2022-04-04', 29, N'Guaynabo', N'Active', N'Laptop de Kristian', '2025-12-29 18:52:27', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (26, N'PW03wJET', N'Lenovo ', N'Flex 7 14IAU7', N'Laptop', N'Intel Core I7-125U', NULL, N'SSD', 477, NULL, N'Windows 11 Pro', N'2024-02-02', N'2025-02-02', N'2024-02-02', 8, N'República Dominicana ', N'Active', N'Laptop Alessa ', '2026-01-06 13:38:17', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (27, N'B660M-HDV', N'NA', N'B660M-HDV', N'Desktop', N'Intel ICore 3 13th 3.4 Ghz', NULL, N'SSD', 477, NULL, N'Windows 10 Pro', N'2016-03-15', N'2017-03-15', N'2016-03-15', 39, N'Trujillo Alto', N'Active', N'Computadora Desktop de Sigfredo no aparece el Service Tag', '2026-01-09 15:10:15', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (29, N'NXJDJAA00150405F6D7600', N'Acer', N'Laptop Acer NXJK7AA002 14 pulgadas', N'Laptop', N'Intel(R) Core(TM) Ultra 5 226V (2.10 GHz)', NULL, N'SSD', 1000, NULL, N'Windows 11 Pro', N'2025-01-01', N'2026-01-01', N'2025-01-01', 6, N'Trujillo Alto', N'Active', N'', '2026-01-12 16:45:31', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (32, N'ROT4MTSB', N'Lenovo', N'ThinkPad', N'Laptop', N'Intel core i7 150u', NULL, N'SSD', 1024, NULL, N'windows 11 pro', N'2025-01-01', N'2026-01-01', N'2025-01-01', 25, N'Guaynabo, Puerto Rico', N'Active', N'Device name LAPTOP-ROT4MTSB | Processor Intel(R) Core(TM) 7 150U (1.80 GHz) | Installed RAM 16.0 GB (15.7 GB usable) | Device ID A7D14098-20B0-4D57-AB68-3EBEEAC2302E | Product ID 00330-81498-17796-AA315 | Serial number MP2MQHB1', '2026-01-23 15:30:27', '2026-01-23 00:00:00')
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (33, N'93OOKC6', N'HP', N'HP-Envy TE01-3xxx', N'Laptop', N'12th Generation Intel (R) Core(TM) i7-1270F', NULL, N'SSD', 932, NULL, N'Windows 11 Pro', N'2025-10-13', N'2026-10-13', N'2025-10-13', 18, N'Guaynabo', N'Active', N'Laptop de Giovanni ', '2026-01-28 17:04:31', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (34, N'405QCLH568488', N'LG', N'15Z90S-H.AAB6U1', N'Laptop', N'Intel Core Ultra 7 155h', NULL, N'NVMe', 954, NULL, N'Windows 11 Pro', N'2024-04-02', N'2025-04-02', N'2024-04-02', 33, N'Trujillo', N'Active', N'Laptop Max Oliveras', '2026-03-02 15:29:22', NULL)
INSERT [dbo].[hardware_inventory] ([hardware_id], [serial_number], [brand], [model], [device_type], [processor], [ram_gb], [storage_type], [storage_size_gb], [gpu], [operating_system], [warranty_start_date], [warranty_end_date], [purchase_date], [employee_id], [location], [status], [notes], [created_at], [updated_at]) VALUES (35, N'7RV3G4', N'Dell', N'Dell 16 Plus DB16250', N'Laptop', N'Intel(R) Core(TM) Ultra 9 288V (3.30 GHz)', NULL, N'SSD', 954, NULL, N'Windows 11 Pro', N'2026-03-09', N'2029-03-09', N'2026-03-09', 49, N'Guaynabo', N'Active', N'Laptop de Rosa Maria', '2026-03-18 19:41:55', NULL)

SET IDENTITY_INSERT [dbo].[hardware_inventory] OFF
GO


-- holidays: No data to insert


-- Data for product_families (7 records)
SET IDENTITY_INSERT [dbo].[product_families] ON
GO

INSERT [dbo].[product_families] ([id], [name], [description], [active], [created_at]) VALUES (1, N'Fire Alarm', NULL, 1, N'2026-06-10 06:13:40.5124609')
INSERT [dbo].[product_families] ([id], [name], [description], [active], [created_at]) VALUES (2, N'Plumbing', NULL, 1, N'2026-06-10 06:13:40.5160875')
INSERT [dbo].[product_families] ([id], [name], [description], [active], [created_at]) VALUES (3, N'Fire Sprinkler', NULL, 1, N'2026-06-10 06:13:40.5184273')
INSERT [dbo].[product_families] ([id], [name], [description], [active], [created_at]) VALUES (4, N'Security', NULL, 1, N'2026-06-10 06:13:40.5209027')
INSERT [dbo].[product_families] ([id], [name], [description], [active], [created_at]) VALUES (6, N'Devices', NULL, 1, N'2026-06-25 02:35:12.1965790')
INSERT [dbo].[product_families] ([id], [name], [description], [active], [created_at]) VALUES (7, N'Panels', NULL, 1, N'2026-06-25 02:36:47.4949750')
INSERT [dbo].[product_families] ([id], [name], [description], [active], [created_at]) VALUES (8, N'Power Supplies', NULL, 1, N'2026-06-26 22:06:34.3849300')

SET IDENTITY_INSERT [dbo].[product_families] OFF
GO


-- Data for product_categories (9 records)
SET IDENTITY_INSERT [dbo].[product_categories] ON
GO

INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (1, 1, N'Device', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (2, 1, N'Module', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (3, 2, N'Valve', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (4, 3, N'Head', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (7, 6, N'Devices - Addressable', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (8, 7, N'IPA Series Panels', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (9, 6, N'Detectors - Addressable', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (10, 8, N'Batteries', NULL, 1)
INSERT [dbo].[product_categories] ([id], [family_id], [name], [description], [active]) VALUES (11, 1, N'Control Panel', NULL, 1)

SET IDENTITY_INSERT [dbo].[product_categories] OFF
GO


-- Data for products (3 records)
SET IDENTITY_INSERT [dbo].[products] ON
GO

INSERT [dbo].[products] ([id], [name], [description], [type], [sku], [unit_price], [cost], [tax_rate], [unit], [stock_quantity], [is_active], [created_at], [code], [family], [category], [size], [material_type], [min_stock], [needed_quantity], [family_id], [category_id], [specification], [manufacturer], [model]) VALUES (81, N'4064 POINT ADDRESSABLE FIRE PANEL EXPANDABLE', N'', N'Product', N'IPA-4000E', '2763.70', '1326.58', '0.0000', N'pieza', 0, 1, N'2026-07-02 17:21:59.6414890', N'3992798', NULL, NULL, N'NA', N'Electronic', '2.00', NULL, 1, 11, N'Addressable Fire Panel', N'Potter', N'IPA-4000E')
INSERT [dbo].[products] ([id], [name], [description], [type], [sku], [unit_price], [cost], [tax_rate], [unit], [stock_quantity], [is_active], [created_at], [code], [family], [category], [size], [material_type], [min_stock], [needed_quantity], [family_id], [category_id], [specification], [manufacturer], [model]) VALUES (82, N'60 Point Addressable Fire, Releasing Panel', N'60 Point Addressable Fire, Releasing Panel', N'Product', N'IPA-60', '1309.45', '628.53', '0.0000', N'pieza', 0, 1, N'2026-07-02 17:24:49.6057930', N'3992714', NULL, NULL, N'NA', N'Electronic', '10.00', NULL, 1, 11, N'Addressable Fire Panel', N'Potter', N'IPA-4000E')
INSERT [dbo].[products] ([id], [name], [description], [type], [sku], [unit_price], [cost], [tax_rate], [unit], [stock_quantity], [is_active], [created_at], [code], [family], [category], [size], [material_type], [min_stock], [needed_quantity], [family_id], [category_id], [specification], [manufacturer], [model]) VALUES (83, N'127 Point Addressable Fire, Releasing Panel', N'Panel demo', N'Product', N'IPA-100', '1647.05', '807.06', '0.0000', N'pieza', 0, 1, N'2026-07-02 17:50:10.0436680', N'3992715', NULL, NULL, N'NA', N'Electronic', '0.00', NULL, 1, 11, N'Addressable Fire Panel', N'Potter', N'IPA-4000E')

SET IDENTITY_INSERT [dbo].[products] OFF
GO


-- Data for warehouse_locations (2 records)
SET IDENTITY_INSERT [dbo].[warehouse_locations] ON
GO

INSERT [dbo].[warehouse_locations] ([warehouse_location_id], [name], [is_active]) VALUES (4, N'Republica Dominicana', 1)
INSERT [dbo].[warehouse_locations] ([warehouse_location_id], [name], [is_active]) VALUES (5, N'Puerto Rico', 1)

SET IDENTITY_INSERT [dbo].[warehouse_locations] OFF
GO


-- Data for warehouses (4 records)
SET IDENTITY_INSERT [dbo].[warehouses] ON
GO

INSERT [dbo].[warehouses] ([warehouse_id], [name], [location], [is_active], [location_id]) VALUES (1, N'Trujillo Alto', N'Puerto Rico', 1, 5)
INSERT [dbo].[warehouses] ([warehouse_id], [name], [location], [is_active], [location_id]) VALUES (3, N'Guaynabo', N'Puerto Rico', 1, 5)
INSERT [dbo].[warehouses] ([warehouse_id], [name], [location], [is_active], [location_id]) VALUES (4, N'Santo Domingo', N'Republica Dominicana', 1, 4)
INSERT [dbo].[warehouses] ([warehouse_id], [name], [location], [is_active], [location_id]) VALUES (5, N'Santiago', N'Republica Dominicana', 1, 4)

SET IDENTITY_INSERT [dbo].[warehouses] OFF
GO


-- Data for inventory_movements (5 records)
SET IDENTITY_INSERT [dbo].[inventory_movements] ON
GO

INSERT [dbo].[inventory_movements] ([movement_id], [product_id], [warehouse_id], [movement_type], [quantity], [movement_date], [project], [po_number], [notes], [created_at], [reference_type], [reference_id], [created_by]) VALUES (1, 82, 1, N'IN', '10.00', N'2026-07-02', N'NA', NULL, N'to have in Stock', N'2026-07-02 17:26:15.0135510', N'PURCHASE', NULL, N'Jonathan Romo')
INSERT [dbo].[inventory_movements] ([movement_id], [product_id], [warehouse_id], [movement_type], [quantity], [movement_date], [project], [po_number], [notes], [created_at], [reference_type], [reference_id], [created_by]) VALUES (2, 81, 4, N'IN', '20.00', N'2026-07-02', N'Coca Cola', N'#00001', N'esta entrada es para el proyecto de Coca Cola ', N'2026-07-02 17:58:17.2866620', N'JOB', NULL, N'Jonathan Romo')
INSERT [dbo].[inventory_movements] ([movement_id], [product_id], [warehouse_id], [movement_type], [quantity], [movement_date], [project], [po_number], [notes], [created_at], [reference_type], [reference_id], [created_by]) VALUES (3, 81, 1, N'IN', '2.00', N'2026-07-07', NULL, NULL, N'test', N'2026-07-08 00:43:08.6094230', N'JOB', NULL, N'Juan Villa')
INSERT [dbo].[inventory_movements] ([movement_id], [product_id], [warehouse_id], [movement_type], [quantity], [movement_date], [project], [po_number], [notes], [created_at], [reference_type], [reference_id], [created_by]) VALUES (4, 82, 1, N'OUT', '1.00', N'2026-07-08', NULL, NULL, N'test', N'2026-07-08 18:17:01.6100000', NULL, NULL, N'Juan Villa')
INSERT [dbo].[inventory_movements] ([movement_id], [product_id], [warehouse_id], [movement_type], [quantity], [movement_date], [project], [po_number], [notes], [created_at], [reference_type], [reference_id], [created_by]) VALUES (5, 82, 1, N'OUT', '1.00', N'2026-07-08', NULL, NULL, N'test2', N'2026-07-08 18:29:51.1766667', NULL, NULL, N'Juan Villa')

SET IDENTITY_INSERT [dbo].[inventory_movements] OFF
GO


-- Data for inventory_movement_approvals (2 records)
SET IDENTITY_INSERT [dbo].[inventory_movement_approvals] ON
GO

INSERT [dbo].[inventory_movement_approvals] ([approval_id], [product_id], [warehouse_id], [movement_type], [quantity], [movement_date], [project], [po_number], [reference_type], [reference_id], [notes], [status], [requested_by], [requested_by_email], [review_note], [reviewed_by], [reviewed_at], [movement_id], [created_at]) VALUES (1, 82, 1, N'OUT', '1.00', N'2026-07-08', NULL, NULL, NULL, NULL, N'test2', N'APPROVED', N'Juan Villa', N'jvilla@primefire.us', N'test', N'Juan Villa', N'2026-07-08 18:29:52.2333333', 5, N'2026-07-08 18:29:00.1100000')
INSERT [dbo].[inventory_movement_approvals] ([approval_id], [product_id], [warehouse_id], [movement_type], [quantity], [movement_date], [project], [po_number], [reference_type], [reference_id], [notes], [status], [requested_by], [requested_by_email], [review_note], [reviewed_by], [reviewed_at], [movement_id], [created_at]) VALUES (2, 82, 1, N'OUT', '2.00', N'2026-07-08', NULL, NULL, NULL, NULL, N'test2', N'REJECTED', N'Juan Villa', N'jvilla@primefire.us', N'no se puede', N'Juan Villa', N'2026-07-08 18:33:22.7400000', NULL, N'2026-07-08 18:31:05.4633333')

SET IDENTITY_INSERT [dbo].[inventory_movement_approvals] OFF
GO


-- jobs: No data to insert


-- Data for licenses (67 records)
SET IDENTITY_INSERT [dbo].[licenses] ON
GO

INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (2, N'Office Hogar y Empresas', N'2021', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 8, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (3, N'Office Hogar y Empresas', N'2021', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (4, N'Office Hogar y Empresas', N'2021', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (5, N'Office Hogar y Empresas', N'2021', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (6, N'Office Hogar y Empresas', N'2021', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (7, N'Office Hogar y Empresas', N'2019', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 35, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (8, N'Office Hogar y Empresas', N'2019', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (9, N'Office Hogar y Empresas', N'2019', N'2025-11-01', N'2026-11-01', N'.exe', N'Lorenzo Luciano ', N'NA', 19, N'Licencia de Luciano')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (10, N'Office Hogar y Empresas', N'2019', N'2025-11-01', N'2030-12-31', N'.exe', N'NA', N'NA', 2, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (11, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2030-12-31', N'YY8HR-MRN7Y-GJQ22-VTYYB-PR4D9', N'NA', N'NA', 32, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (13, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2026-11-01', N'RN964-Y9TP4-C9XB3-R7JCY-F9CMK', N'NA', N'NA', 52, N'')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (14, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2030-12-31', N'6C3H9-NF4XV-M7B9T-2FKMJ-Q69VX', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (15, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2030-12-31', N'NBRB7-DXRTG-78F3J-6DH6H-X767X', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (16, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2026-11-01', N'6YPF7-NVQTX-CFRFY-K8H8K-V22MK', N'NA', N'NA', 6, N'')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (17, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2026-11-01', N'PTNYH-C3K4Y-R2V4Y-FVK7G-KTPMK', N'NA', N'NA', 29, N'')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (18, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2030-12-31', N'JW2N2-VY84G-7B4WQ-F8TRG-TJGBK', N'NA', N'NA', 43, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (19, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2030-12-31', N'X3NXY-WQF6G-6TYHP-VGMR4-JHV39', N'NA', N'NA', 16, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (20, N'Project Professional', N'2016', N'2025-01-01', N'2030-12-31', N'NA', N'.exe', N'NA', 33, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (22, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'WJKK4-JNQ3C-6DXMP-MBQ68-TQ726', N'NA', N'NA', 25, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (23, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'KNBXT-476VY-4MD7F-WD96T-3V66T', N'NA', N'NA', 12, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (24, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'QV29N-MB22V-W77GF-V7YWD-9D726', N'NA', N'NA', 10, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (25, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'GQ632-4NHC2-874P6-WY9F3-C3726', N'NA', N'NA', 16, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (26, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'KKNY3-6G7QC-9MV22-B8FKG-H8RC6', N'NA', N'NA', 24, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (27, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'BMHN4-RV8TH-384JX-MRBQW-F3KTT', N'NA', N'NA', 3, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (28, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'JJD6F-GN9FY-Q8GR3-T6TYQ-YBH26', N'NA', N'NA', 42, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (29, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'NDQPV-Q8C4R-6DG4R-RP7JR-369TT', N'NA', N'NA', 33, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (30, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N' 7TNMC-WG9JC-FXW9P-JTYYM-QJ3GT', N'NA', N'NA', 5, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (31, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'XKKX3-N9D4Q-F2MHB-TW9VF-PPQGT', N'NA', N'NA', 41, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (32, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'WN9QH-23YXT-JFJG2-GYJBY-K766T', N'NA', N'NA', 38, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (33, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'WBQHR-NYK2T-RTXF7-9XYDR-JHV26', N'NA', N'NA', 43, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (34, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'WJKK4-JNQ3C-6DXMP-MBQ68-TQ726', N'NA', N'NA', 25, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (35, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'WJKK4-JNQ3C-6DXMP-MBQ68-TQ726', N'NA', N'NA', 25, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (36, N'Windows 11 Pro', N'2025', N'2025-12-15', N'2030-12-31', N'NWFKH-V99CG-MV63M-PGQYD-7T9TT', N'NA', N'NA', 3, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (37, N'Windows 11 Pro', N'2025', N'2025-12-09', N'2030-12-31', N'HM2F6-NTVVH-V4YWB-7BC2M-39MP6', N'NA', N'NA', 17, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (38, N'Windows11 Pro', N'2025', N'2025-12-01', N'2026-12-01', N'WTNHY-BR399-MBF4T-7HHQW-VH66T', N'NA', N'NA', 3, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (39, N'Revit', N'2025', N'2025-11-30', N'2026-11-30', N'575-04949370', N'NA', N'NA', 23, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (40, N'Revit', N'2025', N'2025-11-30', N'2026-11-29', N'575-04949370', N'NA', N'NA', 43, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (41, N'Revit', N'2025', N'2025-12-17', N'2026-12-16', N'574-73837017', N'NA', N'NA', 23, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (42, N'Adobe Acrobat', N'2020 Standart', N'2025-12-10', N'2026-12-15', N'118-1981-0736-3346-2793-4534', N'NA', N'NA', 17, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (43, N'Adobe Acribat Pro', N'2025', N'2025-12-17', N'2030-12-31', N'1118-1780-2264-9622-2021-5546', N'NA', N'NA', 12, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (44, N'Adobe Acribat Pro', N'2025', N'2025-12-17', N'2030-12-31', N'1118-1780-2264-9622-2021-5546', N'NA', N'NA', 10, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (45, N'Adobe Acribat Pro', N'2025', N'2025-12-17', N'2030-12-31', N'1118-1714-6444-4243-6737-2511', N'NA', N'NA', 12, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (46, N'Adobe Acribat Pro', N'2025', N'2025-12-17', N'2030-12-31', N'1118-1714-6444-4243-6737-2511', N'NA', N'NA', 3, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (47, N'Adobe Acribat Pro', N'2025', N'2025-12-17', N'2030-12-31', N'1118-1780-2264-9622-2021-5546', N'NA', N'NA', 25, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (48, N'Adobe Acribat Pro', N'2025', N'2025-12-17', N'2030-12-31', N'1118-1780-2264-9622-2021-5546', N'NA', N'NA', 25, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (49, N'AlarmCAD', N'2023', N'2025-02-28', N'2026-02-28', N'EGBC4-CJLTC-64K8C- FA9BX-6NXUJ-9', N'Amartinez@primefire.us', N'', 2, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (50, N'AutoSPRINK Platinum', N'2024', N'2026-02-03', N'2027-02-03', N'9WVCN-X5X63-3TYME-GMTYJ-NMJP4-4', N'lbusert@primefire.us', N'Na', 30, N'')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (51, N'AutoSPRINK Lite', N'2024', N'2025-02-04', N'2026-02-04', N'ZFHG6-JYC26-X2K9A-UWQN5-9A8VK-6', N'Lnieves@primefire.us', N'NA', 32, N'La licencia ya no se va a actualizar por que es perpetua solo se quedara sin mtto')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (52, N'AutoSPRINK Lite', N'2024', N'2025-02-04', N'2026-02-04', N'ZFHG6-JYC26-X2K9A-UWQN5-9A8VK-6', N'Lbilleard@primefire.us', N'NA', 45, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (53, N'AlarmCAD ', N'2023', N'2024-05-31', N'2025-05-31', N'7HPVU-ZS2L3-Q8YA9-ZZHC7-26PPB-2 ', N'Jmedina@primefire.us', N'NA', 23, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (54, N'AlarmCAD', N'2023', N'2024-03-03', N'2025-03-03', N'ARFQH-LQ9N5-JMRJB-QR5NJ-C58FT-4', N'Wbencosme@primefire.us', N'NA', 43, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (55, N'AutoCAD', N'Full Version', N'2025-06-06', N'2026-06-06', N'NA', N'amartinez@primefire.us', N'NA', 2, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (56, N'AutoCAD', N'Full Version', N'2026-06-10', N'2029-06-10', N'NA', N'lnieves@primefire.us', N'NA', 32, N'')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (57, N'AutoCAD', N'FullVersion', N'2025-06-10', N'2026-06-10', N'NA', N'lburset@primefire.us', N'NA', 30, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (58, N'Office Hogar y Empresas', N'2016', N'2025-11-01', N'2030-12-31', N'', N'NA', N'NA', 19, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (59, N'AutoCAD', N'Full Version', N'2025-06-03', N'2026-06-03', N'NA', N'ngonzalwz@primefire.us', N'NA', 35, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (60, N'AutoCAD ', N'LT', N'2025-11-29', N'2026-11-29', N'Na', N'Sofia Rodriguez', N'NA', 3, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (67, N'AutoCAD', N'AutoCAD 2025', N'2025-11-27', N'2026-11-27', N'574-62827022', N'NA', N' A', 23, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (68, N'AutoCAD ', N'Full Version ', N'2025-06-10', N'2026-06-10', N'NA', N'Arodriguez@promefire.us', N'NA', 34, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (69, N'ZenFire', N'Subscription CRM', N'2026-01-05', N'2027-01-05', N'Subscription', N'ALL ', N'NA', 21, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (70, N'Godaddy Dominio PrimeFire.us', N'Dominio', N'2025-10-29', N'2027-10-29', N'Subscription', N'30916342', N'Alberto2016', 21, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (71, N'Godaddy eliteyachtscharter.com', N'Dominio', N'2026-01-18', N'2027-01-18', N'Subscription', N'PrimeFirePR', N'PFP2@25!@#', 21, N'')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (72, N'Godaddy haciendapallares.com', N'Dominio', N'2026-05-01', N'2029-05-01', N'Subscription ', N'PrimeFirePR', N'PFP2@25!@#', 21, NULL)
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (74, N'Windows 11 ', N'Pro', N'2026-03-16', N'2039-12-16', N'FDHVN-XCPCG-77YDX-TTYYQ-T6PKG', N'Rmrivera@primefire.us', N'Na', 49, N'Key Rosa Maria')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (75, N'Autocad ', N'2026', N'2026-04-23', N'2027-05-27', N'001R1 57521733043', N'Wbencosme@primefire.us', N'Na', 43, N'Autocad 2026')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (76, N'AutoCAD ', N'2026', N'2026-06-09', N'2027-06-09', N'Subscripcion ', N'It@primefire.do', N'- [ ] AutocadDO26!#', 45, N'Licencia de 1 año por subscripcion a Luis Belliard')
INSERT [dbo].[licenses] ([license_id], [software], [version], [created_at], [expiry_date], [key], [account], [password], [employee_id], [notes]) VALUES (77, N'Adobe Acrobat', N'Standard 2020', N'2026-07-20', N'2027-07-20', N'1118-1995-5508-0563-8239-2470', N'NA', N'NA', 46, N'Licencia de Kevin')

SET IDENTITY_INSERT [dbo].[licenses] OFF
GO


-- Data for modules (26 records)
SET IDENTITY_INSERT [dbo].[modules] ON
GO

INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (1, N'Dashboard', N'dashboard', N'Main dashboard and analytics', N'dashboard', N'/dashboard', 1, 1, NULL, '2025-10-18 19:52:14')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (3, N'Jobs', N'jobs', N'Job postings management', N'work', N'/jobs', 2, 1, NULL, '2025-10-18 19:52:14')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (5, N'Licenses', N'licenses', N'Software licenses management', N'vpn_key', N'/licenses', 6, 1, 22, '2025-10-18 19:52:14')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (6, N'Administration', N'administration', N'System administration', N'settings', N'/config', 6, 1, NULL, '2025-10-18 19:52:14')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (7, N'Roles', N'roles', N'Role management', N'admin_panel_settings', N'config/permissions/roles', 6, 1, 6, '2025-10-18 19:52:14')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (8, N'Permissions', N'permissions', N'Module permissions management', N'lock', N'/config/permissions', 9, 1, 6, '2025-10-18 19:52:14')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (10, N'Modules', N'modules', N'modules', N'Modules', N'/config/permissions/modules', 7, 1, 6, '2025-10-18 22:40:51')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (11, N'Employees', N'employees', N'Employees Module', N'people', N'/employees', 4, 1, 22, '2025-10-19 17:31:12')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (12, N'Tickets', N'tickets', N'', N'confirmation_number', N'/tickets', 5, 1, 22, '2025-10-28 02:24:35')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (13, N'hardware', N'hardware', N'Modulo para gestionar inventario de equipos', N'settings', N'/hardware', 7, 1, 22, '2025-11-11 19:48:15')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (14, N'timeoff', N'timeoff', N'timeoff', N'event_available', N'/workforce-management/time-off/calendar', 2, 1, 23, '2025-12-06 20:52:19')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (15, N'Tenants', N'tenants', N'Tenants', N'', N'/permissions/Tenants', 0, 0, NULL, '2025-12-28 05:40:08')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (16, N'customers', N'customers', N'customers', N'groups_2', N'customers', 8, 1, 21, '2026-02-09 23:33:12')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (17, N'Timesheet', N'timesheet', N'timesheet', N'schedule', N'/workforce-management/timesheet', 3, 1, 23, '2026-02-26 03:20:49')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (18, N'Products', N'products', N'modulo de productos o servicios', N'inventory_2', N'/products', 8, 1, 21, '2026-04-17 17:52:13')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (20, N'quotations', N'quotations', N'modulo para cotizaciones', N'description', N'/quotations', 0, 1, NULL, '2026-04-24 01:25:22')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (21, N'business-proposals', N'business-proposals', N'business-proposals', N'request_quote', N'', 0, 1, NULL, '2026-05-23 00:21:27')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (22, N'systems', N'systems', N'systems', N'dns', N'', 0, 1, NULL, '2026-05-23 00:21:56')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (23, N'workforce-management', N'workforce-management', N'workforce-management', N'groups', N'', 0, 1, NULL, '2026-05-23 00:22:23')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (24, N'inventory', N'inventory', N'inventory', N'inventory', N'/inventory', 0, 1, NULL, '2026-05-30 22:38:08')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (25, N'Inventory Overview', N'inventory-overview', N'Inventory overview and stock summary', N'inventory_2', N'/inventory', 1, 1, 24, '2026-06-16 03:56:01')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (26, N'Inventory Entries', N'inventory-entries', N'Inventory stock entries', N'add_box', N'/inventory/entries', 2, 1, 24, '2026-06-16 03:56:01')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (27, N'Inventory Outputs', N'inventory-outputs', N'Inventory stock outputs', N'outbox', N'/inventory/outputs', 3, 1, 24, '2026-06-16 03:56:01')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (28, N'Inventory Adjustments', N'inventory-adjustments', N'Inventory stock adjustments', N'tune', N'/inventory/adjustments', 4, 1, 24, '2026-06-16 03:56:01')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (29, N'Inventory Movements', N'inventory-movements', N'Inventory movement history', N'sync_alt', N'/inventory/movements', 5, 1, 24, '2026-06-16 03:56:01')
INSERT [dbo].[modules] ([module_id], [module_name], [module_key], [description], [icon], [route_url], [display_order], [is_active], [parent_module_id], [created_at]) VALUES (30, N'Inventory Warehouses', N'inventory-warehouses', N'Inventory warehouse management', N'warehouse', N'/inventory/warehouses', 6, 1, 24, '2026-06-16 03:56:01')

SET IDENTITY_INSERT [dbo].[modules] OFF
GO


-- product_attachments: No data to insert


-- Data for product_catalog (8 records)
SET IDENTITY_INSERT [dbo].[product_catalog] ON
GO

INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (1, N'TEST', N'TEST', NULL, NULL, N'pieza', '0.00', 1, N'TEST', N'2026-05-31 01:30:55.2900000')
INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (3, N'P-4', N'test2', 1, 1, N'hora', '0.00', 1, N'test', N'2026-06-24 03:23:26.5845030')
INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (4, N'FSP-951', N'Intelligent Photoelectric Smoke Detector', 6, 9, N'pieza', '0.00', 0, N'Addressable photoelectric smoke sensor for intelligent control panels.', N'2026-06-25 02:36:06.8308340')
INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (5, N'3992798', N'4064 POINT ADDRESSABLE FIRE PANEL EXPANDABLE', 1, 11, N'pieza', '0.00', 1, N'', N'2026-06-25 02:37:31.5053990')
INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (6, N'P-80', N'test', NULL, NULL, N'pieza', '0.00', 1, N'', N'2026-07-01 01:07:54.0166667')
INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (7, N'asdgasdg', N'test', NULL, NULL, N'pieza', '0.00', 1, N'', N'2026-07-01 01:08:21.5066667')
INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (8, N'3992714', N'60 Point Addressable Fire, Releasing Panel', 1, 11, N'pieza', '0.00', 1, N'60 Point Addressable Fire, Releasing Panel', N'2026-07-02 17:24:49.8218430')
INSERT [dbo].[product_catalog] ([id], [code], [name], [family_id], [category_id], [unit], [min_stock], [active], [description], [created_at]) VALUES (9, N'3992715', N'127 Point Addressable Fire, Releasing Panel', 1, 11, N'pieza', '0.00', 1, N'Panel demo', N'2026-07-02 17:50:10.2655760')

SET IDENTITY_INSERT [dbo].[product_catalog] OFF
GO


-- Data for product_specifications (8 records)
SET IDENTITY_INSERT [dbo].[product_specifications] ON
GO

INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (1, 1, NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (3, 3, N'test', N'test', N'test', N'test', N'test', NULL)
INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (4, 4, NULL, NULL, NULL, N'Notifier', N'FSP-951', NULL)
INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (5, 5, N'Addressable Fire Panel', N'NA', N'Electronic', N'Potter', N'IPA-4000E', NULL)
INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (6, 6, NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (7, 7, NULL, NULL, NULL, NULL, NULL, NULL)
INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (8, 8, N'Addressable Fire Panel', N'NA', N'Electronic', N'Potter', N'IPA-4000E', NULL)
INSERT [dbo].[product_specifications] ([id], [product_id], [specification], [size], [material], [manufacturer], [model], [notes]) VALUES (9, 9, N'Addressable Fire Panel', N'NA', N'Electronic', N'Potter', N'IPA-4000E', NULL)

SET IDENTITY_INSERT [dbo].[product_specifications] OFF
GO


-- quotations: No data to insert


-- quotation_items: No data to insert


-- Data for role_modules (104 records)
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 1, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:16')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 3, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:17')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 5, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:18')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 6, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:18')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 7, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:19')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 8, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:20')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 10, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:19')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 11, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:17')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 12, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:18')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 13, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:19')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 14, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:17')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 16, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:19')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 17, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:17')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 18, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:20')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 20, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:16')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 21, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:34:15')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 22, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:34:16')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 23, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:34:16')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 24, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:34:15')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 25, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 26, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 27, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 28, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 29, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (1, 30, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (2, 3, 1, 1, 1, 1, 1, 1, 0, '2025-12-22 17:03:13')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (2, 14, 1, 1, 1, 1, 1, 1, 0, '2025-12-22 17:03:13')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 1, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 3, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 5, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 7, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:56')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 8, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:56')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 10, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:56')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 11, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 12, 1, 1, 1, 1, 1, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 13, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:56')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 14, 1, 1, 1, 1, 1, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 16, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:56')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 17, 1, 1, 1, 1, 1, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 18, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:56')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 20, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 25, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 26, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 27, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 28, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 29, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (3, 30, 0, 0, 0, 0, 0, 0, 0, '2026-06-24 03:49:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 1, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:42')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 3, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:43')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 5, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:43')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 6, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:43')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 7, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:44')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 8, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:45')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 10, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:44')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 11, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:42')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 12, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:45')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 13, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:45')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 14, 0, 0, 0, 0, 0, 0, 0, '2025-12-28 05:40:42')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (8, 15, 1, 1, 1, 1, 1, 1, 1, '2025-12-28 05:40:41')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 1, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:51')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 3, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:52')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 5, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:53')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 6, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:53')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 7, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 8, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 10, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 11, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:53')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 12, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:53')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 13, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 14, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:52')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 16, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:54')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 17, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:52')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 18, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:55')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 20, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:51')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 21, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 22, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:51')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 23, 0, 0, 0, 0, 0, 0, 0, '2026-06-16 02:37:51')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 24, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 02:37:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 25, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 26, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 27, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 28, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 29, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (9, 30, 1, 1, 1, 1, 1, 1, 1, '2026-06-16 03:56:01')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 1, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:49')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 3, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:49')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 5, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 7, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 8, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:51')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 10, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 11, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 12, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 13, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 14, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:49')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 16, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:51')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 17, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 18, 1, 1, 1, 1, 1, 0, 0, '2026-07-08 03:45:51')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 20, 0, 0, 0, 0, 0, 0, 0, '2026-07-08 03:45:49')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 25, 1, 1, 1, 1, 1, 0, 0, '2026-07-08 03:45:49')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 26, 1, 1, 1, 1, 1, 0, 0, '2026-07-08 03:45:49')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 27, 1, 0, 1, 1, 1, 0, 0, '2026-07-08 03:45:49')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 28, 1, 1, 1, 1, 1, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 29, 1, 1, 1, 1, 1, 0, 0, '2026-07-08 03:45:50')
INSERT [dbo].[role_modules] ([role_id], [module_id], [can_view], [can_create], [can_edit], [can_delete], [can_export], [admin_actions], [other_actions], [assigned_at]) VALUES (10, 30, 1, 1, 1, 1, 1, 0, 0, '2026-07-08 03:45:50')
GO


-- tenant_employees: No data to insert


-- Data for tenant_logos (2 records)
SET IDENTITY_INSERT [dbo].[tenant_logos] ON
GO

INSERT [dbo].[tenant_logos] ([logo_id], [tenant_id], [title], [description], [path], [path_background], [primary_color], [secondary_color], [tertiary_color], [created_at], [updated_at], [url]) VALUES (1, 1, N'Cliente A', N'Cliente A', N'assets/Test-Logo.webp', N'assets/test-hero.webp', NULL, NULL, NULL, '2025-12-28 00:14:01', NULL, N'localhost:4201')
INSERT [dbo].[tenant_logos] ([logo_id], [tenant_id], [title], [description], [path], [path_background], [primary_color], [secondary_color], [tertiary_color], [created_at], [updated_at], [url]) VALUES (2, 3, N'Developer''s Romo', NULL, N'assets/devromo_logo.webp', N'assets/devromo_bg.webp', N'', N'', NULL, '2026-01-13 04:19:36', NULL, N'app.devromo.com')

SET IDENTITY_INSERT [dbo].[tenant_logos] OFF
GO


-- Data for tickets (219 records)
SET IDENTITY_INSERT [dbo].[tickets] ON
GO

INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (1, N'Deploy App to Azure', N'invest how to deploy the app Python and angular to Azure', N'closed', N'normal', NULL, 21, 27, N'2025-11-20 13:05:03.0000000', N'2025-11-25 14:16:36.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (2, N'Anydesk Column', N'Add Anydesk Column to employees Table and show ', N'closed', N'normal', NULL, 21, 27, N'2025-11-20 13:06:37.0000000', N'2025-11-25 14:17:05.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (3, N'Iframe Jobs Work4 PrimeFire 2 Sites', N'Add the Frame Jobs(Vacancies) to the new webpages  ', N'closed', N'normal', NULL, 21, 27, N'2025-11-20 13:08:22.0000000', N'2025-11-25 14:17:15.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (4, N'Migration webpage Cpanel to Plesk ', N'we need to migrate the cpanel webp app to plesk hosting', N'closed', N'normal', NULL, 21, 27, N'2025-11-20 13:12:49.0000000', N'2026-06-13 20:51:24.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (5, N'Carpeta Compartida Impresora Canon', N'esta carpeta es necesaria para las impresiones ', N'closed', N'normal', NULL, 21, 21, N'2025-11-25 14:26:24.0000000', N'2025-11-25 14:26:52.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (8, N'Popup Tickets Tema Negro', N'El Popup cuando se muestra se ve en negro', N'closed', N'medium', NULL, 21, 27, N'2025-11-26 00:39:14.0000000', N'2025-11-29 20:25:14.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (9, N'Filtros Tickets Module', N'En el modulo Tickets debe de empezar con 

Filtro al inicio 

Assigned me

mes actual

activos

Ahi que agregar un filtro extra de rango  de fechas.



Si tengo rol de user solo ver mis tickets activos cerrados y activos. si tengo rol de Manager o admin puedo ver todos los tickets.

La vista siempre debe empezar con activos y asignados a mi. pero debe existir la opcion de guardar la vista en el storage

Entonces ahi que crear un servicio que tenga las credenciales usuario y rol. para determinar las vistas.



validaciones. 

Managers puede crear tickets a todos

Users solo puede crear Tickets a IT.

', N'closed', N'normal', NULL, 21, 27, N'2025-11-26 00:49:22.0000000', N'2025-11-29 20:25:09.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (10, N'Validar campos mandatorios en Jobs ', N'Validación 

•Campos mandatorios en Jobs 

•Cambiar el ejemplo de Mexico City a San Juan City.



', N'closed', N'normal', NULL, 21, 27, N'2025-11-26 01:26:25.0000000', N'2025-11-29 20:25:06.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (11, N'Validación Formulario Tickets ', N'Validación campos mandatorios 

Validación máximo y mínimo de caracteres en Title y descripción

El SLA no debe ser opcional y las opciones son 

1 hora o menos 

4 horas 

8 horas 

48 horas 

1 week 

2 weeks 

1 Month 





', N'closed', N'normal', N'12h', 21, 27, N'2025-11-26 01:34:28.0000000', N'2025-11-29 20:25:02.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (12, N'Validation Licences ', N'Campos mandatorios 

Deshabilitar expired date hasta que se llene create at.

Debe pintarse de la siguiente manera acorde las fechas



Amarillo 3 meses antes de vencer la licencia

Naranja 2 meses antes de vencer la licencia 

Rojo 1 mes antes de vencer la licencia 



Agregar nombre de usuario licencia asignada.

', N'todo', N'normal', N'1w', 21, 21, N'2025-11-26 01:41:40.0000000', N'2025-12-20 18:06:55.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (16, N'Instalacion de Revit - William', N'Se requiere esta instalacion de software para modelar en 3D ', N'closed', N'urgent', N'4h', 21, 27, N'2025-12-02 17:20:26.0000000', N'2025-12-09 17:47:27.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (17, N'Instalacion paquete Office, Luis Belliard', N'Necesito el paquete de MS office para poder acceder a los BOM de los proyectos', N'closed', N'normal', N'1w', 45, 21, N'2025-12-02 17:40:30.0000000', N'2025-12-09 17:47:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (18, N'Instalación de REVIT- Joskayra Medina', N'La instalación de este software se require para realizar modelados en 3D, ya se instaló esta mañana por el momento todo va marchando bien.', N'closed', N'normal', N'1h', 23, 21, N'2025-12-02 19:07:06.0000000', N'2025-12-03 01:15:35.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (19, N'Instalar Software Revit', N'Se requiere la instalación del software revit para el modelado de planos en 3D.', N'closed', N'normal', N'1h', 43, 21, N'2025-12-02 19:34:47.0000000', N'2025-12-03 01:15:43.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (20, N'Licencia de AlarmCAD Reasignar', N'La licencia de AlarmCAD no me funciona, ahí que reasignarla por que aparece que ya esta en uso', N'closed', N'medium', N'4h', 21, 21, N'2025-12-09 17:54:45.0000000', N'2025-12-09 17:57:38.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (21, N'validacion siempre  To/Do sin ser editable el ticket al momento del create ', N'validacion siempre el "Status" To/Do sin ser editable el ticket al momento del create  ', N'closed', N'normal', N'24h', 21, 27, N'2025-12-10 00:32:42.0000000', N'2025-12-10 02:53:48.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (22, N'Poner los formatos de files que soporta', N'si el modulo de Tickets soporta 

.pdf,.word,excel tipos de imagenes, cuando se suba un documento mostrar "uploaded", al momento de enviar verificar si vuelve a cargar los documentos', N'closed', N'normal', N'24h', 21, 27, N'2025-12-10 00:35:31.0000000', N'2025-12-10 02:47:45.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (23, N'Share Knowledge Submodulos Jobs & Tickets', N'Hacer un documento que explique el como hacer un ticket & como crear un Job ', N'closed', N'normal', N'24h', 21, 27, N'2025-12-10 00:39:40.0000000', N'2026-06-18 00:38:31.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (25, N'support con equipo', N'se solicito asistencia para poder trabajar los PDF que no e abren ', N'closed', N'normal', N'4h', 46, 21, N'2025-12-11 17:41:14.0000000', N'2025-12-12 13:42:02.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (26, N'CONFIGURACION NUEVA PC', N'INSTALACION DE TODOS LOS PROGRAMAS DE DISEÑO  (AUTOCAD, REVIT, BLUE BEAM, SKETCHUP) PARA NUEVA LAPTOP.', N'closed', N'medium', N'4h', 43, 21, N'2025-12-15 14:08:46.0000000', N'2025-12-19 02:48:56.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (27, N'Mover los botones de time off a Calendar', N'primero ahi que crear un modulo que se llame administration

dentro ira 

-Calendar

-TimeSheet 



y mover las secciones dentro de la primera pagina Time Off - Calendar

', N'closed', N'normal', N'8h', 21, 27, N'2025-12-15 23:18:56.0000000', N'2025-12-27 23:12:23.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (28, N'Inventory Adolfo', N'Hacer Inventario a maquina de Adolfo', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 23:51:05.0000000', N'2025-12-22 14:23:22.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (29, N'Inventory Alberto', N'Hacer Inventario a maquina de Alberto', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 16:55:26.0000000', N'2025-12-15 16:55:26.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (30, N'Inventory Cesar Figueroa Cruzado', N'Hacer Inventario a maquina de Cesar Figueroa Cruzado', N'closed', N'normal', N'1m', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-12 16:45:58.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (31, N'Inventory Christopher Carballo Rosado', N'Hacer Inventario a maquina de Christopher Carballo Rosado', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-15 17:12:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (32, N'Inventory Alessa', N'Hacer Inventario a maquina de Alessa', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2026-01-06 16:49:50.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (33, N'Inventory Edwin de Jesus', N'Hacer Inventario a maquina de Edwin de Jesus', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-15 17:12:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (34, N'Inventory Edwin Guilloty', N'Hacer Inventario a maquina de Edwin Guilloty', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-23 15:38:50.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (35, N'Inventory Elionetzi Santiago Adames', N'Hacer Inventario a maquina de Elionetzi Santiago Adames', N'closed', N'normal', N'2w', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-30 19:07:08.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (36, N'Inventory Elizaud Hdz', N'Hacer Inventario a maquina de Elizaud Hdz', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-23 14:11:51.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (37, N'Inventory Emilio Melendez', N'Hacer Inventario a maquina de Emilio Melendez', N'todo', N'normal', N'1m', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-05 23:11:23.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (38, N'Inventory Enmanuel Desueza', N'Hacer Inventario a maquina de Enmanuel Desueza', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-15 17:12:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (39, N'Inventory Geurys Medrano', N'Hacer Inventario a maquina de Geurys Medrano', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-20 18:32:48.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (40, N'Inventory Giovanni Velez', N'Hacer Inventario a maquina de Giovanni Velez', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2026-01-29 16:09:53.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (41, N'Inventory Gustavo Vazquez', N'Hacer Inventario a maquina de Gustavo Vazquez', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2026-01-26 16:39:28.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (42, N'Inventory Israel Nieves', N'Hacer Inventario a maquina de Israel Nieves', N'closed', N'normal', N'1m', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-30 19:07:21.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (43, N'Inventory Javier Lopez Rivera', N'Hacer Inventario a maquina de Javier Lopez Rivera', N'todo', N'normal', N'1m', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-05 23:07:09.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (44, N'Inventory Jose Daniel Agisto Rivera', N'Hacer Inventario a maquina de Jose Daniel Agisto Rivera', N'todo', N'normal', N'2w', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-05 23:07:34.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (45, N'Inventory Jose Martinez', N'Hacer Inventario a maquina de Jose Martinez', N'closed', N'normal', N'1m', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-23 15:24:41.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (46, N'Inventory Jose Morales', N'Hacer Inventario a maquina de Jose Morales', N'todo', N'normal', N'1m', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-05 23:08:29.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (47, N'Inventory Joskayra de Jesus Medina', N'Hacer Inventario a maquina de Joskayra de Jesus Medina', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-20 18:30:30.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (48, N'Inventory Kevin Lopez', N'Hacer Inventario a maquina de Kevin Lopez', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-22 19:34:39.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (49, N'Inventory Kevin Morales', N'Hacer Inventario a maquina de Kevin Morales', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-20 18:33:55.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (50, N'Inventory Kristian Torres', N'Hacer Inventario a maquina de Kristian Torres', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-29 19:06:37.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (51, N'Inventory Luis Belliard', N'Hacer Inventario a maquina de Luis Belliard', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-20 18:16:59.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (52, N'Inventory Luis Burset', N'Hacer Inventario a maquina de Luis Burset', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-15 17:12:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (53, N'Inventory Luis De Jesus', N'Hacer Inventario a maquina de Luis De Jesus', N'closed', N'normal', N'1m', 21, 27, N'2025-12-15 17:12:12.0000000', N'2026-01-29 20:30:43.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (54, N'Inventory Luis Nieves', N'Hacer Inventario a maquina de Luis Nieves', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-23 20:23:30.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (55, N'Inventory Marcos Quiles', N'Hacer Inventario a maquina de Marcos Quiles', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-29 19:24:45.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (56, N'Inventory Max Oliveras', N'Hacer Inventario a maquina de Max Oliveras', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-15 17:12:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (57, N'Inventory Nathan Gonzalez', N'Hacer Inventario a maquina de Nathan Gonzalez', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-20 18:34:50.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (58, N'Inventory Rolando Rivera', N'Hacer Inventario a maquina de Rolando Rivera', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-22 14:24:16.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (59, N'Inventory Santiago Rodriguez', N'Hacer Inventario a maquina de Santiago Rodriguez', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-15 17:12:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (60, N'Inventory Sigfredo Carrero', N'Hacer Inventario a maquina de Sigfredo Carrero', N'todo', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-15 17:12:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (61, N'Inventory Willian Bnecosme', N'Hacer Inventario a maquina de Willian Bnecosme', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-20 18:03:03.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (62, N'Inventory Wilnelia Santos', N'Hacer Inventario a maquina de Wilnelia Santos', N'closed', N'normal', N'2w', 21, 21, N'2025-12-15 17:12:12.0000000', N'2025-12-22 17:56:18.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (63, N'Onedrive', N'Sync error due to not enough space', N'closed', N'normal', N'1h', 2, 21, N'2025-12-18 18:22:04.0000000', N'2025-12-19 02:46:57.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (64, N'Reinstalación de Revit ', N'La aplicación arrojo que la licencia fue caducada por lo cual, se tuvo que reinstalar el software nuevamente.', N'closed', N'normal', N'1h', 23, 21, N'2025-12-18 20:25:26.0000000', N'2025-12-19 02:46:22.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (65, N'Botón Créate debe ser Flotante ', N'Botón créate debe ser Flotante y solo debe tener acceso el admin module ', N'todo', N'normal', N'1w', 21, 21, N'2025-12-20 18:05:17.0000000', N'2025-12-20 18:05:17.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (66, N'Mas grises los botones del menú en White ', N'Los títulos de los submodulos no están muy visibles cuando el tema es White ', N'closed', N'medium', N'2w', 21, 27, N'2025-12-20 18:22:25.0000000', N'2025-12-27 23:11:54.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (67, N'Inventario Nathan Gonzalez', N'Hacer inventario Nathan Gonzalez de su PC', N'closed', N'normal', N'2w', 21, 21, N'2025-12-20 18:27:16.0000000', N'2025-12-20 18:29:46.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (68, N'Configuración remota via Anydesk', N'Configuración remota via Anydesk, para trabajar remoto los días lunes 29 y martes 30 de diciembre.', N'closed', N'normal', N'1h', 23, 21, N'2025-12-23 17:52:34.0000000', N'2025-12-23 18:33:30.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (69, N'Remover configuración de Inicio automático. ', N'Remover configuración de Inicio automático.', N'closed', N'normal', N'1h', 43, 21, N'2025-12-23 18:36:14.0000000', N'2025-12-23 23:18:44.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (70, N'Improvments Licenses ', N'Change color in expire date

disabled expired date & autopopulate expire date when is creating screen then set 1 year 

show the name of the employee', N'closed', N'normal', N'4h', 21, 21, N'2025-12-26 22:18:30.0000000', N'2025-12-26 22:18:41.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (71, N'changes in Hardware inventory', N'change color acording waranty 

autopopulate waranty 

show wmployee in list', N'closed', N'normal', N'4h', 21, 21, N'2025-12-26 22:20:40.0000000', N'2026-01-05 23:14:42.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (76, N'Instalar Office Test', N'Instalar office a Kevin ', N'closed', N'medium', N'4h', 21, 21, N'2025-12-30 17:19:14.0000000', N'2025-12-30 17:21:18.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (77, N'Push Notifications Via Email', N'-Cuando se Cree un nuevo ticket automaticamente debe llegar un correo al asigned To

-Cuando se cree un comentario debe tomar la decicion de quien esta creando el comentario y a quien va dirigido en este caso solo existe la logica de Created By y asigned to.

-En time off - Calendar el usuario quien esta realizando el ticket debe llegar una notificacion a su manager

', N'closed', N'medium', N'1w', 21, 27, N'2026-01-06 00:04:29.0000000', N'2026-01-08 03:05:09.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (78, N'Conexion a nueva Base de datos ', N'Voy a migrar la base de datos a sql de azure 

te dejo la conexion 

Driver={ODBC Driver 18 for SQL Server};Server=tcp:server-primefiredb.database.windows.net,1433;Database=primefirebd;Uid=PrimeFire;Pwd={your_password_here};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;', N'closed', N'normal', N'1w', 21, 21, N'2026-01-06 00:09:00.0000000', N'2026-01-26 16:10:34.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (81, N'Acceso Servidor TA', N'Se solicito acceso servidor a TA para poder acceder mas informacion de proyectos mientrsas se completa la migracion a proyectos PFP Server

', N'closed', N'normal', N'1h', 46, 21, N'2026-01-08 12:36:53.0000000', N'2026-01-08 13:52:57.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (82, N'Data of Business ', N'Buen día Emmanuel porfavor de agregar los datos que nos pide ZenFire', N'closed', N'high', N'24h', 21, 10, N'2026-01-15 00:16:51.0000000', N'2026-01-26 16:11:14.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (83, N'ZenFire Information RD', N'Buenas tardes Emmanuel 
Si me puedes asistir con la información que nos pide ZenFire para que den de alta ', N'closed', N'high', N'24h', 21, 10, N'2026-01-15 00:19:37.0000000', N'2026-01-26 16:11:03.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (84, N'ZenFire Guaynabo Informationn', N'Información de Guaynabo para darlo de alta en la plataforma de ZenFire ', N'closed', N'high', N'24h', 21, 18, N'2026-01-15 00:22:29.0000000', N'2026-01-21 12:45:54.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (85, N'ZenFire Information TA', N'Kevin porfavor agregar la información de Trujillo Alto ', N'closed', N'high', N'24h', 21, 28, N'2026-01-15 00:26:11.0000000', N'2026-01-21 12:45:36.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (86, N'Revisar ZenFire', N'Test', N'closed', N'normal', N'8h', 21, 3, N'2026-01-17 18:28:06.0000000', N'2026-01-26 16:10:45.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (87, N'Business Proposals ', N'Dentro de este modulo, ahi que poner el submodulo de Customers 
El modulo de customers debt tener la si guide the information:

Information General,
Address 
Notes
Contact
Attachments', N'closed', N'normal', N'2w', 21, 27, N'2026-01-21 13:42:29.0000000', N'2026-02-04 15:02:32.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (88, N'Outlook no funciona ', N'agregar Primefire@outlook.com
arreglar visor de outlook', N'closed', N'normal', N'1h', 11, 21, N'2026-01-23 13:30:47.0000000', N'2026-01-23 13:54:18.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (89, N'Agregar Notas a Licences ', N'Agregar Notas a Licencias ', N'closed', N'normal', N'8h', 21, 27, N'2026-01-26 23:56:57.0000000', N'2026-01-26 23:57:06.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (90, N'Agregar Customers ', N'Agregar Customers en un nuevo modulo llamado Business Proposals, dentro de este modulo agregar Customers de ZenFire  ', N'closed', N'normal', N'1w', 21, 27, N'2026-01-26 23:59:28.0000000', N'2026-02-03 18:50:52.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (91, N'Unable to login in Office365 from the browser', N'Unable to login in Office365 from the browser', N'closed', N'medium', N'1h', 2, 21, N'2026-02-04 20:19:29.0000000', N'2026-02-04 20:21:06.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (92, N'Time Sheet Component - Componente Data User ', N'Componente de los datos del usuario', N'closed', N'normal', N'8h', 21, 27, N'2026-02-05 00:59:06.0000000', N'2026-03-03 00:17:28.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (93, N'TimeSheet - Clocking Component', N'Agregar un servicio que obtenga la localización y agregar un screenshot de la hora.
agregarla al componente clocking descripcion: 
Customer seleccionado:
1-.El customer debe ser mandatorio para activar el timesheet
2-.Cuando se hace screenshot del clocking automáticamente debe aparecer el botón Clockout', N'closed', N'normal', N'48h', 21, 27, N'2026-02-05 01:01:10.0000000', N'2026-03-03 00:17:18.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (94, N'TimeSheet - Dashboard Component', N'Agregar el UI con el prerrellenado de los servicios, agregar los filtros el componente de la lista customers descripcion: 

El TimeSheet debe ser filtrado por mes y tener un paginador según la pantalla para cubrir todos los dias.

En automático se deben llenar los campos sin embargo esos deben ser inputs que solo con el rol admin o manager pueden estar habilitados manualmente o en su caso debe haber un botón o sección donde el usuario debe pedir permisos para habilitar esos campos.

Debe haber un servicio que comunica la vacacion, enfermedad o el día festivo en automático debe llenarse desde time-off.

Exportar Excel con los títulos y data:
Aplicar un filtro de rangos de fecha para descargar el Excel
Como extra de ser posible un campo mas puede ser notas donde explique el cliente con el que efectuo las horas laboradas día a dia

', N'closed', N'high', N'2w', 21, 27, N'2026-02-05 01:04:03.0000000', N'2026-03-08 22:21:23.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (95, N'Access to Prime Services Folder (Resolved)', N'Access Request to prime services folder ', N'closed', N'normal', N'1h', 45, 21, N'2026-02-05 19:58:56.0000000', N'2026-02-05 19:59:48.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (96, N'Filtros no funcionan', N'Outlook filtra de 1 año hacia atras en el buscador', N'closed', N'normal', N'1h', 8, 21, N'2026-02-10 16:41:11.0000000', N'2026-02-10 16:41:48.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (97, N'Arreglo de firma de Outlook', N'me salen dos diferentes firmas cuando envío un email nuevo. Si se podrá arreglar con que solo salga el que dice Engineering Alarm Designer y no el de Job Safety Analyst (es posición vieja).

Gracias', N'closed', N'low', N'1w', 35, 21, N'2026-02-10 17:29:59.0000000', N'2026-02-11 00:54:54.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (98, N'Instalación del programa VeriFire Tools', N'Instalación de este programa para el uso de Santiago Rodriguez, ya que su PC asignada esta averiada.', N'closed', N'urgent', N'1h', 23, 21, N'2026-02-23 17:29:52.0000000', N'2026-02-24 13:51:20.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (99, N'Modificacion de Firma', N'El numero secundario de mi correo está incorrecto.', N'closed', N'normal', N'4h', 16, 27, N'2026-02-23 17:37:29.0000000', N'2026-03-08 22:21:09.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (100, N'Crear email empleado', N'Crear email al empleado:
 Luis D. Lugo
Técnico Servicio Nivel II
(787)630-6000 oficina
(787)951-4104 celular
Oficina de Guaynabo', N'closed', N'high', N'4h', 44, 27, N'2026-02-24 16:21:00.0000000', N'2026-03-06 12:30:50.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (101, N'Issue Load Menu ', N'El Menu no Carga ahi que darle refresh algunas veces ', N'closed', N'normal', N'8h', 21, 27, N'2026-02-24 23:58:31.0000000', N'2026-03-08 22:20:59.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (102, N'Boton con el tema Blanco ', N'el boton create se ve el del tema negro cuando aun cuando cambiamos a tema blanco', N'closed', N'normal', N'4h', 21, 27, N'2026-03-03 01:16:34.0000000', N'2026-03-09 02:50:03.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (103, N'installation all programs ', N'install all programs Max Machine', N'closed', N'medium', N'4h', 33, 21, N'2026-03-04 12:45:01.0000000', N'2026-03-05 19:09:15.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (104, N'New Hire!', N'Tenemos una empleada nueva que empezara a trabajar en la oficina de Guaynabo el lunes, 9 de marzo. Su nombre es Rosa M. Rivera Rivera. Su posición es Project Manager - Ai Strategic Efficiency. Necesito le crees email y accesos necesarios - one drive, proyectos, etc. Cualquier duda o pregunta contactarme al (860)841-3625. Gracias. ', N'closed', N'high', N'24h', 44, 21, N'2026-03-04 14:11:52.0000000', N'2026-03-06 01:24:11.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (105, N'Configuracion apps computadora', N'Instalar aplicaciones y servicios', N'closed', N'normal', N'4h', 49, 21, N'2026-03-09 17:27:42.0000000', N'2026-03-23 15:01:19.6133333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (106, N'Add emails to forms ', N'Agregar a Giovanni y Wilnelia al form de la webpage PR 

Agregar a Enmanuel a la webpage DO ', N'closed', N'normal', N'4h', 21, 27, N'2026-03-10 19:21:14.0000000', N'2026-03-21 05:25:52.9700000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (107, N'Mejora de time sheet', N'cuando el usuario le da click en Clock in automáticamente debe aparecer reflejado en start time ', N'closed', N'normal', N'4h', 21, 27, N'2026-03-12 14:53:59.0000000', N'2026-03-27 02:35:33.3933333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (108, N'Mejoras TimeOFF', N'time off: no puedes pedir permisos si no existe un manager -- validacion del manager 
time off: Halliday automatico por países y enrolar a un employee por país para mostrar sus hollidays
verificar por que no funciona servicio cuando el correo no es de un dominio empresarial', N'closed', N'normal', N'4w', 21, 21, N'2026-03-13 00:28:50.0000000', N'2026-03-23 15:04:12.2466667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (109, N'Issue Correo Outlook', N'Correos borrados vuelven al bandeja de inbox', N'closed', N'normal', N'4h', 28, 21, N'2026-03-17 15:49:38.0000000', N'2026-03-23 15:00:45.7100000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (110, N'Ticket para JR', N'Excel', N'closed', N'medium', N'1h', 29, 21, N'2026-03-18 16:58:58.0000000', N'2026-03-23 15:00:57.2900000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (111, N'Mejoras en Tickets ', N'-Agregar gráficas por user para tickets 
-Agregar un dropdown tipo que identifique si es issue, request, improvement
-agregar si es repetitivo día/semana/mes', N'closed', N'high', N'2w', 21, 27, N'2026-03-23 15:03:48.6666667', N'2026-03-27 02:48:08.6666667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (112, N'Title Change', N'Change the "Tittle" or "Position" from "Global Inventory Manager" to "Project Estimator"', N'closed', N'normal', N'48h', 16, 21, N'2026-03-23 15:56:04.3300000', N'2026-04-01 23:27:00.3233333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (113, N'Dar de alta empleados con el role especifico en ZenFire', N'el objetivo de esta tarea es dar de alta todos los usuarios en ZenFire de RD 
Preguntar a Enmanuel quienes faltan en el organigrama.', N'closed', N'high', N'48h', 21, 49, N'2026-03-24 19:45:01.4466667', N'2026-04-06 18:53:20.7266667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (114, N'Dar de alta a los Customers RD activos en ZenFire ', N'Dar de alta a los customers con los datos Nombre, email, dirección, contacto, y empresa', N'closed', N'high', N'1w', 21, 49, N'2026-03-24 19:46:57.7000000', N'2026-04-06 18:53:15.5166667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (115, N'Dar de alta los customers de Puerto Rico en PrimeFire App', N'Dar de alta los customers inicialmente de Building Reports, Preguntar a Giovanni si ahi mas ', N'closed', N'normal', N'2w', 21, 49, N'2026-03-24 19:52:57.9500000', N'2026-04-07 11:29:04.8133333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (116, N'Forgot password Login Auth ', N'Agregar opcion para el usuario que olvidó el password ', N'closed', N'medium', N'4w', 21, 27, N'2026-03-26 01:26:27.7333333', N'2026-03-27 05:31:20.3366667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (117, N'test', N'test', N'closed', N'normal', N'1h', 27, 27, N'2026-03-27 02:36:11.4666667', N'2026-03-27 02:36:26.1266667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (118, N'Backup Wilnelia ', N'Hacer respaldo de documentos a Wilnelia', N'closed', N'normal', N'24h', 21, 21, N'2026-04-01 23:29:23.7700000', N'2026-04-06 18:55:46.2233333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (119, N'Agregar Secure Form a PrimeFire Form', N'Agregar que se vayan a Spam o revisar si es bot el formulario de PrimeFire ', N'closed', N'high', N'24h', 21, 27, N'2026-04-01 23:32:45.8566667', N'2026-04-01 23:33:18.7266667', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (120, N'Reacomodar arquitectura Front End', N'Agregar arquitectura MVC módulos y submódulos ejemplo dentro de systems, submodulos y homologar validación de controles ', N'closed', N'normal', N'1w', 21, 27, N'2026-04-01 23:35:35.9733333', N'2026-04-08 23:21:03.0066667', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (121, N'Agregar vista View Products, Hardware & Licences', N'Agregar vista View Products, Hardware & Licences', N'closed', N'normal', N'48h', 21, 21, N'2026-04-01 23:38:11.8966667', N'2026-04-18 17:47:32.0266667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (122, N'Agregar Email generico para cuentas Chat Gpt', N'Agregar email generico para cuentas de chat gpt', N'closed', N'normal', N'24h', 21, 21, N'2026-04-01 23:40:18.4633333', N'2026-04-18 17:47:21.4033333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (123, N'Validar al menos 1 hora en timesheet por cliente ', N'Si hacen clock out en timesheet en menos de una hora que salga un popop tipo warning que no se ha cumplido una hora con ese customer ', N'closed', N'normal', N'24h', 21, 27, N'2026-04-02 00:32:42.1900000', N'2026-04-08 23:41:11.9233333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (124, N'Set up laptop', N'Need to set all apps in laptop.', N'closed', N'normal', N'8h', 6, 21, N'2026-04-02 11:11:16.0733333', N'2026-05-01 17:47:05.7066667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (125, N'Mejora de Dashboard ', N'mejorar en lo mas importante el dashboard no copiar lo que ya tenemos en el menu', N'closed', N'high', N'2w', 21, 27, N'2026-04-03 07:08:03.5500000', N'2026-05-06 00:59:54.7000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (126, N'Printer Scanner Setup', N'Setup printer scanner for Rosa Rivera.', N'closed', N'normal', N'4h', 49, 21, N'2026-04-06 13:30:10.5466667', N'2026-04-20 23:47:07.3433333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (127, N'Agregar Time off todos los empleados de PR ', N'agregar las vacaciones, enfermedad o permiso de PR a time off', N'todo', N'normal', N'48h', 21, 49, N'2026-04-06 18:54:03.2033333', N'2026-04-06 18:54:03.2033333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (128, N'Bluebeam question', N'We are experiencing multiple issues. Do we have the most recent version?', N'closed', N'normal', N'1h', 2, 21, N'2026-04-07 15:26:50.8666667', N'2026-05-06 01:00:06.7000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (129, N'Issue absence reports ', N'cuando pongo este filtro no me sale Adolfo ', N'closed', N'normal', N'48h', 21, 27, N'2026-04-09 00:31:56.2966667', N'2026-04-12 23:22:51.6700000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (130, N'time off No se sobrescribe ', N'dice que puso el dia 23 medio tiempo y luego lo cancelo y luego puso vacaciones todo ese dia 
adicional el dia 24 y se sobreescribieron 4 items entre 23 y 24 tal como se muestra 
 ', N'closed', N'normal', N'48h', 21, 27, N'2026-04-09 00:34:10.0933333', N'2026-04-12 23:23:34.8066667', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (131, N'Asistencia con mi equipo', N'marca error cad vez que enciendo el equipo y me sale ese pop up durante el uso
', N'closed', N'normal', N'8h', 46, 21, N'2026-04-09 11:48:31.4533333', N'2026-05-20 23:58:38.8400000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (132, N'agregar nuevo role module solo admin', N'agregar nuevo role module solo admins ', N'closed', N'normal', N'12h', 21, 27, N'2026-04-18 16:56:31.4100000', N'2026-04-24 01:34:34.1600000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (133, N'responsive Dasboard', N'mejorar bloques del dasboardh que sean responsive para todos 
homologar  
iPhone Pro: 393 × 852 px, devicePixelRatio: 3
iPhone Pro Max: 430 × 932 px, devicePixelRatio: 3
iPad (línea base / 10ª gen aprox.): 810 × 1080 px, devicePixelRatio: 2
iPad 11-inch / iPad Pro 11": 834 × 1194 px, devicePixelRatio: 2
Laptop Apple
MacBook Air 13: 1280 × 800 px
', N'closed', N'normal', N'12h', 21, 27, N'2026-04-18 17:44:04.5566667', N'2026-04-24 04:41:25.1800000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (134, N'Replicate Ticket', N'agregar boton replicate Ticket que se autopopulen todos los campos y sean editables, cuando le de enviar se creara un nuevo ticket', N'closed', N'medium', N'12h', 21, 27, N'2026-04-18 17:47:03.8100000', N'2026-04-24 03:11:38.7933333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (135, N'Cambiar schemas .dbo por modulos ', N'agregar schemas por modulos en la base de datos y mapearlos en Python ', N'closed', N'high', N'1w', 21, 27, N'2026-04-18 18:13:06.1966667', N'2026-05-19 00:43:22.9666667', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (136, N'Documentacion por modulo ', N'Agregar Documentacion por modulo en archivo pdf Inicialmente, Dashboard, Jobs, Workforce Managment, Systems, Configurations, etc... ', N'todo', N'normal', N'24h', 21, 21, N'2026-04-18 18:16:32.4066667', N'2026-04-18 18:16:32.4066667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (137, N'New Email Request for NFPA Link', N'Request of a new email for the use of NFPA Link', N'closed', N'normal', N'8h', 45, 21, N'2026-04-22 19:03:18.0700000', N'2026-04-23 23:20:04.8800000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (138, N'Configurar impresora Canon ', N'Configuración impresora Canon para Kristian Torres', N'todo', N'medium', N'8h', 21, 21, N'2026-04-24 14:20:04.3066667', N'2026-04-24 14:20:04.3066667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (139, N'Configurar impresora Canon ', N'Configuración impresora Canon para Giovanni Velez', N'closed', N'medium', N'8h', 21, 21, N'2026-04-24 14:22:12.5200000', N'2026-04-27 19:40:09.6866667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (140, N'Can''t access to onedrive', N'Can''t access to onedrive', N'closed', N'normal', N'1h', 12, 21, N'2026-04-27 14:53:37.0566667', N'2026-05-01 17:45:42.8533333', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (141, N'HARD ROCK-POTTER', N'POTTER-BOOM', N'todo', N'high', N'1w', 18, 2, N'2026-04-28 18:31:25.3866667', N'2026-04-28 18:31:25.3866667', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (142, N'HARD ROCK-POTTER', N'POTTER-BOOM', N'todo', N'high', N'1w', 18, 35, N'2026-04-28 18:31:49.3566667', N'2026-04-28 18:31:49.3566667', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (143, N'Liberty ', N'Cuadro telefonico', N'todo', N'medium', N'8h', 49, 49, N'2026-04-28 18:40:36.3333333', N'2026-04-28 18:40:36.3333333', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (144, N'Notify key players of vacation and send approval to manager', N'Module - Time Off Calendar
', N'todo', N'normal', N'8h', 49, 21, N'2026-04-28 18:42:48.1200000', N'2026-04-28 18:44:01.1366667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (145, N'Coordinates which clocking in', N'Coordinates saved when clocking in and out', N'todo', N'medium', N'24h', 49, 21, N'2026-04-28 18:48:40.4200000', N'2026-04-28 18:48:40.4200000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (146, N'Hidden', N'Some modules', N'closed', N'normal', N'8h', 49, 21, N'2026-04-28 18:54:23.4333333', N'2026-06-18 00:39:10.0000000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (147, N'Update employee list', N'eliminar 
Edwin de Jesus
Baxter Jayauya
raynee funez
staphanie martinez
wilnelia santos

cambiar
Elizaud cambiar a Manager
Kevin Morales cambiar a manager
 ', N'closed', N'normal', N'8h', 49, 21, N'2026-04-28 19:02:17.5933333', N'2026-05-07 00:38:41.8100000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (148, N'Give users to modules', N'Time off and tickets', N'todo', N'normal', N'8h', 49, 21, N'2026-04-28 19:05:47.0833333', N'2026-04-28 19:05:47.0833333', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (149, N'Santiago configuración ', N'Configuración de máquina de Santiago 
Issue con planos en el iPad ', N'closed', N'medium', N'4h', 21, 21, N'2026-05-01 00:01:57.1100000', N'2026-05-01 00:02:11.9666667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (150, N'agregar listado Assign todos los empleados con el role de Manager ', N'agregar listado Assign todos los empleados con el role de Manager ', N'closed', N'normal', N'12h', 21, 27, N'2026-05-06 01:03:50.0133333', N'2026-05-12 01:02:30.7966667', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (151, N'Computadora Lorenzo Luciano', N'Preparar para Lorenzo
Firma, Office 2016 -2019, Meterlo a Microsoft entra AD,  en m365 agregar la info de Trujillo alto Puesto: Assistant Project Manager, permisos en la nube como los de Max Oliveras, Inventario de Hardware', N'closed', N'normal', N'4h', 21, 27, N'2026-05-07 19:58:41.7066667', N'2026-05-08 15:52:29.0833333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (152, N'Issue en Employees', N'no me permite actualizar campos la seccion de empleados', N'closed', N'medium', N'1h', 21, 27, N'2026-05-08 00:43:40.2666667', N'2026-05-23 04:16:52.7566667', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (153, N'Filtro por empleado', N'filtro en tickets por empleado
1-. si es user se queda igual 
2-. si es manager solo debe aparecer los empleados subordinados
3-. si es admin debe ver el filtro de todos los empleados ', N'closed', N'normal', N'4h', 21, 27, N'2026-05-08 00:46:15.4800000', N'2026-05-10 18:14:34.5966667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (154, N'Query Solo empleados Activos y con licencia', N'de la lista de empleados realizar un query que muestre solo activos y con licencia, los externos esconderlos', N'closed', N'medium', N'1h', 21, 27, N'2026-05-08 00:55:38.5966667', N'2026-05-23 00:47:18.1600000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (155, N'Mejora en tickets SLA', N'ver si hay manera que el ticket empiece el SLA cuando el usuario cambie el status a in progress ', N'closed', N'medium', N'4h', 21, 27, N'2026-05-08 00:57:12.0133333', N'2026-05-10 18:14:49.0066667', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (156, N'Iconos Menu', N'Iconos por modulo compatiubles con angular material', N'closed', N'medium', N'8h', 21, 27, N'2026-05-12 01:13:21.6000000', N'2026-05-23 00:26:20.4666667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (157, N'Migracion de customers', N'migrar todos los customers a la base de datos, despues en el excel validar 

en el excel campos mandatorios
duplicidad

', N'closed', N'normal', N'8h', 21, 27, N'2026-05-12 01:17:32.0633333', N'2026-05-23 00:26:30.1266667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (158, N'escaneo de mantenimiento a PC', N'se solicita servico de escaneo y mantenimiento de la PC. hace varias semanas ha estado dando erores con el uso de autocad. subiendo los archivo daba un error que indicaba que el archivo no podia abrirse porque no estaba disponible y daba de baj l programa de autocad. habia pensado que podia ser la coneccion al internet que estaba intermitente y copiaba los archivo al disco duro local de la PC para trabajarlos y luego subirlo a la nube. aun asi en varias ocaciones dio el error. ya que desde ayer no ha vuelto a presentar el error.', N'closed', N'normal', N'4h', 34, 21, N'2026-05-19 13:43:50.6633333', N'2026-05-26 00:43:29.7633333', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (159, N'Scroll Pagination', N'si no hay mas paginacion, mostrar no more Items to show o algo similar.
revisar query involves me.
', N'active', N'normal', N'4h', 21, 27, N'2026-05-26 00:51:57.9766667', N'2026-07-08 04:14:28.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (160, N'Module Inventory overview ', N'Módulos inventory general ', N'closed', N'normal', N'24h', 21, 27, N'2026-05-26 11:44:10.4800000', N'2026-06-18 04:51:19.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (161, N'Inventory Entires ', N'Page to add products ', N'closed', N'medium', N'24h', 21, 27, N'2026-05-26 11:47:19.2466667', N'2026-06-18 04:51:28.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (162, N'Inventory - Outputs', N'Inventory 
When is a new estimation you need to take the stock inventory. Then if the estimation is created a project the inventory needs output ', N'todo', N'medium', N'24h', 21, 21, N'2026-05-26 11:49:44.1966667', N'2026-05-26 11:49:44.1966667', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (163, N'Inventory Adjustment ', N'This page is to regulate the inventory 
Just for admins and managers ', N'closed', N'normal', N'24h', 21, 27, N'2026-05-26 11:50:59.4833333', N'2026-06-18 04:51:07.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (164, N'Inventory - Movements ', N'This inventory page is the historical of movements, where take the products, where, who add more products etc', N'closed', N'normal', N'24h', 21, 27, N'2026-05-26 11:52:46.1533333', N'2026-06-18 04:51:00.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (165, N'Access to Prime email', N'Add primefire@outlook.com to be able to access it', N'closed', N'normal', N'1h', 49, 21, N'2026-05-26 18:30:11.4733333', N'2026-05-27 22:17:30.1833333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (166, N'NFPA Link Membership Activation', N'Saludos Jonathan, este ticket es para solicitar que se active la membresia de NFPA link del email que creaste hace un tiempo ', N'todo', N'normal', N'1h', 45, 21, N'2026-05-26 19:50:47.9300000', N'2026-05-26 19:50:47.9300000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (167, N'Notificaciones Tickets are failure', N'Cuando creo un ticket no llega la notificación ', N'closed', N'normal', N'4h', 21, 27, N'2026-05-28 00:53:52.7000000', N'2026-05-29 04:24:05.0000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (168, N'Nuevo Organigrama ', N'Organigrama actual con managers ', N'todo', N'low', N'4h', 21, 49, N'2026-05-28 00:56:29.0333333', N'2026-05-28 00:56:29.0333333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (169, N'Excel Customers ', N'Excel de Louis customers de República Dominicana ', N'todo', N'normal', N'4h', 21, 21, N'2026-05-28 00:57:50.4733333', N'2026-05-28 00:57:50.4733333', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (176, N'Set New configuration Santiago Rodriguez ', N'Configurar nueva computadora para Santiago Rodríguez ', N'closed', N'normal', N'4h', 21, 21, N'2026-06-02 20:40:54.0000000', N'2026-06-04 12:14:24.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (177, N'Configuración M365 Sofía Rodríguez ', N'Agregar correo y datos a Sofía Rodríguez ', N'closed', N'normal', N'4h', 21, 21, N'2026-06-02 20:44:26.0000000', N'2026-06-04 12:14:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (178, N'New configuration Mario Ordaz', N'New programas 

Adobe Acrobat licencia
Licencia Windows 11 Pro
Instalar antivirus

Visual studio 
Visual studio code 
Sql express 
Firma electrónica HTML
Teams 



', N'closed', N'normal', N'4h', 21, 54, N'2026-06-04 12:18:26.0000000', N'2026-06-13 20:49:45.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (179, N'Agregar data faltante a los empleados PrimeFire ', N'Además de homologar la dirección, oficina hay que recolectar todos los AnyDesk en la aplicacion', N'todo', N'normal', N'4h', 21, 54, N'2026-06-04 12:20:15.0000000', N'2026-06-04 12:20:15.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (180, N'Documentar la aplicación ', N'Documentar funcionamiento de la aplicación PrimeFire módulo por módulo y como funciona para compartirlo en un share knowledge ', N'closed', N'normal', N'12h', 21, 54, N'2026-06-04 12:21:52.0000000', N'2026-06-18 18:10:40.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (181, N'M365 ', N'Verificar que todos los empleados tengan la verificación dos pasos de teléfono 
verificar quienes tienen permisos de otros usuarios en exchange 
', N'closed', N'normal', N'4h', 21, 54, N'2026-06-04 12:23:12.0000000', N'2026-06-23 16:42:54.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (182, N'Products Modify Module', N'Agregar: Code, Family, Category, Material_Type_Min_Stck_Needed_Quantitty al stock actual', N'closed', N'normal', N'8h', 21, 27, N'2026-06-07 06:52:54.0000000', N'2026-06-18 04:51:12.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (183, N'Warehouse Module', N'AddWarehouse Module Table ', N'closed', N'normal', N'8h', 21, 27, N'2026-06-07 06:55:30.0000000', N'2026-06-18 04:50:54.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (184, N'Add Products Catalog', N'agregar esta modulo: 
CREATE TABLE product_catalog (
    id SERIAL PRIMARY KEY,

    code VARCHAR(50) UNIQUE NOT NULL,

    name VARCHAR(255) NOT NULL,

    family_id INT,
    category_id INT,

    unit VARCHAR(20),

    min_stock NUMERIC(12,2) DEFAULT 0,

    active BOOLEAN DEFAULT TRUE,

    description TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_product_family
        FOREIGN KEY (family_id)
        REFERENCES product_families(id),

    CONSTRAINT fk_product_category
        FOREIGN KEY (category_id)
        REFERENCES product_categories(id)
);', N'closed', N'normal', N'8h', 21, 27, N'2026-06-07 06:59:46.0000000', N'2026-06-18 04:50:46.0000000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (185, N'Add Product Family', N'CREATE TABLE product_families (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);', N'closed', N'normal', N'8h', 21, 27, N'2026-06-07 07:00:34.0000000', N'2026-06-18 04:50:41.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (186, N'Add Product categpry', N'CREATE TABLE product_categories (
    id SERIAL PRIMARY KEY,
    family_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    active BOOLEAN DEFAULT TRUE,

    CONSTRAINT fk_category_family
        FOREIGN KEY (family_id)
        REFERENCES product_families(id)
);', N'closed', N'normal', N'4h', 21, 27, N'2026-06-07 07:01:18.0000000', N'2026-06-18 04:50:34.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (187, N'Add Product Especifications', N'CREATE TABLE product_specifications (
    id SERIAL PRIMARY KEY,

    product_id INT NOT NULL,

    specification VARCHAR(100),

    size VARCHAR(100),

    material VARCHAR(100),

    manufacturer VARCHAR(100),

    model VARCHAR(100),

    notes TEXT,

    CONSTRAINT fk_spec_product
        FOREIGN KEY (product_id)
        REFERENCES product_catalog(id)
);', N'closed', N'normal', N'8h', 21, 27, N'2026-06-07 07:02:03.0000000', N'2026-06-18 04:50:16.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (188, N'agregar a Juan y Mario al organigrama como mi equipo', N'agregar a Juan y Mario al organigrama como mi equipo', N'closed', N'normal', N'4h', 21, 49, N'2026-06-17 14:01:31.0000000', N'2026-07-14 15:23:54.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (189, N'Agregar Managers a employees ', N'acorde al organigrama agregar los managers ', N'closed', N'normal', N'4h', 21, 54, N'2026-06-17 14:12:21.0000000', N'2026-06-30 18:46:55.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (190, N'Separar por controllers(modulos) el swagger ', N'Separar por controllers(modulos) el swagger 
', N'on_hold', N'low', N'8h', 21, 27, N'2026-06-17 14:20:54.0000000', N'2026-07-08 04:19:17.0000000', N'request', N'2026-07-08 04:16:26.0000000')
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (191, N'correr el ruff y hacer una limpieza acorde al codigo ', N'correr el ruff y hacer una limpieza acorde al codigo ', N'closed', N'normal', N'8h', 21, 27, N'2026-06-17 14:23:22.0000000', N'2026-06-18 04:50:08.0000000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (192, N'fix en el create hardware inventory', N'No se activa el boton create o esta hidden cuando llenamos para una computadora', N'closed', N'normal', N'4h', 21, 27, N'2026-06-17 14:24:21.0000000', N'2026-06-18 04:50:01.0000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (193, N'agregar a la documentacion el modulo de Inventario', N'Agregar a la documentacion el modulo de Inventario', N'closed', N'normal', N'4h', 21, 54, N'2026-06-17 14:36:21.0000000', N'2026-06-18 18:10:55.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (194, N'Set Up Dean Ortiz', N'Despues de crear el usuario de Dean Ortiz ayudarlo a configurar su dispositivo', N'closed', N'high', N'1h', 21, 54, N'2026-06-18 00:37:17.0000000', N'2026-06-22 16:29:55.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (195, N'Have the Org Chart updated', N'Have org chart updated to enable vacation sick and PTO requests', N'todo', N'high', N'1w', 49, 21, N'2026-06-18 15:21:59.0000000', N'2026-06-18 15:21:59.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (196, N'Material Autopopulation', N'CP - Tool was shared through teams', N'todo', N'normal', N'1w', 49, 21, N'2026-06-18 15:35:58.0000000', N'2026-06-18 15:35:58.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (197, N'Instalación de AutoCAD', N'Requiero la habilitación de AutoCAD para usarlo con cuenta, no con la clave de producto. ', N'closed', N'high', N'1h', 43, 54, N'2026-06-18 19:03:44.0000000', N'2026-06-22 16:29:49.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (198, N'Support Servidor', N'Se solicito soporte a acceder a servidor', N'closed', N'normal', N'1h', 46, 21, N'2026-06-19 13:59:34.0000000', N'2026-06-22 14:25:38.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (199, N'error en firma outlook', N'error en firma outlook', N'closed', N'normal', N'1h', 52, 54, N'2026-06-19 16:45:27.0000000', N'2026-06-22 16:26:35.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (200, N'New User ', N'Luis O Morales

939 210 3807
Fire Alarm Inspector
Guaynabo
No tiene equipo por el momento...', N'closed', N'normal', N'1h', 21, 54, N'2026-06-22 14:25:24.0000000', N'2026-06-22 17:36:16.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (201, N'documento firma duplicada y/o ver forma que se pueda bloquear o editar las formas de Outlook  ', N'dado de que se estan duplicando las firmas hacerlo saber con el documento y ademas, ver una manera de deshabilitar ese boton. con m365', N'todo', N'normal', N'8h', 21, 54, N'2026-06-23 23:08:03.0000000', N'2026-06-23 23:08:03.0000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (202, N'Verificar Licencias activas de AutoCAD, AlarmCAD, Subscripciones Godaddy, Dominio DO', N'Verificar Licencias activas de AutoCAD, Ademas de agregar el vencimiento del dominio DO', N'todo', N'normal', N'4h', 21, 54, N'2026-06-23 23:14:32.0000000', N'2026-06-23 23:16:51.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (203, N'Pruebas en Inventory con Data ', N'agregar las dos facturas a Inventario ', N'closed', N'normal', N'4h', 21, 54, N'2026-06-23 23:15:40.0000000', N'2026-07-07 22:31:29.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (204, N'Ticket solo aparece a nivel Dasboard no el Modulo ', N'si solo tiene User de role deberia aparecer Modulo Systems/Tickets, WM/TimeSheet,Time Off', N'closed', N'normal', N'1h', 21, 27, N'2026-06-24 00:49:55.0000000', N'2026-06-24 03:52:04.0000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (205, N'Filtros en Local Storage', N'Hacer un barrido a todos los submodulos y agregar los filtros al localstorage y borrarlos una vez expire la sesion o logout', N'closed', N'normal', N'8h', 21, 27, N'2026-06-24 00:51:06.0000000', N'2026-06-25 01:27:05.0000000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (206, N'Cambios en Inventory', N'remover qty de products, remover minimun stock de products, agregar minumin stock a entries y reflejarlo en overview', N'closed', N'urgent', N'4h', 21, 27, N'2026-06-24 00:52:46.0000000', N'2026-06-24 03:25:25.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (207, N'Responsive Products', N'Hacerlo Responsivo Para Tablets toma de referencia el IPad Pro 11 y 13 Inch', N'closed', N'high', N'8h', 21, 27, N'2026-06-27 21:01:33.0000000', N'2026-07-02 02:36:19.0000000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (208, N'Products UI o mensajes de error en campos requeridos ', N'Llene los campos y se activo el botón Créate pero no se realizaba el Insert y no me muestra error', N'closed', N'medium', N'4h', 21, 27, N'2026-06-27 21:03:13.0000000', N'2026-07-08 01:45:15.0000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (209, N'Validar lógica en MIN stock Inventory', N'Colores de Min Stck si la cantidad es min stock + 20% al mínimo stock Muestra Naranja
Si es menor al min Stock rojo y si es Mayor al min stock + 20% muéstralo en verde', N'closed', N'normal', N'4h', 21, 27, N'2026-06-27 21:12:36.0000000', N'2026-07-02 02:20:11.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (210, N'Borrar Needed Quantity a products ', N'Borrar Needed Qty por que ya existe Min Stock', N'closed', N'normal', N'4h', 21, 27, N'2026-06-27 21:13:49.0000000', N'2026-07-02 02:20:07.0000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (211, N'Buscador en Dropdown products en Inventory', N'Agregar un buscador de Products a Invenrtory en un Escenario de 500 products o mas se debería facilitar la búsqueda del producto. 

El producto debe aparecer [partNumber]-[Product]
', N'todo', N'normal', N'8h', 21, 4, N'2026-06-27 21:17:03.0000000', N'2026-06-27 21:17:03.0000000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (212, N'Reinstalar AlarmCad Joskayra', N'Reinstalar alarmaCad joskayra', N'closed', N'normal', N'1h', 21, 54, N'2026-06-30 01:20:08.0000000', N'2026-06-30 18:41:05.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (213, N'Reinstalar AlarmCad William', N'Reinstalar alarmaCad William ', N'todo', N'normal', N'1h', 21, 54, N'2026-06-30 01:20:39.0000000', N'2026-06-30 01:20:39.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (214, N'Cambiar título a Kristian ', N'Cambie titulo /posición Kristian torres ', N'closed', N'normal', N'1h', 21, 54, N'2026-06-30 01:21:46.0000000', N'2026-07-07 22:30:25.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (215, N'Validar doble firma ', N'Validar que Rosa María y Lorenzo no tengan doble firma y además enviar correo con las instrucciónes de solo agregar la firma de reply en outlook', N'todo', N'normal', N'1h', 21, 54, N'2026-06-30 02:30:13.0000000', N'2026-06-30 02:30:13.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (216, N'Crear usuario de ivanska Hernandez', N'Agregar usuario y dar soporte con teams, outlook y verificar si va a tener equipo', N'closed', N'normal', N'1h', 21, 54, N'2026-06-30 02:31:32.0000000', N'2026-07-04 23:27:29.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (217, N'Inventory Entries ', N'Validar Entries que si no existe ningun producto salga un popup que avise que debes agregar products ', N'closed', N'medium', N'4h', 21, 27, N'2026-07-02 01:35:11.0000000', N'2026-07-02 02:36:28.0000000', N'issue', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (218, N'Onboarding and Offboarding Process', N'When hiring and laying off personal', N'todo', N'normal', N'2w', 49, 21, N'2026-07-03 18:03:14.0000000', N'2026-07-03 18:03:14.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (219, N'Unactive and active filter', N'to see which people are still on prime', N'todo', N'normal', N'4w', 49, 21, N'2026-07-03 18:04:30.0000000', N'2026-07-03 18:04:30.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (220, N'Filtro por wharehouses en Inventory', N'Agregar el Filtro por Wharehouses ', N'closed', N'normal', N'4h', 21, 27, N'2026-07-04 23:20:42.0000000', N'2026-07-08 04:19:02.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (221, N'Notificacion a Manager cuando va a ser una salida de Inventario Y validar Stock', N'1-.al ser un traspaso, primero validar que solo se pueda traspasar inventario por en stock por purchase y no por proyecto.
2-.Cuando es una salida de Inventario Notificar al Manager para quien va esa orden de salida, entonces el Manager tendra que aprobar de la misma Manera vacations, el ususario vera que esa salida esta pendiente de aprovacion hasta ser aprobada la salida entonces se validara que se restara la cantidad al Whareouse', N'todo', N'normal', N'8h', 21, 27, N'2026-07-04 23:27:06.0000000', N'2026-07-04 23:49:52.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (222, N'Habilitar Excel para descargar Inventario Filtrado', N'Dado que se estaran realizando Auditorias por zonas y cada cierta fecha, es necesario tener varios filtros en el inventario y sobre todo por wharehouses para poder realizar Inventario(Auditorias)', N'closed', N'normal', N'12h', 21, 27, N'2026-07-04 23:32:13.0000000', N'2026-07-08 04:18:55.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (223, N'Autopopular Warehouse ', N'Determinar el usuario con Role "Inventory" a que Zona pertenece y si no esManager o Admin solo podra ver los inventarios de su Pais. ', N'closed', N'normal', N'8h', 21, 27, N'2026-07-04 23:39:23.0000000', N'2026-07-08 04:04:20.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (224, N'Validar colores en tema blanco en todas las sesiones de Inventario', N'validar que los colores no queden tan claros en las letras incluso en controles', N'closed', N'normal', N'8h', 21, 27, N'2026-07-05 00:00:57.0000000', N'2026-07-07 05:26:50.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (225, N'Habilitar que se pueda subir imagenes a Products ', N'Ademas de los campos que ya existen tener un campo para agregar 1 o hasta 3 imagenes y habilitar varias extenciones ', N'closed', N'normal', N'4h', 21, 27, N'2026-07-05 00:11:00.0000000', N'2026-07-08 00:39:52.0000000', N'improvement', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (226, N'Onboarding - Ivanska Liz Hernandez Diaz', N'Computer configuration', N'closed', N'high', N'1h', 49, 54, N'2026-07-06 14:53:28.0000000', N'2026-07-07 22:30:21.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (227, N'Edit vacations, sick and PTO', N'So users can edit their vacation request or eliminate them', N'todo', N'normal', N'1w', 49, 21, N'2026-07-06 18:43:36.0000000', N'2026-07-06 18:43:36.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (228, N'New Employee - Oscar', N'Start date 7/11', N'todo', N'normal', N'1w', 49, 55, N'2026-07-07 19:55:08.0000000', N'2026-07-07 19:55:08.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (229, N'Two Sofia Rodriguez on dropdown', N'Keep Sofía Rodríguez', N'todo', N'normal', N'24h', 49, 21, N'2026-07-07 21:04:38.0000000', N'2026-07-07 21:04:38.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (230, N'Verificar Distribution List por Zonas y crear una global', N'de todos los empleados que estan activos que esten dentro de la distribution list segun el area 
', N'closed', N'normal', N'4h', 21, 54, N'2026-07-07 22:46:47.0000000', N'2026-07-16 16:46:14.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (231, N'verificar subscripcion y agregar a las licencias primefire.do', N'esta es una subscripcion que esta con una pagina de dominmicana ', N'todo', N'normal', N'4h', 21, 54, N'2026-07-07 23:02:07.0000000', N'2026-07-07 23:02:07.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (232, N'Mejora de statuses en Tickets', N'mejorar con tags los statuses en los tickets', N'closed', N'medium', N'48h', 21, 27, N'2026-07-08 00:59:37.0000000', N'2026-07-08 04:17:11.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (233, N'Validar que se pueda editar Permiso, Vacacion, o enfermedad antes de ser aprobada', N'Validar que se pueda editar Permiso, Vacacion, o enfermedad antes de ser aprobada', N'closed', N'normal', N'4h', 21, 27, N'2026-07-08 01:13:15.0000000', N'2026-07-08 05:22:15.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (234, N'Ir a la aplicación desde la URL corta ', N'Cambiar la URL de azure (legacy) à la url corta ', N'closed', N'normal', N'4h', 21, 27, N'2026-07-09 00:33:23.0000000', N'2026-07-09 01:28:17.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (240, N'Configure Sofia computer to the printer', N'Configure Sofia computer to the printer', N'todo', N'normal', N'4h', 49, 21, N'2026-07-14 13:09:08.0000000', N'2026-07-14 13:09:08.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (241, N'Pruebas Inventory', N'de los ultimos cambios que realizo Juan realizar las pruebas manuales y agregarlas al archivo
', N'todo', N'normal', N'8h', 21, 54, N'2026-07-16 01:24:44.0000000', N'2026-07-16 01:24:44.0000000', N'request', NULL)
INSERT [dbo].[tickets] ([ticket_id], [title], [description], [status], [priority], [sla], [created_by], [assigned_to], [created_at], [updated_at], [ticket_type], [in_progress_at]) VALUES (242, N'Adobe Support', N'asistencia con adobe extender licencia', N'todo', N'normal', N'1h', 46, 21, N'2026-07-20 14:57:23.0000000', N'2026-07-20 14:57:23.0000000', N'request', NULL)

SET IDENTITY_INSERT [dbo].[tickets] OFF
GO


-- Data for ticket_messages (52 records)
SET IDENTITY_INSERT [dbo].[ticket_messages] ON
GO

INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (1, 16, 21, N'Ok Willian reviso la compra de la licencia', '2025-12-02 17:22:05', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (2, 20, 21, N'Se mando correo y se esta validando con el equipo de MepCAD', '2025-12-09 17:56:09', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (5, 23, 21, N'test', '2025-12-11 02:28:30', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (6, 27, 21, N'adjunto imagen de los improvmens', '2025-12-15 23:19:27', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (7, 63, 21, N'Se borraron algunos archivos duplicados', '2025-12-19 02:46:53', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (8, 26, 21, N'Se configuró nueva PC para Willian y Joskayra con los programas de Cinstrucciom', '2025-12-19 02:48:52', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (9, 61, 21, N'Se realizó el inventario de Computadora y de la laptop', '2025-12-20 18:02:59', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (10, 51, 21, N'Inventario a su maquina', '2025-12-20 18:16:55', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (11, 39, 21, N'Se realizó inventario a la laptop', '2025-12-20 18:32:43', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (12, 49, 21, N'Se realizó inventario e instalación de licencia', '2025-12-20 18:33:52', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (13, 28, 21, N'Inventario Realizado', '2025-12-22 14:23:19', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (14, 58, 21, N'Inventario Realizado', '2025-12-22 14:23:49', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (16, 76, 21, N'Kevin Necesito una aprovacion de parte de Elizaud', '2025-12-30 17:20:11', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (17, 76, 21, N'imagen', '2025-12-30 17:20:49', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (18, 23, 27, N'test', '2026-01-05 23:44:26', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (19, 77, 27, N'test', '2026-01-08 03:12:24', '2026-01-08 03:25:58', '2026-01-08 03:25:58')
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (20, 81, 21, N'listo concedido Kevin, saludos', '2026-01-08 13:52:26', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (21, 78, 21, N'ya subi la cadena de conexio', '2026-01-10 16:22:30', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (22, 78, 21, N'foto hny', '2026-01-10 16:23:12', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (23, 83, 21, N'Atacho documento', '2026-01-15 00:20:13', '2026-01-15 00:20:23', '2026-01-15 00:20:23')
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (24, 84, 21, N'Atacho documento', '2026-01-15 00:23:19', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (25, 85, 21, N'Te adjunto el documento', '2026-01-15 00:27:29', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (26, 42, 21, N'Israel tiene Tablet', '2026-01-20 13:11:17', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (27, 35, 21, N'Elionetzi tiene tablet', '2026-01-20 13:11:58', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (28, 88, 21, N'Ya quedó saludos', '2026-01-23 13:54:13', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (29, 53, 21, N'Luis usa teams desde su celular personal', '2026-01-29 20:30:33', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (30, 104, 21, N'Buen dia Wilnelia,
Perfecto voy a crear el usuario en m365 y su firma. Para el lunes continuar con la instalación de los programas.
Por otra parte va a usar una laptop nueva o una de alguien mas? Quedo atento,m saludos', '2026-03-04 14:23:51', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (31, 104, 44, N'Tengo que confirmar con Alberto, pero entiendo que se le tendra que comprar una computadora nueva.', '2026-03-04 14:26:24', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (32, 104, 44, N'Ok, para su firma el telefono de la oficina es 787-630-6000 y su celular es (787)975-9127.', '2026-03-04 14:29:09', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (33, 104, 21, N'Perfecto voy avanzando en eso, si es computadora nueva voy a tomar en cuenta que también se necesitara una licencia de Windows 11 Pro, adicional de Office crees que necesite algun otro programa especifico?', '2026-03-04 14:31:28', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (34, 104, 44, N'Saludos Jonathan, Alberto está en el proceso de hacer la compra de la computadora para la nueva empleada. Entiendo que ella necesitara una licencia para los programas de Microsoft Office, si eventualmente requiere otros programas te dejo saber. Le voy a dar accesso al Chat GPT. Tambien quería dejarte saber que tenemos a Rolando Rivera y su email es rrivera@primefire.us, así que el de Rosa M. Rivera deberia ser rmrivera@primefire.us. Quedo atenta a cualquier duda o pregunta. Gracias.', '2026-03-05 18:43:07', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (35, 104, 21, N'Ya quedo listo solo faltara la licencia de Windows 11 pro para poder ingresar a Rosa a la red de prime', '2026-03-06 01:22:03', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (36, 104, 21, N'Ya quedo listo solo faltara la licencia de Windows 11 pro para poder ingresar a Rosa a la red de prime', '2026-03-06 01:22:04', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (37, 104, 21, N'Ya quedo listo solo faltara la licencia de Windows 11 pro para poder ingresar a Rosa a la red de prime', '2026-03-06 01:22:04', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (38, 104, 21, N'Ya quedo listo solo faltara la licencia de Windows 11 pro para poder ingresar a Rosa a la red de prime', '2026-03-06 01:22:04', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (40, 102, 27, N'result', '2026-03-09 02:47:45', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (41, 107, 21, N'mostrar names no ids', '2026-03-13 00:56:20', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (42, 125, 21, N'imagen ejemplo del dashboard', '2026-04-03 07:10:38', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (43, 128, 21, N'The versión that we have is 2021 desktop, after that the versión is only web, wich kind of issues are you experimented', '2026-04-07 17:00:19', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (44, 129, 21, N'img absence', '2026-04-09 00:32:28', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (45, 130, 21, N'add screenshot', '2026-04-09 00:35:53', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (46, 130, 27, N'Ahora no se permite solapamientos o inconsistencias en los nuevos', '2026-04-12 23:23:24', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (47, 132, 21, N'boton + solo filtrar modulos diferentes a los que ya estan agregados y el boton create solo estara habilitado para el admin', '2026-04-18 16:57:27', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (48, 128, 21, N'De este voy a comprar la versión 21.5 y la instalo a mediados de mayo, Saludos', '2026-05-01 17:46:38', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (49, 147, 21, N'Usuarios eliminados de M365', '2026-05-07 00:38:37', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (50, 166, 21, N'Ok se revisa a la brevedad', '2026-05-28 00:59:16', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (51, 179, 21, N'Mario agrega el anydesk del archivo employees', '2026-06-17 00:01:45', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (52, 189, 21, N'agregue el organigrama', '2026-06-17 14:14:06', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (53, 209, 21, N'Campo min stock', '2026-06-27 21:14:28', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (54, 211, 21, N'Add search partNumber - Descripcin Product', '2026-06-27 21:17:41', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (55, 224, 21, N'ejemplos', '2026-07-05 00:01:34', NULL, NULL)
INSERT [dbo].[ticket_messages] ([ticket_message_id], [ticket_id], [user_id], [message_txt], [created_at], [updated_at], [edited_at]) VALUES (56, 224, 21, N'otro ejemplo', '2026-07-05 00:14:30', NULL, NULL)

SET IDENTITY_INSERT [dbo].[ticket_messages] OFF
GO


-- Data for ticket_attachments (16 records)
SET IDENTITY_INSERT [dbo].[ticket_attachments] ON
GO

INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (4, 23, 5, N'angular.png', N'image/png', N'tickets/23/c298fa41042247a1b4bfaa9a53f1492a.png', '2025-12-11 02:28:31')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (5, 27, 6, N'VacationsImproves.png', N'image/png', N'tickets/27/0d56d010084d4dd78de4e732c3d4bccd.png', '2025-12-15 23:19:29')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (6, 76, 17, N'sumas.jpg', N'image/jpeg', N'tickets/76/f49e6b762cac49f5ad4548465caf0131.jpg', '2025-12-30 17:20:50')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (7, 77, 19, N'nfpa-logo-1.png', N'image/png', N'D:/home/uploads/tickets/77/995695a047bd4734bf9a65ceaeb25021.png', '2026-01-08 03:25:59')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (8, 102, 40, N'Untitled.png', N'image/png', N'/home/home/uploads/tickets/102/716543f9c6894ac7b1808cc2a547ea66.png', '2026-03-09 02:47:46')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (9, 107, 41, N'Screenshot 2026-03-12 185238.png', N'image/png', N'/home/home/uploads/tickets/107/c7c0f56614184af5b11c25375ac0baf9.png', '2026-03-13 00:56:21')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (10, 125, 42, N'dashboard.png', N'image/png', N'/home/home/uploads/tickets/125/4faed6e73f3d4a18ab3ea3fff8027bc5.png', '2026-04-03 07:10:40')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (11, 129, 44, N'Screenshot 2026-04-08 at 6.29.20 p.m..png', N'image/png', N'/home/home/uploads/tickets/129/965712871b3c484aad5e3616f67a26d8.png', '2026-04-09 00:32:29')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (12, 130, 45, N'Screenshot 2026-04-08 at 6.17.59 p.m..png', N'image/png', N'/home/home/uploads/tickets/130/b68edc951513402986e930b48983458e.png', '2026-04-09 00:35:55')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (13, 132, 47, N'Screenshot 2026-04-18 at 10.51.52 a.m..png', N'image/png', N'/home/home/uploads/tickets/132/62970ae4b64244d89c9db64c176b6334.png', '2026-04-18 16:57:28')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (14, 189, 52, N'Org.pdf', N'application/pdf', N'/home/home/uploads/tickets/189/5b53777dea6a49a4aa658bd0391961ac.pdf', '2026-06-17 14:14:08')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (15, 209, 53, N'IMG_0193.jpeg', N'image/jpeg', N'/home/home/uploads/tickets/209/bc32f2df9e904f85b94ff294d20a4ef8.jpeg', '2026-06-27 21:14:30')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (16, 211, 54, N'IMG_0192.jpeg', N'image/jpeg', N'/home/home/uploads/tickets/211/17690fac215641e78d96bad601062fc6.jpeg', '2026-06-27 21:17:42')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (17, 224, 55, N'Screenshot 2026-07-04 at 5.59.44 p.m..png', N'image/png', N'/home/home/uploads/tickets/224/5fafc2f18e104990bd455e9bc870b426.png', '2026-07-05 00:01:35')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (18, 224, 55, N'Screenshot 2026-07-04 at 5.56.43 p.m..png', N'image/png', N'/home/home/uploads/tickets/224/2221c42436a641a8a9328c0bd6881b13.png', '2026-07-05 00:01:35')
INSERT [dbo].[ticket_attachments] ([ticket_attachment_id], [ticket_id], [ticket_message_id], [file_name], [file_type], [file_path], [created_at]) VALUES (19, 224, 56, N'Screenshot 2026-07-04 at 6.13.04 p.m..png', N'image/png', N'/home/home/uploads/tickets/224/a5abfc41099e49438bbef0ce92dd0bbd.png', '2026-07-05 00:14:31')

SET IDENTITY_INSERT [dbo].[ticket_attachments] OFF
GO


-- Data for ticket_recurrence_config (2 records)
SET IDENTITY_INSERT [dbo].[ticket_recurrence_config] ON
GO

INSERT [dbo].[ticket_recurrence_config] ([config_id], [ticket_id], [recurrence_type], [next_occurrence], [parent_ticket_id], [is_active], [created_at]) VALUES (1, 117, N'DAILY', N'2026-03-28 02:36:11.6360260', NULL, 0, N'2026-03-27 02:36:11.6364170')
INSERT [dbo].[ticket_recurrence_config] ([config_id], [ticket_id], [recurrence_type], [next_occurrence], [parent_ticket_id], [is_active], [created_at]) VALUES (2, 232, N'DAILY', N'2026-07-09 00:59:37.0000000', NULL, 0, N'2026-07-08 00:59:37.0000000')

SET IDENTITY_INSERT [dbo].[ticket_recurrence_config] OFF
GO


-- Data for time_off_balances (14 records)
SET IDENTITY_INSERT [dbo].[time_off_balances] ON
GO

INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (1, 21, N'sick', 2026, N'0', N'0.50', N'0.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (2, 21, N'vacation', 2026, N'0', N'3.00', N'1.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (3, 2, N'vacation', 2026, N'0', N'0', N'8.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (4, 35, N'vacation', 2026, N'0', N'9.50', N'0.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (5, 11, N'vacation', 2026, N'0', N'0', N'17.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (6, 38, N'vacation', 2026, N'0', N'0', N'6.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (7, 18, N'vacation', 2026, N'0', N'0', N'9.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (8, 54, N'vacation', 2026, N'0', N'0', N'1.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (9, 49, N'sick', 2026, N'0', N'1.00', N'0.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (10, 25, N'personal', 2026, N'0', N'11.00', N'0.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (11, 29, N'sick', 2026, N'0', N'0', N'0.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (12, 24, N'vacation', 2026, N'0', N'0', N'4.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (13, 27, N'vacation', 2026, N'0', N'0', N'0.00', N'0')
INSERT [dbo].[time_off_balances] ([balance_id], [employee_id], [absence_type], [year], [entitled_days], [used_days], [pending_days], [carryover_days]) VALUES (14, 29, N'vacation', 2026, N'0', N'0', N'2.00', N'0')

SET IDENTITY_INSERT [dbo].[time_off_balances] OFF
GO


-- Data for time_off_requests (22 records)
SET IDENTITY_INSERT [dbo].[time_off_requests] ON
GO

INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (1, 21, N'sick', N'approved', N'half_day', N'2026-02-12', N'2026-02-12', NULL, NULL, NULL, N'0.50', N'I feel sick ', 21, N'2026-02-19 15:58:01', NULL, N'2026-02-12 21:01:46', N'2026-02-19 15:58:01')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (2, 21, N'vacation', N'approved', N'full_day', N'2026-02-26', N'2026-02-27', NULL, NULL, NULL, N'2.00', N'Pido este dia de vacaciones por que necesito salir ', 21, N'2026-02-19 16:12:25', NULL, N'2026-02-19 16:11:29', N'2026-02-19 16:12:25')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (3, 21, N'vacation', N'approved', N'full_day', N'2026-03-16', N'2026-03-16', NULL, NULL, NULL, N'1.00', N'That day is holliday in mexico', 49, N'2026-03-12 14:48:59', NULL, N'2026-03-12 14:45:10', N'2026-03-12 14:48:59')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (4, 21, N'vacation', N'pending', N'full_day', N'2026-03-27', N'2026-03-27', NULL, NULL, NULL, N'1.00', N'i have a visit', NULL, NULL, NULL, N'2026-03-26 01:05:14', N'2026-03-26 01:05:14')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (5, 2, N'vacation', N'pending', N'full_day', N'2026-04-09', N'2026-04-16', NULL, NULL, NULL, N'8.00', N'Vacation', NULL, NULL, NULL, N'2026-04-07 11:36:46', N'2026-04-07 11:36:46')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (6, 35, N'vacation', N'rejected', N'half_day', N'2026-04-23', N'2026-04-24', NULL, NULL, NULL, N'1.00', N'Vacation', 49, N'2026-04-07 11:38:59', N'Wrong entry.', N'2026-04-07 11:37:53', N'2026-04-07 11:38:59')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (7, 35, N'vacation', N'approved', N'half_day', N'2026-04-23', N'2026-04-23', NULL, NULL, NULL, N'0.50', N'Vacation', 49, N'2026-04-07 18:54:45', NULL, N'2026-04-07 11:39:28', N'2026-04-07 18:54:45')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (8, 35, N'vacation', N'approved', N'full_day', N'2026-04-24', N'2026-04-24', NULL, NULL, NULL, N'1.00', N'Vacation', 49, N'2026-04-07 18:54:47', NULL, N'2026-04-07 11:39:45', N'2026-04-07 18:54:47')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (9, 11, N'vacation', N'pending', N'full_day', N'2026-11-25', N'2026-12-11', NULL, NULL, NULL, N'17.00', N'Vacation', NULL, NULL, NULL, N'2026-04-07 11:41:53', N'2026-04-07 11:41:53')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (10, 38, N'vacation', N'pending', N'full_day', N'2026-04-13', N'2026-04-13', NULL, NULL, NULL, N'1.00', N'Vacation', NULL, NULL, NULL, N'2026-04-07 11:42:25', N'2026-04-07 11:42:25')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (11, 18, N'vacation', N'pending', N'full_day', N'2026-07-09', N'2026-07-17', NULL, NULL, NULL, N'9.00', N'VACATION ', NULL, NULL, NULL, N'2026-04-28 18:42:24', N'2026-04-28 18:42:24')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (12, 54, N'vacation', N'pending', N'full_day', N'2026-07-03', N'2026-07-03', NULL, NULL, NULL, N'1.00', N'Día para viajar y poder presentar un examen el sábado ', NULL, NULL, NULL, N'2026-07-03 06:30:42', N'2026-07-03 06:30:42')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (13, 49, N'sick', N'approved', N'full_day', N'2026-07-06', N'2026-07-06', NULL, NULL, NULL, N'1.00', N'Medical Appointment', 21, N'2026-07-03 17:47:54', NULL, N'2026-07-03 17:21:48', N'2026-07-03 17:47:54')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (14, 35, N'vacation', N'approved', N'full_day', N'2026-08-12', N'2026-08-19', NULL, NULL, NULL, N'8.00', NULL, 18, N'2026-07-03 18:17:04', NULL, N'2026-07-03 18:13:40', N'2026-07-03 18:17:04')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (15, 25, N'personal', N'approved', N'full_day', N'2026-07-27', N'2026-08-06', NULL, NULL, NULL, N'11.00', NULL, 49, N'2026-07-03 20:13:18', NULL, N'2026-07-03 20:08:06', N'2026-07-03 20:13:18')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (16, 29, N'sick', N'cancelled', N'full_day', N'2026-07-14', N'2026-07-14', NULL, NULL, NULL, N'1.00', N'Doctors appointment 
', NULL, NULL, NULL, N'2026-07-03 20:34:40', N'2026-07-20 12:16:51')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (17, 38, N'vacation', N'pending', N'full_day', N'2026-07-24', N'2026-07-28', NULL, NULL, NULL, N'5.00', NULL, NULL, NULL, NULL, N'2026-07-06 12:18:37', N'2026-07-06 12:18:37')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (18, 24, N'vacation', N'pending', N'full_day', N'2026-07-28', N'2026-07-31', NULL, NULL, NULL, N'4.00', N'Vacaciones ', NULL, NULL, NULL, N'2026-07-06 17:16:56', N'2026-07-06 17:16:56')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (19, 27, N'vacation', N'cancelled', N'full_day', N'2026-07-29', N'2026-07-29', NULL, NULL, NULL, N'1.00', NULL, NULL, NULL, NULL, N'2026-07-08 01:10:41', N'2026-07-08 05:02:17')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (20, 27, N'vacation', N'cancelled', N'full_day', N'2026-07-29', N'2026-07-31', NULL, NULL, NULL, N'3.00', NULL, NULL, NULL, NULL, N'2026-07-08 05:02:40', N'2026-07-08 05:17:50')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (21, 27, N'vacation', N'cancelled', N'full_day', N'2026-07-22', N'2026-07-24', NULL, NULL, NULL, N'3.00', N'test', NULL, NULL, NULL, N'2026-07-08 05:18:14', N'2026-07-08 05:33:14')
INSERT [dbo].[time_off_requests] ([request_id], [employee_id], [absence_type], [status], [time_unit], [start_date], [end_date], [start_time], [end_time], [total_hours], [total_days], [reason], [reviewed_by], [reviewed_at], [review_notes], [created_at], [updated_at]) VALUES (22, 29, N'vacation', N'pending', N'full_day', N'2026-07-21', N'2026-07-22', NULL, NULL, NULL, N'2.00', NULL, NULL, NULL, NULL, N'2026-07-20 12:16:08', N'2026-07-20 12:16:08')

SET IDENTITY_INSERT [dbo].[time_off_requests] OFF
GO


-- Data for time_sheet_location_snapshots (8 records)
SET IDENTITY_INSERT [dbo].[time_sheet_location_snapshots] ON
GO

INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (1, 21, 1, N'200.68.164.16:9945', N'25.72012410070058', N'-100.52835521338724', N'10.507418291305687', NULL, NULL, NULL, N'America/Monterrey', NULL, N'2026-03-12 14:50:55')
INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (2, 21, 1, N'201.172.175.223:57914', N'25.769168838556393', N'-100.45509983015337', N'12.757271574563367', NULL, NULL, NULL, N'America/Monterrey', NULL, N'2026-03-13 00:22:48')
INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (3, 49, 1, N'173.211.173.139:64306', N'18.317721496001777', N'-66.09618346379386', N'129', NULL, NULL, NULL, N'America/New_York', NULL, N'2026-03-17 11:42:49')
INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (4, 21, 1, N'201.172.175.223:53831', N'25.76923139460576', N'-100.45510769569442', N'7.973458517303936', NULL, NULL, NULL, N'America/Monterrey', NULL, N'2026-03-26 01:15:26')
INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (5, 21, 1, N'201.172.175.223:53831', N'25.76923139460576', N'-100.45510769569442', N'7.973458517303936', NULL, NULL, NULL, N'America/Monterrey', NULL, N'2026-03-26 01:17:54')
INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (6, 21, 1, N'200.68.165.37:6030', N'25.719791675302382', N'-100.53229219448839', N'10.435810122786505', NULL, NULL, NULL, N'America/Monterrey', NULL, N'2026-04-28 18:44:12')
INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (7, 54, 574, N'189.159.71.86:55561', N'25.67353073512337', N'-100.47041041682644', N'120', NULL, NULL, NULL, N'America/Mexico_City', NULL, N'2026-06-22 14:53:39')
INSERT [dbo].[time_sheet_location_snapshots] ([snapshot_id], [employee_id], [customer_id], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [timezone], [location_raw], [captured_at]) VALUES (8, 54, 574, N'189.159.71.86:55561', N'25.67350471855975', N'-100.47042320494873', N'115', NULL, NULL, NULL, N'America/Mexico_City', NULL, N'2026-06-22 14:54:07')

SET IDENTITY_INSERT [dbo].[time_sheet_location_snapshots] OFF
GO


-- Data for time_sheet_punches (5 records)
SET IDENTITY_INSERT [dbo].[time_sheet_punches] ON
GO

INSERT [dbo].[time_sheet_punches] ([punch_id], [employee_id], [customer_id], [clock_in_at], [clock_out_at], [timezone], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [location_raw], [worked_minutes], [status], [note], [approved_by], [approved_at], [created_at], [updated_at]) VALUES (1, 21, 1, N'2026-03-12 14:50:56', N'2026-03-13 00:22:48', N'America/Monterrey', NULL, N'25.769168838556393', N'-100.45509983015337', N'12.757271574563367', NULL, NULL, NULL, NULL, 571, N'closed', NULL, NULL, NULL, N'2026-03-12 14:50:56', N'2026-03-13 00:22:48')
INSERT [dbo].[time_sheet_punches] ([punch_id], [employee_id], [customer_id], [clock_in_at], [clock_out_at], [timezone], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [location_raw], [worked_minutes], [status], [note], [approved_by], [approved_at], [created_at], [updated_at]) VALUES (2, 49, 1, N'2026-03-17 11:42:50', N'2026-03-18 12:36:15', N'America/New_York', NULL, N'18.317721496001777', N'-66.09618346379386', N'129', NULL, NULL, NULL, NULL, 1493, N'rejected', NULL, 49, N'2026-03-18 12:36:59', N'2026-03-17 11:42:50', N'2026-03-18 12:36:59')
INSERT [dbo].[time_sheet_punches] ([punch_id], [employee_id], [customer_id], [clock_in_at], [clock_out_at], [timezone], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [location_raw], [worked_minutes], [status], [note], [approved_by], [approved_at], [created_at], [updated_at]) VALUES (3, 21, 1, N'2026-03-26 01:15:27', N'2026-03-26 01:17:54', N'America/Monterrey', NULL, N'25.76923139460576', N'-100.45510769569442', N'7.973458517303936', NULL, NULL, NULL, NULL, 2, N'closed', NULL, NULL, NULL, N'2026-03-26 01:15:27', N'2026-03-26 01:17:54')
INSERT [dbo].[time_sheet_punches] ([punch_id], [employee_id], [customer_id], [clock_in_at], [clock_out_at], [timezone], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [location_raw], [worked_minutes], [status], [note], [approved_by], [approved_at], [created_at], [updated_at]) VALUES (4, 21, 1, N'2026-04-28 18:44:13', N'2026-05-26 00:52:15', N'America/Mexico_City', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 39248, N'closed', NULL, NULL, NULL, N'2026-04-28 18:44:13', N'2026-05-26 00:52:15')
INSERT [dbo].[time_sheet_punches] ([punch_id], [employee_id], [customer_id], [clock_in_at], [clock_out_at], [timezone], [ip_address], [latitude], [longitude], [gps_accuracy], [city], [region], [country], [location_raw], [worked_minutes], [status], [note], [approved_by], [approved_at], [created_at], [updated_at]) VALUES (5, 54, 574, N'2026-06-22 14:53:40', N'2026-06-22 14:54:08', N'America/Mexico_City', NULL, N'25.67350471855975', N'-100.47042320494873', N'115', NULL, NULL, NULL, NULL, 0, N'closed', NULL, NULL, NULL, N'2026-06-22 14:53:40', N'2026-06-22 14:54:08')

SET IDENTITY_INSERT [dbo].[time_sheet_punches] OFF
GO


-- Data for time_sheet_settings (1 records)
SET IDENTITY_INSERT [dbo].[time_sheet_settings] ON
GO

INSERT [dbo].[time_sheet_settings] ([setting_id], [overtime_daily_hours], [overtime_weekly_hours], [round_to_minutes], [is_active], [created_at], [updated_at], [max_overtime_daily_hours]) VALUES (1, N'8.00', N'40.00', NULL, 1, N'2026-03-05 02:52:38', N'2026-03-05 02:52:38', N'8.00')

SET IDENTITY_INSERT [dbo].[time_sheet_settings] OFF
GO


-- =============================================
-- FOREIGN KEYS
-- =============================================

ALTER TABLE [dbo].[addresses] WITH CHECK ADD CONSTRAINT [fk_addresses_countries]
FOREIGN KEY([country_id])
REFERENCES [dbo].[countries] ([country_id])
GO
ALTER TABLE [dbo].[addresses] CHECK CONSTRAINT [fk_addresses_countries]
GO

ALTER TABLE [dbo].[customer_alternate_contacts] WITH CHECK ADD CONSTRAINT [fk_customer_alternate_contacts_customer_id_customers]
FOREIGN KEY([customer_id])
REFERENCES [dbo].[customers] ([customer_id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[customer_alternate_contacts] CHECK CONSTRAINT [fk_customer_alternate_contacts_customer_id_customers]
GO

ALTER TABLE [dbo].[customer_attachments] WITH CHECK ADD CONSTRAINT [fk_customer_attachments_customer_id_customers]
FOREIGN KEY([customer_id])
REFERENCES [dbo].[customers] ([customer_id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[customer_attachments] CHECK CONSTRAINT [fk_customer_attachments_customer_id_customers]
GO

ALTER TABLE [dbo].[customer_attachments] WITH CHECK ADD CONSTRAINT [fk_customer_attachments_created_by_employees]
FOREIGN KEY([created_by])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[customer_attachments] CHECK CONSTRAINT [fk_customer_attachments_created_by_employees]
GO

ALTER TABLE [dbo].[customer_notes] WITH CHECK ADD CONSTRAINT [fk_customer_notes_customer_id_customers]
FOREIGN KEY([customer_id])
REFERENCES [dbo].[customers] ([customer_id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[customer_notes] CHECK CONSTRAINT [fk_customer_notes_customer_id_customers]
GO

ALTER TABLE [dbo].[customer_notes] WITH CHECK ADD CONSTRAINT [fk_customer_notes_created_by_employees]
FOREIGN KEY([created_by])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[customer_notes] CHECK CONSTRAINT [fk_customer_notes_created_by_employees]
GO

ALTER TABLE [dbo].[customers] WITH CHECK ADD CONSTRAINT [fk_customers_primary_address_id_addresses]
FOREIGN KEY([primary_address_id])
REFERENCES [dbo].[addresses] ([address_id])
GO
ALTER TABLE [dbo].[customers] CHECK CONSTRAINT [fk_customers_primary_address_id_addresses]
GO

ALTER TABLE [dbo].[customers] WITH CHECK ADD CONSTRAINT [fk_customers_created_by_employees]
FOREIGN KEY([created_by])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[customers] CHECK CONSTRAINT [fk_customers_created_by_employees]
GO

ALTER TABLE [dbo].[employee_roles] WITH CHECK ADD CONSTRAINT [fk_employee_r_emplo_247d636f]
FOREIGN KEY([employee_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[employee_roles] CHECK CONSTRAINT [fk_employee_r_emplo_247d636f]
GO

ALTER TABLE [dbo].[employee_roles] WITH CHECK ADD CONSTRAINT [fk_employee_r_role_i_257187a8]
FOREIGN KEY([role_id])
REFERENCES [dbo].[roles] ([role_id])
GO
ALTER TABLE [dbo].[employee_roles] CHECK CONSTRAINT [fk_employee_r_role_i_257187a8]
GO

ALTER TABLE [dbo].[employees] WITH CHECK ADD CONSTRAINT [fk_employees_count_1dd065e0]
FOREIGN KEY([country_id])
REFERENCES [dbo].[countries] ([country_id])
GO
ALTER TABLE [dbo].[employees] CHECK CONSTRAINT [fk_employees_count_1dd065e0]
GO

ALTER TABLE [dbo].[employees] WITH CHECK ADD CONSTRAINT [fk_employees_manager_employee]
FOREIGN KEY([manager_employee_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[employees] CHECK CONSTRAINT [fk_employees_manager_employee]
GO

ALTER TABLE [dbo].[external_users] WITH CHECK ADD CONSTRAINT [fk_external_u_tenan_08012052]
FOREIGN KEY([tenant_id])
REFERENCES [dbo].[tenants] ([tenant_id])
GO
ALTER TABLE [dbo].[external_users] CHECK CONSTRAINT [fk_external_u_tenan_08012052]
GO

ALTER TABLE [dbo].[inventory_movement_approvals] WITH CHECK ADD CONSTRAINT [FK_inv_mov_approvals_product]
FOREIGN KEY([product_id])
REFERENCES [dbo].[products] ([id])
GO
ALTER TABLE [dbo].[inventory_movement_approvals] CHECK CONSTRAINT [FK_inv_mov_approvals_product]
GO

ALTER TABLE [dbo].[inventory_movement_approvals] WITH CHECK ADD CONSTRAINT [FK_inv_mov_approvals_warehouse]
FOREIGN KEY([warehouse_id])
REFERENCES [dbo].[warehouses] ([warehouse_id])
GO
ALTER TABLE [dbo].[inventory_movement_approvals] CHECK CONSTRAINT [FK_inv_mov_approvals_warehouse]
GO

ALTER TABLE [dbo].[inventory_movement_approvals] WITH CHECK ADD CONSTRAINT [FK_inv_mov_approvals_movement]
FOREIGN KEY([movement_id])
REFERENCES [dbo].[inventory_movements] ([movement_id])
GO
ALTER TABLE [dbo].[inventory_movement_approvals] CHECK CONSTRAINT [FK_inv_mov_approvals_movement]
GO

ALTER TABLE [dbo].[inventory_movements] WITH CHECK ADD CONSTRAINT [FK_inventory_movements_products]
FOREIGN KEY([product_id])
REFERENCES [dbo].[products] ([id])
GO
ALTER TABLE [dbo].[inventory_movements] CHECK CONSTRAINT [FK_inventory_movements_products]
GO

ALTER TABLE [dbo].[inventory_movements] WITH CHECK ADD CONSTRAINT [FK_inventory_movements_warehouses]
FOREIGN KEY([warehouse_id])
REFERENCES [dbo].[warehouses] ([warehouse_id])
GO
ALTER TABLE [dbo].[inventory_movements] CHECK CONSTRAINT [FK_inventory_movements_warehouses]
GO

ALTER TABLE [dbo].[jobs] WITH CHECK ADD CONSTRAINT [fk_jobs_countries]
FOREIGN KEY([country_id])
REFERENCES [dbo].[countries] ([country_id])
GO
ALTER TABLE [dbo].[jobs] CHECK CONSTRAINT [fk_jobs_countries]
GO

ALTER TABLE [dbo].[modules] WITH CHECK ADD CONSTRAINT [fk_modules_parent_m_19ffd4fc]
FOREIGN KEY([parent_module_id])
REFERENCES [dbo].[modules] ([module_id])
GO
ALTER TABLE [dbo].[modules] CHECK CONSTRAINT [fk_modules_parent_m_19ffd4fc]
GO

ALTER TABLE [dbo].[product_attachments] WITH CHECK ADD CONSTRAINT [FK_product_attachments_product]
FOREIGN KEY([product_id])
REFERENCES [dbo].[products] ([id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[product_attachments] CHECK CONSTRAINT [FK_product_attachments_product]
GO

ALTER TABLE [dbo].[product_attachments] WITH CHECK ADD CONSTRAINT [FK_product_attachments_employee]
FOREIGN KEY([created_by])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[product_attachments] CHECK CONSTRAINT [FK_product_attachments_employee]
GO

ALTER TABLE [dbo].[product_catalog] WITH CHECK ADD CONSTRAINT [FK_product_catalog_family]
FOREIGN KEY([family_id])
REFERENCES [dbo].[product_families] ([id])
GO
ALTER TABLE [dbo].[product_catalog] CHECK CONSTRAINT [FK_product_catalog_family]
GO

ALTER TABLE [dbo].[product_catalog] WITH CHECK ADD CONSTRAINT [FK_product_catalog_category]
FOREIGN KEY([category_id])
REFERENCES [dbo].[product_categories] ([id])
GO
ALTER TABLE [dbo].[product_catalog] CHECK CONSTRAINT [FK_product_catalog_category]
GO

ALTER TABLE [dbo].[product_categories] WITH CHECK ADD CONSTRAINT [FK_product_categories_family]
FOREIGN KEY([family_id])
REFERENCES [dbo].[product_families] ([id])
GO
ALTER TABLE [dbo].[product_categories] CHECK CONSTRAINT [FK_product_categories_family]
GO

ALTER TABLE [dbo].[product_specifications] WITH CHECK ADD CONSTRAINT [FK_product_specifications_product]
FOREIGN KEY([product_id])
REFERENCES [dbo].[product_catalog] ([id])
GO
ALTER TABLE [dbo].[product_specifications] CHECK CONSTRAINT [FK_product_specifications_product]
GO

ALTER TABLE [dbo].[products] WITH CHECK ADD CONSTRAINT [FK_products_product_families_family_id]
FOREIGN KEY([family_id])
REFERENCES [dbo].[product_families] ([id])
GO
ALTER TABLE [dbo].[products] CHECK CONSTRAINT [FK_products_product_families_family_id]
GO

ALTER TABLE [dbo].[products] WITH CHECK ADD CONSTRAINT [FK_products_product_categories_category_id]
FOREIGN KEY([category_id])
REFERENCES [dbo].[product_categories] ([id])
GO
ALTER TABLE [dbo].[products] CHECK CONSTRAINT [FK_products_product_categories_category_id]
GO

ALTER TABLE [dbo].[quotation_items] WITH CHECK ADD CONSTRAINT [fk_quotation_items_quotation]
FOREIGN KEY([quotation_id])
REFERENCES [dbo].[quotations] ([id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[quotation_items] CHECK CONSTRAINT [fk_quotation_items_quotation]
GO

ALTER TABLE [dbo].[quotation_items] WITH CHECK ADD CONSTRAINT [fk_quotation_items_product]
FOREIGN KEY([product_id])
REFERENCES [dbo].[products] ([id])
GO
ALTER TABLE [dbo].[quotation_items] CHECK CONSTRAINT [fk_quotation_items_product]
GO

ALTER TABLE [dbo].[quotations] WITH CHECK ADD CONSTRAINT [fk_quotations_customers]
FOREIGN KEY([customer_id])
REFERENCES [dbo].[customers] ([customer_id])
GO
ALTER TABLE [dbo].[quotations] CHECK CONSTRAINT [fk_quotations_customers]
GO

ALTER TABLE [dbo].[role_modules] WITH CHECK ADD CONSTRAINT [fk_role_modul_role_i_20acd28b]
FOREIGN KEY([role_id])
REFERENCES [dbo].[roles] ([role_id])
GO
ALTER TABLE [dbo].[role_modules] CHECK CONSTRAINT [fk_role_modul_role_i_20acd28b]
GO

ALTER TABLE [dbo].[role_modules] WITH CHECK ADD CONSTRAINT [fk_role_modul_modul_21a0f6c4]
FOREIGN KEY([module_id])
REFERENCES [dbo].[modules] ([module_id])
GO
ALTER TABLE [dbo].[role_modules] CHECK CONSTRAINT [fk_role_modul_modul_21a0f6c4]
GO

ALTER TABLE [dbo].[tenant_employees] WITH CHECK ADD CONSTRAINT [fk_tenant_emp_tenan_033c6b35]
FOREIGN KEY([tenant_id])
REFERENCES [dbo].[tenants] ([tenant_id])
GO
ALTER TABLE [dbo].[tenant_employees] CHECK CONSTRAINT [fk_tenant_emp_tenan_033c6b35]
GO

ALTER TABLE [dbo].[tenant_employees] WITH CHECK ADD CONSTRAINT [fk_tenant_emp_emplo_04308f6e]
FOREIGN KEY([employee_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[tenant_employees] CHECK CONSTRAINT [fk_tenant_emp_emplo_04308f6e]
GO

ALTER TABLE [dbo].[tenant_logos] WITH CHECK ADD CONSTRAINT [fk_tenant_log_tenan_0db9f9a8]
FOREIGN KEY([tenant_id])
REFERENCES [dbo].[tenants] ([tenant_id])
GO
ALTER TABLE [dbo].[tenant_logos] CHECK CONSTRAINT [fk_tenant_log_tenan_0db9f9a8]
GO

ALTER TABLE [dbo].[ticket_attachments] WITH CHECK ADD CONSTRAINT [fk_ticket_att_ticke_2fef161b]
FOREIGN KEY([ticket_id])
REFERENCES [dbo].[tickets] ([ticket_id])
GO
ALTER TABLE [dbo].[ticket_attachments] CHECK CONSTRAINT [fk_ticket_att_ticke_2fef161b]
GO

ALTER TABLE [dbo].[ticket_attachments] WITH CHECK ADD CONSTRAINT [fk_ticket_att_ticke_30e33a54]
FOREIGN KEY([ticket_message_id])
REFERENCES [dbo].[ticket_messages] ([ticket_message_id])
GO
ALTER TABLE [dbo].[ticket_attachments] CHECK CONSTRAINT [fk_ticket_att_ticke_30e33a54]
GO

ALTER TABLE [dbo].[ticket_messages] WITH CHECK ADD CONSTRAINT [fk_ticket_mes_ticke_2c1e8537]
FOREIGN KEY([ticket_id])
REFERENCES [dbo].[tickets] ([ticket_id])
GO
ALTER TABLE [dbo].[ticket_messages] CHECK CONSTRAINT [fk_ticket_mes_ticke_2c1e8537]
GO

ALTER TABLE [dbo].[ticket_messages] WITH CHECK ADD CONSTRAINT [fk_ticket_mes_user_i_2d12a970]
FOREIGN KEY([user_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[ticket_messages] CHECK CONSTRAINT [fk_ticket_mes_user_i_2d12a970]
GO

ALTER TABLE [dbo].[ticket_recurrence_config] WITH CHECK ADD CONSTRAINT [FK_ticket_recurrence_config_tickets]
FOREIGN KEY([ticket_id])
REFERENCES [dbo].[tickets] ([ticket_id])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[ticket_recurrence_config] CHECK CONSTRAINT [FK_ticket_recurrence_config_tickets]
GO

ALTER TABLE [dbo].[tickets] WITH CHECK ADD CONSTRAINT [fk_tickets_created_284df453]
FOREIGN KEY([created_by])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[tickets] CHECK CONSTRAINT [fk_tickets_created_284df453]
GO

ALTER TABLE [dbo].[tickets] WITH CHECK ADD CONSTRAINT [fk_tickets_assigne_2942188c]
FOREIGN KEY([assigned_to])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[tickets] CHECK CONSTRAINT [fk_tickets_assigne_2942188c]
GO

ALTER TABLE [dbo].[time_off_balances] WITH CHECK ADD CONSTRAINT [fk_time_off_balances_employee]
FOREIGN KEY([employee_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[time_off_balances] CHECK CONSTRAINT [fk_time_off_balances_employee]
GO

ALTER TABLE [dbo].[time_off_requests] WITH CHECK ADD CONSTRAINT [fk_time_off_requests_employee]
FOREIGN KEY([employee_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[time_off_requests] CHECK CONSTRAINT [fk_time_off_requests_employee]
GO

ALTER TABLE [dbo].[time_off_requests] WITH CHECK ADD CONSTRAINT [fk_time_off_requests_reviewed_by]
FOREIGN KEY([reviewed_by])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[time_off_requests] CHECK CONSTRAINT [fk_time_off_requests_reviewed_by]
GO

ALTER TABLE [dbo].[time_sheet_location_snapshots] WITH CHECK ADD CONSTRAINT [FK_TimeSheetLocationSnapshots_Employee]
FOREIGN KEY([employee_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[time_sheet_location_snapshots] CHECK CONSTRAINT [FK_TimeSheetLocationSnapshots_Employee]
GO

ALTER TABLE [dbo].[time_sheet_location_snapshots] WITH CHECK ADD CONSTRAINT [FK_TimeSheetLocationSnapshots_Customer]
FOREIGN KEY([customer_id])
REFERENCES [dbo].[customers] ([customer_id])
GO
ALTER TABLE [dbo].[time_sheet_location_snapshots] CHECK CONSTRAINT [FK_TimeSheetLocationSnapshots_Customer]
GO

ALTER TABLE [dbo].[time_sheet_punches] WITH CHECK ADD CONSTRAINT [FK_TimeSheetPunches_Employee]
FOREIGN KEY([employee_id])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[time_sheet_punches] CHECK CONSTRAINT [FK_TimeSheetPunches_Employee]
GO

ALTER TABLE [dbo].[time_sheet_punches] WITH CHECK ADD CONSTRAINT [FK_TimeSheetPunches_Customer]
FOREIGN KEY([customer_id])
REFERENCES [dbo].[customers] ([customer_id])
GO
ALTER TABLE [dbo].[time_sheet_punches] CHECK CONSTRAINT [FK_TimeSheetPunches_Customer]
GO

ALTER TABLE [dbo].[time_sheet_punches] WITH CHECK ADD CONSTRAINT [FK_TimeSheetPunches_ApprovedBy]
FOREIGN KEY([approved_by])
REFERENCES [dbo].[employees] ([employee_id])
GO
ALTER TABLE [dbo].[time_sheet_punches] CHECK CONSTRAINT [FK_TimeSheetPunches_ApprovedBy]
GO

ALTER TABLE [dbo].[warehouses] WITH CHECK ADD CONSTRAINT [FK_warehouses_warehouse_locations_location_id]
FOREIGN KEY([location_id])
REFERENCES [dbo].[warehouse_locations] ([warehouse_location_id])
GO
ALTER TABLE [dbo].[warehouses] CHECK CONSTRAINT [FK_warehouses_warehouse_locations_location_id]
GO


-- =============================================
-- BACKUP SUMMARY
-- =============================================
-- Backup Type: FULL
-- Total Tables: 43
-- Total Records: 2404
-- 
-- Data per table:
--   countries: 8 records
--   addresses: 474 records
--   employees: 54 records
--   customers: 587 records
--   customer_alternate_contacts: 1 records
--   customer_notes: 578 records
--   roles: 7 records
--   employee_roles: 79 records
--   tenants: 2 records
--   external_users: 2 records
--   hardware_inventory: 26 records
--   product_families: 7 records
--   product_categories: 9 records
--   products: 3 records
--   warehouse_locations: 2 records
--   warehouses: 4 records
--   inventory_movements: 5 records
--   inventory_movement_approvals: 2 records
--   licenses: 67 records
--   modules: 26 records
--   product_catalog: 8 records
--   product_specifications: 8 records
--   role_modules: 104 records
--   tenant_logos: 2 records
--   tickets: 219 records
--   ticket_messages: 52 records
--   ticket_attachments: 16 records
--   ticket_recurrence_config: 2 records
--   time_off_balances: 14 records
--   time_off_requests: 22 records
--   time_sheet_location_snapshots: 8 records
--   time_sheet_punches: 5 records
--   time_sheet_settings: 1 records
-- =============================================

PRINT 'Backup restored successfully!'
PRINT 'Total records inserted: 2404'
GO
