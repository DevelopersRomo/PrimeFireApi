import asyncio
import contextlib
import logging
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import or_
from sqlmodel import Session, select

from bd.connection import sync_engine as engine
from core.microsoft_graph import graph_client
from models.countries import Countries
from models.employees import Employees

logger = logging.getLogger(__name__)


def normalize_country_to_code(country_name: str) -> str | None:
    """Convert country names or codes to standard ISO 3166-1 alpha-2 codes."""
    if not country_name or not country_name.strip():
        return None

    country_name = country_name.strip().upper()

    # Direct mapping for common countries
    country_map = {
        # United States variations
        "UNITED STATES": "US",
        "USA": "US",
        "UNITED STATES OF AMERICA": "US",
        "US": "US",
        "AMERICA": "US",
        # Puerto Rico
        "PUERTO RICO": "PR",
        "PR": "PR",
        # Dominican Republic variations
        "REPÚBLICA DOMINICANA": "DO",
        "DOMINICAN REPUBLIC": "DO",
        "REPUBLICA DOMINICANA": "DO",
        "DO": "DO",
        # Mexico
        "MEXICO": "MX",
        "MÉXICO": "MX",
        "MX": "MX",
        # Add more countries as needed
        "CANADA": "CA",
        "SPAIN": "ES",
        "FRANCE": "FR",
        "GERMANY": "DE",
        "ITALY": "IT",
        "UNITED KINGDOM": "GB",
        "UK": "GB",
    }

    return country_map.get(country_name)


def get_or_create_country_id(db: Session, country_input: str) -> tuple[int | None, bool]:
    """
    Get CountryId for a country name/code, creating it if it doesn't exist.
    Always stores standardized ISO codes.
    Returns (CountryId, was_created) tuple.
    CountryId is None if country_input is None or empty.
    """
    if not country_input or not country_input.strip():
        return None, False

    # Normalize to standard ISO code
    country_code = normalize_country_to_code(country_input.strip())
    if not country_code:
        return None, False

    # Try to find existing country by code
    existing_country = db.exec(select(Countries).filter(Countries.name == country_code)).first()

    if existing_country:
        return existing_country.country_id, False

    # Create new country with ISO code
    new_country = Countries(name=country_code)
    db.add(new_country)
    db.commit()
    db.refresh(new_country)
    return new_country.country_id, True


def is_primefire_domain(email: str) -> bool:
    """
    Check if email belongs to PrimeFire domains
    Only checks the domain part (after @)
    Accepts domains like: primefire.us, primefire.do, sub.primefire.com, etc.
    """
    if not email:
        return False

    # Extract domain from email (part after @)
    domain = email.lower().split("@")[-1] if "@" in email else ""

    # Check if domain contains primefire as a separate segment
    # This avoids false positives like "notprimefire.com"
    domain_parts = domain.split(".")
    return any(part == "primefire" for part in domain_parts)


def get_country_id_from_domain(email: str) -> int | None:
    """
    LEGACY: Determine CountryId based on email domain
    Now we filter by PrimeFire domains and get country from Graph.
    """
    if not email:
        return None

    domain = email.lower().split("@")[-1] if "@" in email else ""

    if domain.endswith(".us"):
        return 1  # Puerto Rico
    if domain.endswith(".do"):
        return 2  # República Dominicana

    return None  # Skip other domains


def upsert_employee_from_microsoft_user(db: Session, ms_user: dict) -> Employees:
    """Create or update an employee in SQL from a Microsoft Graph user and return the SQL employee."""
    employee_data = graph_client.map_graph_user_to_employee(ms_user)

    graph_country = employee_data.pop("country", None)
    country_id, _ = get_or_create_country_id(db, graph_country) if graph_country else (None, False)
    employee_data["country_id"] = country_id
    employee_data["last_synced_at"] = datetime.now()  # noqa: DTZ005

    azure_oid = employee_data.get("azure_oid")
    email = employee_data.get("email")
    azure_upn = employee_data.get("azure_upn")

    existing = None
    if azure_oid:
        existing = db.exec(select(Employees).where(Employees.azure_oid == azure_oid)).first()

    if not existing and (email or azure_upn):
        existing = db.exec(
            select(Employees).where(
                or_(
                    Employees.email == email,  # type: ignore[arg-type]
                    Employees.azure_upn == azure_upn,  # type: ignore[arg-type]
                    Employees.email == azure_upn,  # type: ignore[arg-type]
                    Employees.azure_upn == email,  # type: ignore[arg-type]
                )
            )
        ).first()

    if existing:
        for key, value in employee_data.items():
            if value is not None:
                setattr(existing, key, value)
        db.commit()
        db.refresh(existing)
        return existing

    new_employee = Employees(**employee_data)
    db.add(new_employee)
    db.commit()
    db.refresh(new_employee)
    return new_employee


async def resolve_manager_employee_id(
    db: Session, manager_email: str | None = None, manager_name: str | None = None
) -> int | None:
    """Resolve manager to SQL EmployeeId, creating manager in SQL from Microsoft if needed."""
    manager_email = manager_email.strip() if isinstance(manager_email, str) else manager_email
    manager_name = manager_name.strip() if isinstance(manager_name, str) else manager_name

    if manager_email:
        sql_manager = db.exec(
            select(Employees).where(or_(Employees.email == manager_email, Employees.azure_upn == manager_email))  # type: ignore[arg-type]
        ).first()
        if sql_manager:
            return sql_manager.employee_id

        ms_manager: dict[str, Any] | None = await graph_client.get_user(manager_email)
        sql_manager = upsert_employee_from_microsoft_user(db, ms_manager)  # type: ignore[arg-type]
        return sql_manager.employee_id

    if manager_name:
        sql_manager = db.exec(select(Employees).where(Employees.display_name == manager_name)).first()
        if sql_manager:
            return sql_manager.employee_id

        ms_manager = await graph_client.find_user_by_display_name(manager_name)
        if not ms_manager:
            return None

        manager_identifier = ms_manager.get("id") or ms_manager.get("userPrincipalName") or ms_manager.get("mail")
        if not manager_identifier:
            return None

        ms_manager_full = await graph_client.get_user(manager_identifier)
        sql_manager = upsert_employee_from_microsoft_user(db, ms_manager_full)
        return sql_manager.EmployeeId

    return None


class EmployeeSyncScheduler:
    """Background task scheduler for Microsoft 365 employee synchronization."""

    def __init__(self) -> None:
        self.is_running = False
        self.last_sync: datetime | None = None
        self.sync_interval_hours = 24  # Sync every 24 hours by default
        self._task: asyncio.Task | None = None

    async def _process_ms_user(self, ms_user: dict, db: Session, stats: dict[str, int]) -> None:
        """Process a single Microsoft Graph user during sync."""
        try:  # noqa: PLW0717
            # Filter only PrimeFire domains
            email = ms_user.get("userPrincipalName") or ms_user.get("mail")
            if not email or not is_primefire_domain(email):
                # Debug: log skipped users
                logger.debug(f"Skipping user {email} - not PrimeFire domain")
                return  # Skip non-PrimeFire users

            stats["primefire_users"] += 1
            logger.debug(f"✅ Processing PrimeFire user: {email}")

            employee_data = graph_client.map_graph_user_to_employee(ms_user)

            # Resolve the mapped country without assigning it to the SQLAlchemy relationship.
            graph_country = employee_data.pop("country", None)
            country_id, country_created = (
                get_or_create_country_id(db, graph_country) if graph_country else (None, False)
            )

            if country_created:
                stats["countries_created"] += 1

            employee_data["last_synced_at"] = datetime.now()  # noqa: DTZ005
            employee_data["country_id"] = country_id

            employee_data["manager_employee_id"] = await resolve_manager_employee_id(
                db,
                manager_email=employee_data.get("manager_email"),
                manager_name=employee_data.get("manager"),
            )

            stats["processed"] += 1

            # Check if employee exists by azure_oid
            existing = db.exec(select(Employees).filter(Employees.azure_oid == employee_data["azure_oid"])).first()

            if existing:
                # Update existing employee
                for key, value in employee_data.items():
                    if value is not None:
                        setattr(existing, key, value)
                stats["updated"] += 1
            else:
                # Create new employee
                new_employee = Employees(**employee_data)
                db.add(new_employee)
                stats["created"] += 1

            db.commit()

        except Exception:
            stats["errors"] += 1

    async def sync_employees_from_microsoft(self) -> dict:
        """
        Sync all employees from Microsoft 365 to local database
        Returns sync statistics.
        """
        try:  # noqa: PLW0717
            logger.info("Starting automatic sync from Microsoft 365...")

            ms_users = await graph_client.get_all_users()

            stats: dict[str, int] = {
                "total_ms_users": len(ms_users),  # Total users from Microsoft Graph
                "primefire_users": 0,  # Users with PrimeFire domains
                "processed": 0,  # Successfully processed PrimeFire users
                "created": 0,
                "updated": 0,
                "errors": 0,
                "countries_created": 0,
            }
            sync_timestamp: datetime = datetime.now()  # noqa: DTZ005

            with Session(engine) as db:
                for ms_user in ms_users:
                    await self._process_ms_user(ms_user, db, stats)
            self.last_sync = datetime.now()  # noqa: DTZ005

            return {**stats, "timestamp": sync_timestamp}

        except Exception as e:
            logger.exception(f"❌ Failed to sync from Microsoft 365: {e}")
            raise

    async def _periodic_sync_loop(self) -> None:
        """Background loop that runs periodic syncs."""
        while self.is_running:
            try:
                # Check if it's time to sync
                should_sync = self.last_sync is None or datetime.now() - self.last_sync >= timedelta(  # noqa: DTZ005
                    hours=self.sync_interval_hours
                )

                if should_sync:
                    await self.sync_employees_from_microsoft()

                # Wait 1 hour before checking again
                await asyncio.sleep(3600)

            except asyncio.CancelledError:
                logger.info("Sync scheduler cancelled")
                break
            except Exception as e:
                logger.exception(f"❌ Error in sync loop: {e}")
                await asyncio.sleep(3600)  # Wait before retrying

    async def start_periodic_sync(self, interval_hours: int = 24) -> None:
        """
        Start periodic background sync.

        Args:
            interval_hours: Hours between syncs (default: 24)
        """
        if self.is_running:
            logger.warning("Sync scheduler already running")
            return

        self.sync_interval_hours = interval_hours
        self.is_running = True

        logger.info(f"Starting periodic sync (every {interval_hours} hours)")

        # Run initial sync immediately
        try:
            await self.sync_employees_from_microsoft()
        except Exception as e:
            logger.exception(f"❌ Initial sync failed: {e}")

        # Start background loop
        self._task = asyncio.create_task(self._periodic_sync_loop())

    async def stop_periodic_sync(self) -> None:
        """Stop periodic background sync."""
        if not self.is_running:
            return

        self.is_running = False

        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task

        logger.info("Sync scheduler stopped")

    async def sync_on_startup(self):
        """
        Run a one-time sync on application startup
        Recommended for simpler use cases.
        """
        logger.info("Running startup sync from Microsoft 365...")

        try:
            stats = await self.sync_employees_from_microsoft()
            logger.info(f"✅ Startup sync completed: {stats}")
            return stats
        except asyncio.CancelledError:
            logger.info("Startup sync cancelled")
            raise  # Re-raise to properly handle cancellation
        except Exception as e:
            logger.exception(f"❌ Startup sync failed: {e}")
            # Don't fail the application if sync fails
            return None


# Singleton instance
sync_scheduler = EmployeeSyncScheduler()
