from helpers.string_helpers import format_absence_type, format_hours_to_readable

"""Unified notification system with dynamic templates.

IMPORTANT: All notifications are sent using BOT_EMAIL as the sender (orchestrator).
Even though actions are performed by specific users, the email always comes from BOT_EMAIL.
This ensures consistent email delivery and proper authentication with Microsoft Graph API.

To disable notifications, set SEND_NOTIFICATIONS=false in environment variables.
"""

import logging

from sqlmodel import select

from bd.connection import SessionLocal
from core.config import settings
from models.tenants import TenantLogos, Tenants
from services.notifications.email_functions import parse_email_list, send_outlook_email
from services.notifications.schemas import (
    InventoryApprovalNotificationData,
    InventoryMovementNotificationData,
    NotificationField,
    NotificationResponse,
    TicketMessageNotificationData,
    TicketNotificationData,
    TimeOffNotificationData,
    TimeSheetNotificationData,
    UserApprovalNotificationData,
)
from services.notifications.teams_functions import send_teams_notification

logger = logging.getLogger(__name__)


def _should_send_notification() -> bool:
    """Check if notifications should be sent based on SEND_NOTIFICATIONS setting."""
    return getattr(settings, "SEND_NOTIFICATIONS", True)


def get_action_color(action_type: str) -> str:
    """Get color for action type."""
    colors = {
        "approved": "#28a745",
        "rejected": "#dc3545",
        "submitted": "#17a2b8",
        "pending": "#ffc107",
        "created": "#007bff",
        "commented": "#6f42c1",
        "user_approved": "#28a745",
    }
    return colors.get(action_type.lower(), "#6c757d")


def get_action_icon(action_type: str) -> str:
    """Get icon emoji for action type."""
    icons = {
        "approved": "✅",
        "rejected": "❌",
        "submitted": "📤",
        "pending": "⏳",
        "created": "🎫",
        "commented": "💬",
        "user_approved": "👤",
    }
    return icons.get(action_type.lower(), "📧")


def _normalize_app_url(url: str) -> str:
    cleaned = (url or "").strip()
    if not cleaned:
        return ""
    if cleaned.startswith("https://"):
        return cleaned
    if cleaned.startswith("http://"):
        return f"https://{cleaned[len('http://') :]}"
    return f"https://{cleaned}"


def _resolve_email_branding(tenant_key: str | None) -> dict:
    """Resolve branding for emails using tenant key from request context."""
    default_app_url = getattr(
        settings,
        "APP_URL",
        "https://primefireapp-cgh0c9ace5haapcc.mexicocentral-01.azurewebsites.net",
    )
    default_support_email = getattr(settings, "SUPPORT_EMAIL", "info@primefire.us")
    branding = {
        "app_name": "",
        "app_url": _normalize_app_url(default_app_url),
        "support_email": default_support_email,
        "include_support_section": bool(default_support_email),
    }

    if not tenant_key:
        return branding

    db = SessionLocal()
    try:  # noqa: PLW0717
        tenant = db.exec(select(Tenants).where(Tenants.db_connection_key == tenant_key)).first()
        if not tenant:
            return branding

        logo = db.exec(
            select(TenantLogos).where(TenantLogos.tenant_id == tenant.tenant_id).order_by(TenantLogos.logo_id.desc())
        ).first()
        if not logo:
            return branding

        app_name = (logo.title or "").strip() or branding["app_name"]
        app_url = _normalize_app_url((logo.url or "").strip()) or branding["app_url"]
        support_email = (logo.email or "").strip() or None

        return {
            "app_name": app_name,
            "app_url": app_url,
            "support_email": support_email,
            "include_support_section": bool(support_email),
        }
    finally:
        db.close()


def generate_notification_html(
    title: str,
    sub_title: str | None = None,
    action_type: str = "info",
    message_body: str = "",
    performed_by_name: str | None = None,
    performed_by_email: str | None = None,
    fields: list[NotificationField] | None = None,
    action_url: str | None = None,
    action_text: str = "View Details",
    support_email: str | None = None,
    app_url: str | None = None,
    app_name: str | None = None,
    include_support_section: bool = True,
    color_override: str | None = None,
    header_image_cid: str | None = None,
) -> str:
    """Generate unified HTML email template for notifications."""
    color = (color_override or "").strip() or get_action_color(action_type)
    icon = get_action_icon(action_type)

    if support_email is None:
        support_email = getattr(settings, "SUPPORT_EMAIL", "info@primefire.us")
    if app_url is None:
        app_url = getattr(
            settings,
            "APP_URL",
            "https://primefireapp-cgh0c9ace5haapcc.mexicocentral-01.azurewebsites.net",
        )
    app_url = _normalize_app_url(app_url)
    app_name = (app_name or "").strip()

    support_html = ""

    performed_by_html = ""
    if performed_by_name:
        performed_by_display = performed_by_name
        if performed_by_email:
            performed_by_display += f" ({performed_by_email})"
        performed_by_html = f"""
            <tr>
                <td style="padding: 0 40px 20px;">
                    <p style="margin: 0; color: #666; font-size: 14px;">
                        <strong>Performed by:</strong> {performed_by_display}
                    </p>
                </td>
            </tr>
        """

    fields_html = ""
    if fields:
        fields_rows = ""
        for field in fields:
            fields_rows += f"""
                <tr>
                    <td style="background-color: #F2F2F2; font-weight: bold; color: #333; width: 30%; padding: 8px; border-bottom: 1px solid #e1e1e1;">
                        {field.label}
                    </td>
                    <td style="background-color: #ffffff; color: #666; padding: 8px; border-bottom: 1px solid #e1e1e1;">
                        {field.value}
                    </td>
                </tr>
            """

        fields_html = f"""
            <tr>
                <td style="padding: 20px 40px;">
                    <table width="100%" cellpadding="0" cellspacing="0"
                           style="background-color: #f8f9fa; border: 1px solid #e1e1e1; border-radius: 6px;">
                        {fields_rows}
                    </table>
                </td>
            </tr>
        """

    action_button_html = ""
    if action_url:
        action_button_html = f"""
            <tr>
                <td style="padding: 30px 40px; text-align: center;">
                    <a href="{action_url}"
                       target="_blank"
                       style="display: inline-block; padding: 12px 30px; background-color: #000000;
                              color: #ffffff; text-decoration: none; border-radius: 4px; font-size: 14px; font-weight: bold;">
                        {action_text}
                    </a>
                </td>
            </tr>
        """

    html = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <!--[if mso]>
    <style type="text/css">
        body, table, td {{font-family: Arial, sans-serif !important;}}
    </style>
    <![endif]-->
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f4; font-family: Arial, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f4;">
        <tr>
            <td align="center" style="padding: 40px 0;">
                <table width="600" cellpadding="0" cellspacing="0"
                       style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">

                    <!-- Header with colored banner -->
                    <tr>
                        <td style="background-color: {color}; padding: 20px; text-align: center;">
                            {
        f'<img src="cid:{header_image_cid}" alt="" style="display: block; max-width: 240px; max-height: 80px; margin: 0 auto;">'
        if header_image_cid
        else f'<div style="font-size: 48px; color: #ffffff; margin-bottom: 10px;">{icon}</div>'
    }
                        </td>
                    </tr>

                    <!-- Title -->
                    <tr>
                        <td style="padding: 40px 40px 20px;">
                            <h1 style="margin: 0; color: #333; font-size: 24px; font-weight: bold;">
                                {title}
                            </h1>
                            {
        f'<p style="margin: 10px 0 0; color: #666; font-size: 16px;">{sub_title}</p>' if sub_title else ""
    }
                        </td>
                    </tr>

                    {performed_by_html}

                    {fields_html}

                    <!-- Message body -->
                    {
        f'''
                    <tr>
                        <td style="padding: 20px 40px;">
                            <p style="margin: 0; color: #333; font-size: 16px; line-height: 1.6;">
                                {message_body}
                            </p>
                        </td>
                    </tr>
                    '''
        if message_body
        else ""
    }

                    {action_button_html}

                    {support_html}

                    <!-- Footer links -->
                    <tr>
                        <td style="padding: 10px 40px 40px; text-align: center;">
                            <a href="{app_url}"
                               style="padding: 5px 15px; color: #5b5b5b; text-decoration: none; font-size: 14px;">
                                {app_name}
                            </a>
                        </td>
                    </tr>

                </table>
            </td>
        </tr>
    </table>
</body>
</html>
    """

    return html.strip()


async def send_time_off_notification(
    notification_data: TimeOffNotificationData,
    action_type: str,
    to_email: str,
    cc_email: str | None = None,
    tenant_key: str | None = None,
) -> NotificationResponse:
    """Send time off notification (approved/rejected)."""
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping time off notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:  # noqa: PLW0717
        absence_type_display = format_absence_type(notification_data.absence_type)

        if action_type == "approved":
            title = f"Time Off Request Approved - {absence_type_display.title()}"
            message_body = f"Your {absence_type_display.lower()} request has been approved."
        elif action_type == "rejected":
            title = f"Time Off Request Rejected - {absence_type_display.title()}"
            message_body = f"Your {absence_type_display.lower()} request has been rejected."
        elif action_type == "submitted":
            title = f"New Time Off Request - {absence_type_display.title()}"
            message_body = f"A new {absence_type_display.lower()} request has been submitted for your review."
        else:
            title = f"Time Off Request - {absence_type_display.title()}"
            message_body = "Your time off request status has been updated."

        fields = [
            NotificationField(label="Request ID", value=f"#{notification_data.request_id}"),
            NotificationField(label="Type", value=absence_type_display),
            NotificationField(label="Start Date", value=notification_data.start_date),
            NotificationField(label="End Date", value=notification_data.end_date),
            NotificationField(label="Total Days", value=notification_data.total_days),
        ]

        if notification_data.total_hours:
            fields.append(NotificationField(label="Total Hours", value=notification_data.total_hours))

        if notification_data.reason:
            fields.append(NotificationField(label="Reason", value=notification_data.reason))

        if notification_data.review_notes:
            fields.append(NotificationField(label="Review Notes", value=notification_data.review_notes))

        branding = _resolve_email_branding(tenant_key)

        html_body = generate_notification_html(
            title=title,
            sub_title=f"Request #{notification_data.request_id}",
            action_type=action_type,
            message_body=message_body,
            performed_by_name=notification_data.reviewed_by_name,
            performed_by_email=notification_data.reviewed_by_email,
            fields=fields,
            action_url=notification_data.action_url,
            action_text="View Request",
            support_email=branding["support_email"],
            app_url=branding["app_url"],
            app_name=branding["app_name"],
            include_support_section=branding["include_support_section"],
        )

        to_emails = parse_email_list(to_email)
        cc_emails = parse_email_list(cc_email) if cc_email else None

        sender_email = getattr(settings, "BOT_EMAIL", None)
        if not sender_email:
            return NotificationResponse(
                success=False,
                error_message="No sender email configured (BOT_EMAIL)",
            )

        subject = title
        success, message_id, error_message = await send_outlook_email(
            send_as_email=sender_email,
            to_emails=to_emails,
            subject=subject,
            body=html_body,
            cc_emails=cc_emails,
        )

        if success:
            return NotificationResponse(success=True, message_id=message_id)
        return NotificationResponse(success=False, error_message=error_message)

    except Exception as e:
        return NotificationResponse(
            success=False,
            error_message=f"Error sending time off notification: {e!s}",
        )


async def send_ticket_assigned_notification(
    notification_data: TicketNotificationData,
    to_email: str,
    cc_email: str | None = None,
) -> NotificationResponse:
    """Send notification when a ticket is assigned to someone."""
    logger.info(f"[SEND_TICKET_ASSIGNED] Starting - ticket_id={notification_data.ticket_id}, to_email={to_email}")

    if not _should_send_notification():
        logger.info(
            f"[SEND_TICKET_ASSIGNED] Notifications disabled - returning early for ticket_id={notification_data.ticket_id}"
        )
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:  # noqa: PLW0717
        logger.info(f"[SEND_TICKET_ASSIGNED] Building notification HTML for ticket_id={notification_data.ticket_id}")
        title = "Ticket Assigned to You"
        message_body = f"A ticket has been assigned to you: {notification_data.title}"

        fields = [
            NotificationField(label="Ticket ID", value=f"#{notification_data.ticket_id}"),
            NotificationField(label="Title", value=notification_data.title),
            NotificationField(label="Status", value=notification_data.status.title()),
            NotificationField(label="Priority", value=notification_data.priority.title()),
            NotificationField(label="Created By", value=notification_data.created_by_name),
        ]

        if notification_data.description:
            fields.append(
                NotificationField(
                    label="Description",
                    value=notification_data.description[:200]
                    + ("..." if len(notification_data.description) > 200 else ""),
                )
            )

        html_body = generate_notification_html(
            title=title,
            sub_title=f"Ticket #{notification_data.ticket_id}",
            action_type="created",
            message_body=message_body,
            performed_by_name=notification_data.created_by_name,
            performed_by_email=notification_data.created_by_email,
            fields=fields,
            action_url=notification_data.action_url,
            action_text="View Ticket",
        )
        logger.info(
            f"[SEND_TICKET_ASSIGNED] HTML body generated successfully for ticket_id={notification_data.ticket_id}"
        )

        to_emails = parse_email_list(to_email)
        logger.info(f"[SEND_TICKET_ASSIGNED] Parsed recipient emails: {to_emails}")

        cc_emails = parse_email_list(cc_email) if cc_email else None

        sender_email = getattr(settings, "BOT_EMAIL", None)
        if not sender_email:
            logger.error("[SEND_TICKET_ASSIGNED] BOT_EMAIL not configured!")
            return NotificationResponse(
                success=False,
                error_message="No sender email configured (BOT_EMAIL)",
            )
        logger.info(f"[SEND_TICKET_ASSIGNED] Using sender email: {sender_email}")

        subject = f"Ticket Assigned: {notification_data.title}"
        logger.info(f"[SEND_TICKET_ASSIGNED] Calling send_outlook_email for ticket_id={notification_data.ticket_id}")
        success, message_id, error_message = await send_outlook_email(
            send_as_email=sender_email,
            to_emails=to_emails,
            subject=subject,
            body=html_body,
            cc_emails=cc_emails,
        )

        if success:
            logger.info(
                f"[SEND_TICKET_ASSIGNED] Email sent successfully for ticket_id={notification_data.ticket_id}, message_id={message_id}"
            )
            return NotificationResponse(success=True, message_id=message_id)

        logger.error(
            f"[SEND_TICKET_ASSIGNED] Email send failed for ticket_id={notification_data.ticket_id}, error={error_message}"
        )
        return NotificationResponse(success=False, error_message=error_message)

    except Exception as e:
        logger.exception(
            f"[SEND_TICKET_ASSIGNED] Exception occurred for ticket_id={notification_data.ticket_id}: {e!s}"
        )
        return NotificationResponse(
            success=False,
            error_message=f"Error sending ticket assigned notification: {e!s}",
        )


async def send_ticket_created_notification(
    notification_data: TicketNotificationData,
    to_email: str,
    cc_email: str | None = None,
) -> NotificationResponse:
    """Send notification when a ticket is created."""
    logger.info(f"[SEND_TICKET_CREATED] Starting - ticket_id={notification_data.ticket_id}, to_email={to_email}")

    if not _should_send_notification():
        logger.info(
            f"[SEND_TICKET_CREATED] Notifications disabled - returning early for ticket_id={notification_data.ticket_id}"
        )
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:  # noqa: PLW0717
        logger.info(f"[SEND_TICKET_CREATED] Building notification HTML for ticket_id={notification_data.ticket_id}")
        title = "New Ticket Created"
        message_body = f"A new ticket has been created: {notification_data.title}"

        fields = [
            NotificationField(label="Ticket ID", value=f"#{notification_data.ticket_id}"),
            NotificationField(label="Title", value=notification_data.title),
            NotificationField(label="Status", value=notification_data.status.title()),
            NotificationField(label="Priority", value=notification_data.priority.title()),
            NotificationField(label="Created By", value=notification_data.created_by_name),
        ]

        if notification_data.description:
            fields.append(
                NotificationField(
                    label="Description",
                    value=notification_data.description[:200]
                    + ("..." if len(notification_data.description) > 200 else ""),
                )
            )

        if notification_data.assigned_to_name:
            fields.append(NotificationField(label="Assigned To", value=notification_data.assigned_to_name))

        html_body = generate_notification_html(
            title=title,
            sub_title=f"Ticket #{notification_data.ticket_id}",
            action_type="created",
            message_body=message_body,
            performed_by_name=notification_data.created_by_name,
            performed_by_email=notification_data.created_by_email,
            fields=fields,
            action_url=notification_data.action_url,
            action_text="View Ticket",
        )
        logger.info(
            f"[SEND_TICKET_CREATED] HTML body generated successfully for ticket_id={notification_data.ticket_id}"
        )

        to_emails = parse_email_list(to_email)
        logger.info(f"[SEND_TICKET_CREATED] Parsed recipient emails: {to_emails}")

        cc_emails = parse_email_list(cc_email) if cc_email else None

        sender_email = getattr(settings, "BOT_EMAIL", None)
        if not sender_email:
            logger.error("[SEND_TICKET_CREATED] BOT_EMAIL not configured!")
            return NotificationResponse(
                success=False,
                error_message="No sender email configured (BOT_EMAIL)",
            )
        logger.info(f"[SEND_TICKET_CREATED] Using sender email: {sender_email}")

        subject = f"New Ticket: {notification_data.title}"
        logger.info(f"[SEND_TICKET_CREATED] Calling send_outlook_email for ticket_id={notification_data.ticket_id}")
        success, message_id, error_message = await send_outlook_email(
            send_as_email=sender_email,
            to_emails=to_emails,
            subject=subject,
            body=html_body,
            cc_emails=cc_emails,
        )

        if success:
            logger.info(
                f"[SEND_TICKET_CREATED] Email sent successfully for ticket_id={notification_data.ticket_id}, message_id={message_id}"
            )
            return NotificationResponse(success=True, message_id=message_id)

        logger.error(
            f"[SEND_TICKET_CREATED] Email send failed for ticket_id={notification_data.ticket_id}, error={error_message}"
        )
        return NotificationResponse(success=False, error_message=error_message)

    except Exception as e:
        logger.exception(f"[SEND_TICKET_CREATED] Exception occurred for ticket_id={notification_data.ticket_id}: {e!s}")
        return NotificationResponse(
            success=False,
            error_message=f"Error sending ticket created notification: {e!s}",
        )


async def send_ticket_message_notification(
    notification_data: TicketMessageNotificationData,
    to_email: str,
    cc_email: str | None = None,
) -> NotificationResponse:
    """Send notification when a ticket message is posted."""
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping ticket message notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:  # noqa: PLW0717
        title = "New Comment on Ticket"
        message_body = f"{notification_data.commenter_name} commented on ticket: {notification_data.ticket_title}"

        message_preview = notification_data.message_text[:200] + (
            "..." if len(notification_data.message_text) > 200 else ""
        )

        fields = [
            NotificationField(label="Ticket ID", value=f"#{notification_data.ticket_id}"),
            NotificationField(label="Ticket Title", value=notification_data.ticket_title),
            NotificationField(label="Comment", value=message_preview),
        ]

        html_body = generate_notification_html(
            title=title,
            sub_title=f"Ticket #{notification_data.ticket_id}",
            action_type="commented",
            message_body=message_body,
            performed_by_name=notification_data.commenter_name,
            performed_by_email=notification_data.commenter_email,
            fields=fields,
            action_url=notification_data.action_url,
            action_text="View Ticket",
        )

        to_emails = parse_email_list(to_email)
        cc_emails = parse_email_list(cc_email) if cc_email else None

        sender_email = getattr(settings, "BOT_EMAIL", None)
        if not sender_email:
            return NotificationResponse(
                success=False,
                error_message="No sender email configured (BOT_EMAIL)",
            )

        subject = f"New Comment on Ticket #{notification_data.ticket_id}: {notification_data.ticket_title}"
        success, message_id, error_message = await send_outlook_email(
            send_as_email=sender_email,
            to_emails=to_emails,
            subject=subject,
            body=html_body,
            cc_emails=cc_emails,
        )

        if success:
            return NotificationResponse(success=True, message_id=message_id)
        return NotificationResponse(success=False, error_message=error_message)

    except Exception as e:
        return NotificationResponse(
            success=False,
            error_message=f"Error sending ticket message notification: {e!s}",
        )


async def send_user_approval_notification(
    notification_data: UserApprovalNotificationData,
    to_email: str,
    cc_email: str | None = None,
) -> NotificationResponse:
    """Send notification when a user is approved and ready to use."""
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping user approval notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:  # noqa: PLW0717
        title = "Account Approved and Ready"
        message_body = "Your account has been approved and is now ready to use."

        fields = [
            NotificationField(label="User ID", value=f"#{notification_data.user_id}"),
            NotificationField(label="Name", value=notification_data.user_name),
            NotificationField(label="Email", value=notification_data.user_email),
        ]

        if notification_data.approved_by_name:
            fields.append(NotificationField(label="Approved By", value=notification_data.approved_by_name))

        html_body = generate_notification_html(
            title=title,
            sub_title=f"Welcome, {notification_data.user_name}!",
            action_type="user_approved",
            message_body=message_body,
            performed_by_name=notification_data.approved_by_name,
            performed_by_email=notification_data.approved_by_email,
            fields=fields,
            action_url=notification_data.action_url,
            action_text="Access Your Account",
        )

        to_emails = parse_email_list(to_email)
        cc_emails = parse_email_list(cc_email) if cc_email else None

        sender_email = getattr(settings, "BOT_EMAIL", None)
        if not sender_email:
            return NotificationResponse(
                success=False,
                error_message="No sender email configured (BOT_EMAIL)",
            )

        subject = "Account Approved - Ready to Use"
        success, message_id, error_message = await send_outlook_email(
            send_as_email=sender_email,
            to_emails=to_emails,
            subject=subject,
            body=html_body,
            cc_emails=cc_emails,
        )

        if success:
            return NotificationResponse(success=True, message_id=message_id)
        return NotificationResponse(success=False, error_message=error_message)

    except Exception as e:
        return NotificationResponse(
            success=False,
            error_message=f"Error sending user approval notification: {e!s}",
        )


# Helper functions for easy integration with API endpoints


async def notify_time_off_approved(
    request_id: int,
    employee_id: int,
    employee_name: str,
    employee_email: str,
    absence_type: str,
    start_date: str,
    end_date: str,
    total_days: str,
    total_hours: str | None = None,
    reason: str | None = None,
    reviewed_by_name: str | None = None,
    reviewed_by_email: str | None = None,
    review_notes: str | None = None,
    action_url: str | None = None,
    tenant_key: str | None = None,
) -> NotificationResponse:
    """Helper function to send time off approved notification."""
    notification_data = TimeOffNotificationData(
        request_id=request_id,
        employee_id=employee_id,
        employee_name=employee_name,
        employee_email=employee_email,
        absence_type=absence_type,
        start_date=start_date,
        end_date=end_date,
        total_days=total_days,
        total_hours=total_hours,
        reason=reason,
        reviewed_by_name=reviewed_by_name,
        reviewed_by_email=reviewed_by_email,
        review_notes=review_notes,
        action_url=action_url,
    )
    return await send_time_off_notification(
        notification_data=notification_data,
        action_type="approved",
        to_email=employee_email,
        tenant_key=tenant_key,
    )


async def notify_time_off_rejected(
    request_id: int,
    employee_id: int,
    employee_name: str,
    employee_email: str,
    absence_type: str,
    start_date: str,
    end_date: str,
    total_days: str,
    total_hours: str | None = None,
    reason: str | None = None,
    reviewed_by_name: str | None = None,
    reviewed_by_email: str | None = None,
    review_notes: str | None = None,
    action_url: str | None = None,
    tenant_key: str | None = None,
) -> NotificationResponse:
    """Helper function to send time off rejected notification."""
    notification_data = TimeOffNotificationData(
        request_id=request_id,
        employee_id=employee_id,
        employee_name=employee_name,
        employee_email=employee_email,
        absence_type=absence_type,
        start_date=start_date,
        end_date=end_date,
        total_days=total_days,
        total_hours=total_hours,
        reason=reason,
        reviewed_by_name=reviewed_by_name,
        reviewed_by_email=reviewed_by_email,
        review_notes=review_notes,
        action_url=action_url,
    )
    return await send_time_off_notification(
        notification_data=notification_data,
        action_type="rejected",
        to_email=employee_email,
        tenant_key=tenant_key,
    )


async def notify_time_off_submitted(
    request_id: int,
    employee_id: int,
    employee_name: str,
    employee_email: str,
    absence_type: str,
    start_date: str,
    end_date: str,
    total_days: str,
    to_email: str,
    total_hours: str | None = None,
    reason: str | None = None,
    action_url: str | None = None,
    tenant_key: str | None = None,
    cc_email: str | None = None,
) -> NotificationResponse:
    """Helper function to send time off submitted notification (to manager)."""
    notification_data = TimeOffNotificationData(
        request_id=request_id,
        employee_id=employee_id,
        employee_name=employee_name,
        employee_email=employee_email,
        absence_type=absence_type,
        start_date=start_date,
        end_date=end_date,
        total_days=total_days,
        total_hours=total_hours,
        reason=reason,
        reviewed_by_name=employee_name,  # The requester "performed" the submission
        reviewed_by_email=employee_email,
        action_url=action_url,
    )
    return await send_time_off_notification(
        notification_data=notification_data,
        action_type="submitted",
        to_email=to_email,
        cc_email=cc_email,
        tenant_key=tenant_key,
    )


async def notify_ticket_created(
    ticket_id: int,
    title: str,
    description: str | None = None,
    status: str = "todo",
    priority: str = "normal",
    created_by_name: str = "",
    created_by_email: str = "",
    assigned_to_name: str | None = None,
    assigned_to_email: str | None = None,
    action_url: str | None = None,
    notify_assignee: bool = True,
) -> tuple[NotificationResponse, NotificationResponse | None]:
    """Helper function to send ticket created notifications.

    Returns:
        (creator_notification, assignee_notification)
    """
    logger.info(f"[NOTIFY_TICKET_CREATED] Starting notification process for ticket_id={ticket_id}")
    logger.info(f"[NOTIFY_TICKET_CREATED] Created by: {created_by_name} ({created_by_email})")
    logger.info(
        f"[NOTIFY_TICKET_CREATED] Assigned to: {assigned_to_name} ({assigned_to_email}), notify_assignee={notify_assignee}"
    )

    notification_data = TicketNotificationData(
        ticket_id=ticket_id,
        title=title,
        description=description,
        status=status,
        priority=priority,
        created_by_name=created_by_name,
        created_by_email=created_by_email,
        assigned_to_name=assigned_to_name,
        assigned_to_email=assigned_to_email,
        action_url=action_url,
    )

    logger.info(f"[NOTIFY_TICKET_CREATED] Sending creator notification to {created_by_email}")
    creator_notification = await send_ticket_created_notification(
        notification_data=notification_data,
        to_email=created_by_email,
    )
    logger.info(
        f"[NOTIFY_TICKET_CREATED] Creator notification result: success={creator_notification.success}, message_id={creator_notification.message_id}, error={creator_notification.error_message}"
    )

    assignee_notification = None
    if notify_assignee and assigned_to_email and assigned_to_email != created_by_email:
        logger.info(f"[NOTIFY_TICKET_CREATED] Sending assignee notification to {assigned_to_email}")
        assignee_notification = await send_ticket_created_notification(
            notification_data=notification_data,
            to_email=assigned_to_email,
        )
        logger.info(
            f"[NOTIFY_TICKET_CREATED] Assignee notification result: success={assignee_notification.success}, message_id={assignee_notification.message_id}, error={assignee_notification.error_message}"
        )
    else:
        logger.info(
            f"[NOTIFY_TICKET_CREATED] Skipping assignee notification: notify_assignee={notify_assignee}, assigned_to_email={assigned_to_email}, same_as_creator={assigned_to_email == created_by_email}"
        )

    logger.info(f"[NOTIFY_TICKET_CREATED] Notification process completed for ticket_id={ticket_id}")
    return creator_notification, assignee_notification


async def notify_ticket_message(
    ticket_id: int,
    ticket_title: str,
    message_id: int,
    message_text: str,
    commenter_id: int,
    commenter_name: str,
    commenter_email: str,
    ticket_creator_id: int,
    ticket_creator_email: str,
    ticket_assigned_to_id: int | None = None,
    ticket_assigned_to_email: str | None = None,
    action_url: str | None = None,
) -> tuple[NotificationResponse | None, NotificationResponse | None]:
    """Helper function to send ticket message notifications.

    Logic:
    - In LOCAL: Always notify both creator and assignee (skip validation)
    - In PROD:
      - If commenter is creator, notify assignee
      - If commenter is assignee, notify creator
      - If commenter is neither, notify both creator and assignee

    Returns:
        (creator_notification, assignee_notification)
    """
    notification_data = TicketMessageNotificationData(
        ticket_id=ticket_id,
        ticket_title=ticket_title,
        message_id=message_id,
        message_text=message_text,
        commenter_name=commenter_name,
        commenter_email=commenter_email,
        action_url=action_url,
    )

    creator_notification = None
    assignee_notification = None

    environment = settings.ENVIRONMENT.value if hasattr(settings.ENVIRONMENT, "value") else str(settings.ENVIRONMENT)
    is_local = environment == "local"

    if is_local:
        if ticket_creator_email:
            creator_notification = await send_ticket_message_notification(
                notification_data=notification_data,
                to_email=ticket_creator_email,
            )
        if ticket_assigned_to_email:
            assignee_notification = await send_ticket_message_notification(
                notification_data=notification_data,
                to_email=ticket_assigned_to_email,
            )
    else:
        is_commenter_creator = commenter_id == ticket_creator_id
        is_commenter_assignee = ticket_assigned_to_id and commenter_id == ticket_assigned_to_id

        if is_commenter_creator:
            if ticket_assigned_to_email and ticket_assigned_to_email != commenter_email:
                assignee_notification = await send_ticket_message_notification(
                    notification_data=notification_data,
                    to_email=ticket_assigned_to_email,
                )
        elif is_commenter_assignee:
            if ticket_creator_email and ticket_creator_email != commenter_email:
                creator_notification = await send_ticket_message_notification(
                    notification_data=notification_data,
                    to_email=ticket_creator_email,
                )
        else:
            if ticket_creator_email and ticket_creator_email != commenter_email:
                creator_notification = await send_ticket_message_notification(
                    notification_data=notification_data,
                    to_email=ticket_creator_email,
                )
            if ticket_assigned_to_email and ticket_assigned_to_email != commenter_email:
                assignee_notification = await send_ticket_message_notification(
                    notification_data=notification_data,
                    to_email=ticket_assigned_to_email,
                )

    return creator_notification, assignee_notification


async def notify_user_approved(
    user_id: int,
    user_name: str,
    user_email: str,
    approved_by_name: str | None = None,
    approved_by_email: str | None = None,
    action_url: str | None = None,
) -> NotificationResponse:
    """Helper function to send user approval notification."""
    notification_data = UserApprovalNotificationData(
        user_id=user_id,
        user_name=user_name,
        user_email=user_email,
        approved_by_name=approved_by_name,
        approved_by_email=approved_by_email,
        action_url=action_url,
    )
    return await send_user_approval_notification(
        notification_data=notification_data,
        to_email=user_email,
    )


async def send_custom_notification(
    title: str,
    message_body: str,
    to_email: str,
    cc_email: str | None = None,
    action_type: str = "info",
    sub_title: str | None = None,
    performed_by_name: str | None = None,
    performed_by_email: str | None = None,
    fields: list[NotificationField] | None = None,
    action_url: str | None = None,
    action_text: str = "View Details",
) -> NotificationResponse:
    """Send custom notification with basic parameters.

    Args:
        title: Email title/subject
        message_body: Main message content
        to_email: Recipient email address
        cc_email: Optional CC email address
        action_type: Type of action (approved, rejected, created, info, etc.)
        sub_title: Optional subtitle
        performed_by_name: Optional name of person who performed the action
        performed_by_email: Optional email of person who performed the action
        fields: Optional list of fields to display
        action_url: Optional URL for action button
        action_text: Text for action button

    Returns:
        NotificationResponse with success status
    """
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping custom notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:
        return await _send_custom_notification(
            title=title,
            sub_title=sub_title,
            action_type=action_type,
            message_body=message_body,
            performed_by_name=performed_by_name,
            performed_by_email=performed_by_email,
            fields=fields,
            action_url=action_url,
            action_text=action_text,
            to_email=to_email,
            cc_email=cc_email,
        )

    except Exception as e:
        return NotificationResponse(
            success=False,
            error_message=f"Error sending custom notification: {e!s}",
        )


async def _send_custom_notification(
    *,
    title: str,
    message_body: str,
    to_email: str,
    cc_email: str | None,
    action_type: str,
    sub_title: str | None,
    performed_by_name: str | None,
    performed_by_email: str | None,
    fields: list[NotificationField] | None,
    action_url: str | None,
    action_text: str,
) -> NotificationResponse:
    html_body = generate_notification_html(
        title=title,
        sub_title=sub_title,
        action_type=action_type,
        message_body=message_body,
        performed_by_name=performed_by_name,
        performed_by_email=performed_by_email,
        fields=fields,
        action_url=action_url,
        action_text=action_text,
    )
    to_emails = parse_email_list(to_email)
    cc_emails = parse_email_list(cc_email) if cc_email else None
    sender_email = getattr(settings, "BOT_EMAIL", None)
    if not sender_email:
        return NotificationResponse(
            success=False,
            error_message="No sender email configured (BOT_EMAIL)",
        )

    success, message_id, error_message = await send_outlook_email(
        send_as_email=sender_email,
        to_emails=to_emails,
        subject=title,
        body=html_body,
        cc_emails=cc_emails,
    )
    if success:
        return NotificationResponse(success=True, message_id=message_id)
    return NotificationResponse(success=False, error_message=error_message)


async def notify_teams(
    recipient_email: str,
    title: str,
    message_body: str,
    action_url: str | None = None,
    action_text: str = "View Details",
) -> NotificationResponse:
    """
    Send a Teams notification to a user.

    Always uses BOT_EMAIL as sender (orchestrator).

    Args:
        recipient_email: Email address of the recipient
        title: Notification title
        message_body: Main message content
        action_url: Optional URL for action button
        action_text: Text for action button

    Returns:
        NotificationResponse with success status
    """
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping teams notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    return await send_teams_notification(
        recipient_email=recipient_email,
        title=title,
        message_body=message_body,
        action_url=action_url,
        action_text=action_text,
    )


_INVENTORY_MOVEMENT_CONTENT: dict[str, tuple[str, str, str]] = {
    "IN": (
        "New Inventory Entry",
        "A new inventory entry has been registered in your warehouse.",
        "created",
    ),
    "OUT": (
        "New Inventory Output",
        "A new inventory output has been registered in your warehouse.",
        "submitted",
    ),
    "ADJUSTMENT": (
        "New Inventory Adjustment",
        "A new inventory adjustment has been registered in your warehouse.",
        "pending",
    ),
}


def _inventory_movement_fields(notification_data: InventoryMovementNotificationData) -> list[NotificationField]:
    product_display = notification_data.product_name
    if notification_data.product_code:
        product_display = f"{notification_data.product_code} - {notification_data.product_name}"

    fields = [
        NotificationField(label="Movement ID", value=f"#{notification_data.movement_id}"),
        NotificationField(label="Product", value=product_display),
        NotificationField(label="Quantity", value=notification_data.quantity),
    ]

    if notification_data.warehouse_name:
        fields.append(NotificationField(label="Warehouse", value=notification_data.warehouse_name))
    if notification_data.movement_date:
        fields.append(NotificationField(label="Date", value=notification_data.movement_date))
    if notification_data.project:
        fields.append(NotificationField(label="Project", value=notification_data.project))
    if notification_data.po_number:
        fields.append(NotificationField(label="PO Number", value=notification_data.po_number))
    if notification_data.reference_type:
        fields.append(NotificationField(label="Reference Type", value=notification_data.reference_type))
    if notification_data.notes:
        notes_preview = notification_data.notes[:200] + ("..." if len(notification_data.notes) > 200 else "")
        fields.append(NotificationField(label="Notes", value=notes_preview))

    return fields


async def send_inventory_movement_notification(
    notification_data: InventoryMovementNotificationData,
    to_email: str,
) -> NotificationResponse:
    """Send notification when an inventory movement (entry/output/adjustment) is registered."""
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping inventory movement notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:
        title, message_body, action_type = _INVENTORY_MOVEMENT_CONTENT.get(
            notification_data.movement_type,
            ("Inventory Movement", "An inventory movement has been registered in your warehouse.", "info"),
        )

        html_body = generate_notification_html(
            title=title,
            sub_title=f"Movement #{notification_data.movement_id}",
            action_type=action_type,
            message_body=message_body,
            performed_by_name=notification_data.created_by_name,
            fields=_inventory_movement_fields(notification_data),
            action_url=notification_data.action_url,
            action_text="View Inventory",
        )

        sender_email = getattr(settings, "BOT_EMAIL", None)
        if not sender_email:
            return NotificationResponse(
                success=False,
                error_message="No sender email configured (BOT_EMAIL)",
            )

        subject = f"{title} - {notification_data.product_name}"
        success, message_id, error_message = await send_outlook_email(
            send_as_email=sender_email,
            to_emails=parse_email_list(to_email),
            subject=subject,
            body=html_body,
        )

        if success:
            return NotificationResponse(success=True, message_id=message_id)
        return NotificationResponse(success=False, error_message=error_message)

    except Exception as e:
        return NotificationResponse(
            success=False,
            error_message=f"Error sending inventory movement notification: {e!s}",
        )


async def notify_inventory_movement(
    movement_id: int,
    movement_type: str,
    product_name: str,
    quantity: str,
    to_emails: list[str],
    product_code: str | None = None,
    warehouse_name: str | None = None,
    movement_date: str | None = None,
    project: str | None = None,
    po_number: str | None = None,
    reference_type: str | None = None,
    notes: str | None = None,
    created_by_name: str | None = None,
    action_url: str | None = None,
) -> list[NotificationResponse]:
    """Helper function to send inventory movement notifications to multiple recipients."""
    notification_data = InventoryMovementNotificationData(
        movement_id=movement_id,
        movement_type=movement_type,
        product_name=product_name,
        product_code=product_code,
        warehouse_name=warehouse_name,
        quantity=quantity,
        movement_date=movement_date,
        project=project,
        po_number=po_number,
        reference_type=reference_type,
        notes=notes,
        created_by_name=created_by_name,
        action_url=action_url,
    )

    responses = []
    for email in to_emails:
        response = await send_inventory_movement_notification(
            notification_data=notification_data,
            to_email=email,
        )
        responses.append(response)
    return responses


_MOVEMENT_TYPE_LABELS: dict[str, str] = {
    "OUT": "Output",
    "ADJUSTMENT": "Adjustment",
}


def _inventory_approval_fields(notification_data: InventoryApprovalNotificationData) -> list[NotificationField]:
    product_display = notification_data.product_name
    if notification_data.product_code:
        product_display = f"{notification_data.product_code} - {notification_data.product_name}"

    fields = [
        NotificationField(label="Request ID", value=f"#{notification_data.approval_id}"),
        NotificationField(label="Product", value=product_display),
        NotificationField(label="Quantity", value=notification_data.quantity),
    ]

    if notification_data.warehouse_name:
        fields.append(NotificationField(label="Warehouse", value=notification_data.warehouse_name))
    if notification_data.movement_date:
        fields.append(NotificationField(label="Date", value=notification_data.movement_date))
    if notification_data.project:
        fields.append(NotificationField(label="Project", value=notification_data.project))
    if notification_data.po_number:
        fields.append(NotificationField(label="PO Number", value=notification_data.po_number))
    if notification_data.notes:
        notes_preview = notification_data.notes[:200] + ("..." if len(notification_data.notes) > 200 else "")
        fields.append(NotificationField(label="Notes", value=notes_preview))
    if notification_data.review_note:
        fields.append(NotificationField(label="Review Note", value=notification_data.review_note))

    return fields


async def _send_inventory_approval_notification(
    notification_data: InventoryApprovalNotificationData,
    title: str,
    message_body: str,
    action_type: str,
    performed_by_name: str | None,
    to_email: str,
) -> NotificationResponse:
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping inventory approval notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:
        html_body = generate_notification_html(
            title=title,
            sub_title=f"Request #{notification_data.approval_id}",
            action_type=action_type,
            message_body=message_body,
            performed_by_name=performed_by_name,
            fields=_inventory_approval_fields(notification_data),
            action_url=notification_data.action_url,
            action_text="View Approvals",
        )

        sender_email = getattr(settings, "BOT_EMAIL", None)
        if not sender_email:
            return NotificationResponse(
                success=False,
                error_message="No sender email configured (BOT_EMAIL)",
            )

        subject = f"{title} - {notification_data.product_name}"
        success, message_id, error_message = await send_outlook_email(
            send_as_email=sender_email,
            to_emails=parse_email_list(to_email),
            subject=subject,
            body=html_body,
        )

        if success:
            return NotificationResponse(success=True, message_id=message_id)
        return NotificationResponse(success=False, error_message=error_message)

    except Exception as e:
        return NotificationResponse(
            success=False,
            error_message=f"Error sending inventory approval notification: {e!s}",
        )


async def notify_movement_approval_requested(
    notification_data: InventoryApprovalNotificationData,
    to_emails: list[str],
) -> list[NotificationResponse]:
    """Notify approvers that an inventory movement approval was requested."""
    type_label = _MOVEMENT_TYPE_LABELS.get(notification_data.movement_type, "Movement")
    title = f"Inventory {type_label} Approval Requested"
    requester = notification_data.requested_by_name or "An employee"
    message_body = (
        f"{requester} has requested an inventory {type_label.lower()} that requires your approval. "
        "The movement will not be executed until it is approved."
    )

    responses = []
    for email in to_emails:
        response = await _send_inventory_approval_notification(
            notification_data=notification_data,
            title=title,
            message_body=message_body,
            action_type="pending",
            performed_by_name=notification_data.requested_by_name,
            to_email=email,
        )
        responses.append(response)
    return responses


async def notify_movement_approval_reviewed(
    notification_data: InventoryApprovalNotificationData,
    approved: bool,
    to_email: str,
) -> NotificationResponse:
    """Notify the requester that their inventory movement request was approved or rejected."""
    type_label = _MOVEMENT_TYPE_LABELS.get(notification_data.movement_type, "Movement")
    if approved:
        title = f"Inventory {type_label} Request Approved"
        message_body = (
            f"Your inventory {type_label.lower()} request has been approved and the movement has been registered."
        )
        action_type = "approved"
    else:
        title = f"Inventory {type_label} Request Rejected"
        message_body = f"Your inventory {type_label.lower()} request has been rejected. No movement was registered."
        action_type = "rejected"

    return await _send_inventory_approval_notification(
        notification_data=notification_data,
        title=title,
        message_body=message_body,
        action_type=action_type,
        performed_by_name=notification_data.reviewed_by_name,
        to_email=to_email,
    )


async def send_timesheet_notification(
    notification_data: TimeSheetNotificationData,
    to_email: str,
) -> NotificationResponse:
    """Send timesheet notification (regular hours or overtime)."""
    if not _should_send_notification():
        logger.info("Notifications disabled - skipping timesheet notification")
        return NotificationResponse(success=True, message_id="notifications_disabled")

    try:
        return await _send_timesheet_notification(notification_data, to_email)

    except Exception as e:
        return NotificationResponse(
            success=False,
            error_message=f"Error sending timesheet notification: {e!s}",
        )


def _timesheet_notification_content(notification_type: str) -> tuple[str, str, str]:
    if notification_type == "regular_hours":
        return (
            "Regular Hours Completed",
            "You have completed your regular hours of work. You may continue working or clock out when ready.",
            "info",
        )
    if notification_type == "overtime":
        return (
            "Overtime Limit Reached",
            "You have reached the overtime limit. Clock out has been performed automatically.",
            "warning",
        )
    return "TimeSheet Update", "Your timesheet has been updated.", "info"


def _timesheet_notification_fields(notification_data: TimeSheetNotificationData) -> list[NotificationField]:
    fields = [
        NotificationField(label="Employee", value=notification_data.employee_name),
        NotificationField(label="Hours Worked", value=format_hours_to_readable(notification_data.hours_worked)),
    ]
    if notification_data.customer_name:
        fields.append(NotificationField(label="Customer", value=notification_data.customer_name))
    if notification_data.clock_in_time:
        fields.append(NotificationField(label="Clock In Time", value=notification_data.clock_in_time))
    return fields


async def _send_timesheet_notification(
    notification_data: TimeSheetNotificationData,
    to_email: str,
) -> NotificationResponse:
    title, message_body, action_type = _timesheet_notification_content(notification_data.notification_type)
    html_body = generate_notification_html(
        title=title,
        sub_title="TimeSheet Notification",
        action_type=action_type,
        message_body=message_body,
        fields=_timesheet_notification_fields(notification_data),
    )
    sender_email = getattr(settings, "BOT_EMAIL", None)
    if not sender_email:
        return NotificationResponse(
            success=False,
            error_message="No sender email configured (BOT_EMAIL)",
        )

    success, message_id, error_message = await send_outlook_email(
        send_as_email=sender_email,
        to_emails=parse_email_list(to_email),
        subject=title,
        body=html_body,
    )
    if success:
        return NotificationResponse(success=True, message_id=message_id)
    return NotificationResponse(success=False, error_message=error_message)


async def notify_timesheet_hours(
    employee_id: int,
    employee_name: str,
    employee_email: str,
    notification_type: str,
    hours_worked: float,
    customer_name: str | None = None,
    clock_in_time: str | None = None,
    action_url: str | None = None,
) -> NotificationResponse:
    """Helper function to send timesheet notification."""
    notification_data = TimeSheetNotificationData(
        employee_id=employee_id,
        employee_name=employee_name,
        employee_email=employee_email,
        notification_type=notification_type,
        hours_worked=hours_worked,
        customer_name=customer_name,
        clock_in_time=clock_in_time,
        action_url=action_url,
    )
    return await send_timesheet_notification(
        notification_data=notification_data,
        to_email=employee_email,
    )
