import csv
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from io import StringIO
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from api.dependencies import (
    get_current_employee,
    get_current_employee_with_permissions,
    require_authentication,
)
from main import app
from models.employees import Employees
from models.time_off import (
    AbsenceTypeEnum,
    Department,
    Holiday,
    RequestStatusEnum,
    TimeOffBalance,
    TimeOffRequest,
    TimeUnitEnum,
)


@pytest.fixture
def emp_manager(db_session: Session):
    emp = Employees(
        email="manager@example.com",
        display_name="Manager User",
    )
    db_session.add(emp)
    db_session.commit()
    db_session.refresh(emp)
    return emp


@pytest.fixture
def emp_user(db_session: Session, emp_manager: Employees):
    emp = Employees(
        email="user@example.com",
        display_name="Standard User",
        department="Engineering",
        manager_employee_id=emp_manager.employee_id,
    )
    db_session.add(emp)
    db_session.commit()
    db_session.refresh(emp)
    return emp


@pytest.fixture
def emp_other(db_session: Session):
    emp = Employees(
        email="other@example.com",
        display_name="Other User",
    )
    db_session.add(emp)
    db_session.commit()
    db_session.refresh(emp)
    return emp


@pytest.fixture
def time_off_request(db_session: Session, emp_user: Employees):
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
    req = TimeOffRequest(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.VACATION.value,
        status=RequestStatusEnum.PENDING.value,
        time_unit=TimeUnitEnum.FULL_DAY.value,
        start_date=(datetime.now(UTC) + timedelta(days=1)).strftime("%Y-%m-%d"),
        end_date=(datetime.now(UTC) + timedelta(days=2)).strftime("%Y-%m-%d"),
        total_days="2.00",
        reason="Need a break",
        created_at=now_str,
        updated_at=now_str,
    )
    db_session.add(req)

    balance = TimeOffBalance(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.VACATION.value,
        year=datetime.now(UTC).year,
        entitled_days="10.00",
        used_days="0.00",
        pending_days="2.00",
        carryover_days="0.00",
    )
    db_session.add(balance)

    db_session.commit()
    db_session.refresh(req)
    return req


@pytest.fixture
def override_deps():
    def _override(user: Employees, permissions: dict | None = None):
        if permissions is None:
            permissions = {"permissions": []}

        app.dependency_overrides[get_current_employee] = lambda: user
        app.dependency_overrides[get_current_employee_with_permissions] = lambda: permissions
        app.dependency_overrides[require_authentication] = lambda: user

    yield _override

    app.dependency_overrides.pop(get_current_employee, None)
    app.dependency_overrides.pop(get_current_employee_with_permissions, None)
    app.dependency_overrides.pop(require_authentication, None)


def test_list_requests_admin(override_deps, client: TestClient, emp_user: Employees, time_off_request: TimeOffRequest):
    admin_perms = {"permissions": [{"module_key": "timeoff", "permissions": {"admin_actions": True}}]}
    override_deps(emp_user, admin_perms)

    response = client.get("/api/v1/requests")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 1
    assert any(r["request_id"] == time_off_request.request_id for r in data)


def test_list_requests_manager(
    override_deps, client: TestClient, emp_manager: Employees, time_off_request: TimeOffRequest
):
    override_deps(emp_manager, {})

    response = client.get("/api/v1/requests")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 1
    assert any(r["request_id"] == time_off_request.request_id for r in data)


def test_list_team_requests_metadata_has_display_data_and_truthful_scope(
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_manager: Employees,
    emp_user: Employees,
    emp_other: Employees,
    time_off_request: TimeOffRequest,
):
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
    db_session.add(
        TimeOffRequest(
            employee_id=emp_other.employee_id,
            absence_type=AbsenceTypeEnum.SICK.value,
            status=RequestStatusEnum.PENDING.value,
            time_unit=TimeUnitEnum.FULL_DAY.value,
            start_date="2026-08-01",
            end_date="2026-08-01",
            total_days="1.00",
            created_at=now_str,
            updated_at=now_str,
        )
    )
    db_session.commit()
    override_deps(emp_manager, {})

    response = client.get(
        "/api/v1/requests?team_only=true&status_scope=pending&with_meta=true&skip=0&limit=1"
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["total"] == 1
    assert payload["has_more"] is False
    assert payload["items"][0]["request_id"] == time_off_request.request_id
    assert payload["items"][0]["employee_name"] == "Standard User"
    assert payload["items"][0]["department"] == "Engineering"


def test_list_team_history_metadata_excludes_pending_and_orders_stably(
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_manager: Employees,
    emp_user: Employees,
):
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
    for request_status in [RequestStatusEnum.APPROVED.value, RequestStatusEnum.REJECTED.value]:
        db_session.add(
            TimeOffRequest(
                employee_id=emp_user.employee_id,
                absence_type=AbsenceTypeEnum.VACATION.value,
                status=request_status,
                time_unit=TimeUnitEnum.FULL_DAY.value,
                start_date="2026-09-01",
                end_date="2026-09-01",
                total_days="1.00",
                created_at=now_str,
                updated_at=now_str,
            )
        )
    db_session.commit()
    override_deps(emp_manager, {})

    response = client.get(
        "/api/v1/requests?team_only=true&status_scope=history&with_meta=true&skip=0&limit=10"
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["total"] == 2
    ids = [item["request_id"] for item in payload["items"]]
    assert ids == sorted(ids, reverse=True)
    assert all(item["status"] != "pending" for item in payload["items"])


def test_list_requests_user(override_deps, client: TestClient, emp_user: Employees, time_off_request: TimeOffRequest):
    override_deps(emp_user, {})

    response = client.get("/api/v1/requests")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 1
    assert any(r["request_id"] == time_off_request.request_id for r in data)


def test_list_requests_other(override_deps, client: TestClient, emp_other: Employees, time_off_request: TimeOffRequest):
    override_deps(emp_other, {})

    response = client.get("/api/v1/requests")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 0


def test_get_request(override_deps, client: TestClient, emp_user: Employees, time_off_request: TimeOffRequest):
    override_deps(emp_user, {})

    response = client.get(f"/api/v1/requests/{time_off_request.request_id}")
    assert response.status_code == 200
    data = response.json()
    assert data["request_id"] == time_off_request.request_id


def test_get_request_forbidden(
    override_deps, client: TestClient, emp_other: Employees, time_off_request: TimeOffRequest
):
    override_deps(emp_other, {})

    response = client.get(f"/api/v1/requests/{time_off_request.request_id}")
    assert response.status_code == 403


def test_get_request_404(override_deps, client: TestClient, emp_user: Employees):
    override_deps(emp_user, {})
    response = client.get("/api/v1/requests/99999")
    assert response.status_code == 404


@patch("api.time_off.BackgroundTasks.add_task")
def test_create_request_full_day(
    mock_add_task, override_deps, client: TestClient, db_session: Session, emp_user: Employees
):
    override_deps(emp_user, {})

    # Create time off balance for the employee
    current_year = datetime.now(UTC).year
    balance = TimeOffBalance(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.VACATION.value,
        year=current_year,
        entitled_days="10.00",
        used_days="0.00",
        pending_days="0.00",
        carryover_days="0.00",
    )
    db_session.add(balance)
    db_session.commit()

    payload = {
        "absence_type": "vacation",
        "time_unit": "full_day",
        "start_date": (datetime.now(UTC) + timedelta(days=1)).strftime("%Y-%m-%d"),
        "end_date": (datetime.now(UTC) + timedelta(days=2)).strftime("%Y-%m-%d"),
        "reason": "Test logic",
    }

    response = client.post("/api/v1/requests", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["total_days"] == "2.00"

    balance = db_session.exec(
        select(TimeOffBalance).where(
            TimeOffBalance.employee_id == emp_user.employee_id,
            TimeOffBalance.absence_type == "vacation",
            TimeOffBalance.year == (datetime.now(UTC) + timedelta(days=1)).year,
        )
    ).first()
    assert balance.pending_days == "2.00"
    mock_add_task.assert_called_once()


@patch("api.time_off.BackgroundTasks.add_task")
def test_create_request_hours(
    mock_add_task, override_deps, client: TestClient, db_session: Session, emp_user: Employees
):
    override_deps(emp_user, {})

    # Create time off balance for the employee
    current_year = datetime.now(UTC).year
    balance = TimeOffBalance(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.PERSONAL.value,
        year=current_year,
        entitled_days="5.00",
        used_days="0.00",
        pending_days="0.00",
        carryover_days="0.00",
    )
    db_session.add(balance)
    db_session.commit()

    payload = {
        "absence_type": "personal",
        "time_unit": "hours",
        "start_date": (datetime.now(UTC) + timedelta(days=1)).strftime("%Y-%m-%d"),
        "end_date": (datetime.now(UTC) + timedelta(days=1)).strftime("%Y-%m-%d"),
        "start_time": "10:00:00",
        "end_time": "14:00:00",
        "reason": "Doctor",
    }

    response = client.post("/api/v1/requests", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["total_hours"] == "4.00"
    assert data["total_days"] == "0.50"


@patch("api.time_off.BackgroundTasks.add_task")
def test_create_request_half_day_requires_single_day(
    _mock_add_task, override_deps, client: TestClient, emp_user: Employees
):
    override_deps(emp_user, {})

    payload = {
        "absence_type": "vacation",
        "time_unit": "half_day",
        "start_date": (datetime.now(UTC) + timedelta(days=1)).strftime("%Y-%m-%d"),
        "end_date": (datetime.now(UTC) + timedelta(days=2)).strftime("%Y-%m-%d"),
        "reason": "Invalid half-day range",
    }

    response = client.post("/api/v1/requests", json=payload)
    assert response.status_code == 400
    assert "half_day requests must use the same start_date and end_date" in response.json()["detail"]


@patch("api.time_off.BackgroundTasks.add_task")
def test_create_request_rejects_overlap_with_active_request(
    _mock_add_task, override_deps, client: TestClient, db_session: Session, emp_user: Employees
):
    override_deps(emp_user, {})

    start = (datetime.now(UTC) + timedelta(days=3)).strftime("%Y-%m-%d")
    end = (datetime.now(UTC) + timedelta(days=4)).strftime("%Y-%m-%d")
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")

    existing = TimeOffRequest(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.VACATION.value,
        status=RequestStatusEnum.APPROVED.value,
        time_unit=TimeUnitEnum.FULL_DAY.value,
        start_date=start,
        end_date=end,
        total_days="2.00",
        reason="Existing approved request",
        created_at=now_str,
        updated_at=now_str,
    )
    db_session.add(existing)
    db_session.commit()

    payload = {
        "absence_type": "vacation",
        "time_unit": "full_day",
        "start_date": start,
        "end_date": end,
        "reason": "Should be blocked",
    }

    response = client.post("/api/v1/requests", json=payload)
    assert response.status_code == 400
    assert "overlaps with an existing pending or approved" in response.json()["detail"]


@patch("api.time_off.BackgroundTasks.add_task")
def test_approve_request_admin(
    mock_add_task, override_deps, client: TestClient, emp_other: Employees, time_off_request: TimeOffRequest
):
    admin_perms = {"permissions": [{"module_key": "timeoff", "permissions": {"admin_actions": True}}]}
    override_deps(emp_other, admin_perms)

    response = client.patch(f"/api/v1/requests/{time_off_request.request_id}/approve", json={"review_notes": "OK"})
    assert response.status_code == 200
    assert response.json()["status"] == "approved"
    mock_add_task.assert_called_once()


@patch("api.time_off.BackgroundTasks.add_task")
def test_reject_request_manager(
    mock_add_task,
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_manager: Employees,
    time_off_request: TimeOffRequest,
):
    override_deps(emp_manager, {})

    balance_before = db_session.exec(
        select(TimeOffBalance).where(TimeOffBalance.employee_id == time_off_request.employee_id)
    ).first()
    pending_before = Decimal(balance_before.pending_days)

    response = client.patch(f"/api/v1/requests/{time_off_request.request_id}/reject", json={"review_notes": "No"})
    assert response.status_code == 200
    assert response.json()["status"] == "rejected"
    mock_add_task.assert_called_once()

    db_session.refresh(balance_before)
    assert Decimal(balance_before.pending_days) == pending_before - Decimal("2.00")


def test_approve_request_forbidden_own(
    override_deps, client: TestClient, emp_user: Employees, time_off_request: TimeOffRequest
):
    override_deps(emp_user, {})
    response = client.patch(
        f"/api/v1/requests/{time_off_request.request_id}/approve", json={"review_notes": "Self approval"}
    )
    assert response.status_code == 403
    assert "cannot approve or reject your own request" in response.json()["detail"]


def test_get_calendar(
    override_deps, client: TestClient, db_session: Session, emp_user: Employees, time_off_request: TimeOffRequest
):
    override_deps(emp_user, {})

    holiday = Holiday(name="New Year", date="2024-01-01", year=2024)
    db_session.add(holiday)
    db_session.commit()

    response = client.get("/api/v1/calendar")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 2


def test_get_report_summary(override_deps, client: TestClient, emp_user: Employees, time_off_request: TimeOffRequest):
    override_deps(emp_user, {})

    response = client.get("/api/v1/reports/summary")
    assert response.status_code == 200
    data = response.json()
    assert data["total_requests"] == 1
    assert data["status"]["pending"] == 1


def test_export_requests_report(
    override_deps, client: TestClient, emp_user: Employees, time_off_request: TimeOffRequest
):
    override_deps(emp_user, {})

    response = client.get("/api/v1/reports/export")
    assert response.status_code == 200
    assert response.headers["Content-Disposition"] == "attachment; filename=time_off_requests.csv"
    assert response.headers.get("content-type", "").startswith("text/csv")

    reader = csv.DictReader(StringIO(response.text))
    rows = list(reader)
    assert len(rows) == 1
    assert str(rows[0]["request_id"]) == str(time_off_request.request_id)


def test_get_balances(override_deps, client: TestClient, emp_user: Employees, time_off_request: TimeOffRequest):
    override_deps(emp_user, {})

    response = client.get(f"/api/v1/balances/{emp_user.employee_id}")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["pending_days"] == "2.00"


def test_get_balances_forbidden(
    override_deps, client: TestClient, emp_other: Employees, emp_user: Employees, time_off_request: TimeOffRequest
):
    override_deps(emp_other, {})

    response = client.get(f"/api/v1/balances/{emp_user.employee_id}")
    assert response.status_code == 403


def test_list_holidays(override_deps, client: TestClient, db_session: Session, emp_user: Employees):
    override_deps(emp_user, {})
    holiday = Holiday(name="Xmas", date="2024-12-25", year=2024)
    db_session.add(holiday)
    db_session.commit()

    response = client.get("/api/v1/holidays")
    assert response.status_code == 200
    assert len(response.json()) >= 1


def test_list_departments(override_deps, client: TestClient, db_session: Session, emp_user: Employees):
    override_deps(emp_user, {})
    dept = Department(name="Engineering", code="ENG")
    db_session.add(dept)
    db_session.commit()

    response = client.get("/api/v1/departments")
    assert response.status_code == 200
    assert len(response.json()) >= 1


# =============================================================================
# PATCH /api/v1/requests/{request_id} — Edit Time Off Request
# =============================================================================


@patch("api.time_off.BackgroundTasks.add_task")
def test_employee_can_edit_own_pending_request(
    mock_add_task,
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_user: Employees,
    time_off_request: TimeOffRequest,
):
    override_deps(emp_user, {})

    new_start = (datetime.now(UTC) + timedelta(days=5)).strftime("%Y-%m-%d")
    new_end = (datetime.now(UTC) + timedelta(days=6)).strftime("%Y-%m-%d")

    payload = {
        "start_date": new_start,
        "end_date": new_end,
        "reason": "Updated reason",
    }

    response = client.patch(f"/api/v1/requests/{time_off_request.request_id}", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["start_date"] == new_start
    assert data["end_date"] == new_end
    assert data["reason"] == "Updated reason"
    assert data["total_days"] == "2.00"
    mock_add_task.assert_called_once()


def test_employee_cannot_edit_own_approved_request(
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_user: Employees,
    time_off_request: TimeOffRequest,
):
    # Approve the request first
    time_off_request.status = RequestStatusEnum.APPROVED.value
    db_session.add(time_off_request)
    db_session.commit()

    override_deps(emp_user, {})

    payload = {"reason": "Trying to edit approved request"}
    response = client.patch(f"/api/v1/requests/{time_off_request.request_id}", json=payload)
    assert response.status_code == 400
    assert "Only pending requests can be edited" in response.json()["detail"]


@patch("api.time_off.BackgroundTasks.add_task")
def test_manager_can_edit_pending_request_of_direct_report(
    mock_add_task,
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_manager: Employees,
    time_off_request: TimeOffRequest,
):
    override_deps(emp_manager, {})

    new_start = (datetime.now(UTC) + timedelta(days=10)).strftime("%Y-%m-%d")
    new_end = (datetime.now(UTC) + timedelta(days=11)).strftime("%Y-%m-%d")

    payload = {
        "start_date": new_start,
        "end_date": new_end,
    }

    response = client.patch(f"/api/v1/requests/{time_off_request.request_id}", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["start_date"] == new_start
    assert data["end_date"] == new_end
    mock_add_task.assert_called_once()


@patch("api.time_off.BackgroundTasks.add_task")
def test_admin_can_edit_approved_request(
    mock_add_task,
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_other: Employees,
    time_off_request: TimeOffRequest,
):
    # Approve the request first
    time_off_request.status = RequestStatusEnum.APPROVED.value
    db_session.add(time_off_request)
    db_session.commit()

    admin_perms = {"permissions": [{"module_key": "timeoff", "permissions": {"admin_actions": True}}]}
    override_deps(emp_other, admin_perms)

    payload = {"reason": "Admin updated the reason"}
    response = client.patch(f"/api/v1/requests/{time_off_request.request_id}", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["reason"] == "Admin updated the reason"
    assert data["status"] == "approved"
    mock_add_task.assert_called_once()


@patch("api.time_off.BackgroundTasks.add_task")
def test_balance_recalculation_when_editing_approved_request(
    mock_add_task,
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_user: Employees,
    emp_other: Employees,
):
    # Create an approved request: 3 full days
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
    start = (datetime.now(UTC) + timedelta(days=20)).strftime("%Y-%m-%d")
    end = (datetime.now(UTC) + timedelta(days=22)).strftime("%Y-%m-%d")
    current_year = datetime.now(UTC).year

    req = TimeOffRequest(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.VACATION.value,
        status=RequestStatusEnum.APPROVED.value,
        time_unit=TimeUnitEnum.FULL_DAY.value,
        start_date=start,
        end_date=end,
        total_days="3.00",
        reason="Original",
        created_at=now_str,
        updated_at=now_str,
    )
    db_session.add(req)

    # Balance reflects approved state: 3 days in used_days
    balance = TimeOffBalance(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.VACATION.value,
        year=current_year,
        entitled_days="15.00",
        used_days="3.00",
        pending_days="0.00",
        carryover_days="0.00",
    )
    db_session.add(balance)
    db_session.commit()
    db_session.refresh(req)

    admin_perms = {"permissions": [{"module_key": "timeoff", "permissions": {"admin_actions": True}}]}
    override_deps(emp_other, admin_perms)

    # Edit to 2 days instead of 3
    new_end = (datetime.now(UTC) + timedelta(days=21)).strftime("%Y-%m-%d")
    payload = {"end_date": new_end}

    response = client.patch(f"/api/v1/requests/{req.request_id}", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["total_days"] == "2.00"

    # Balance should now have 2.00 used_days (reversed 3, applied 2)
    db_session.refresh(balance)
    assert balance.used_days == "2.00"


@patch("api.time_off.BackgroundTasks.add_task")
def test_overlap_validation_on_edit(
    mock_add_task,
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_user: Employees,
    time_off_request: TimeOffRequest,
):
    # Create another approved request that will conflict
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
    conflict_start = (datetime.now(UTC) + timedelta(days=10)).strftime("%Y-%m-%d")
    conflict_end = (datetime.now(UTC) + timedelta(days=12)).strftime("%Y-%m-%d")

    conflicting = TimeOffRequest(
        employee_id=emp_user.employee_id,
        absence_type=AbsenceTypeEnum.PERSONAL.value,
        status=RequestStatusEnum.APPROVED.value,
        time_unit=TimeUnitEnum.FULL_DAY.value,
        start_date=conflict_start,
        end_date=conflict_end,
        total_days="3.00",
        reason="Conflicting request",
        created_at=now_str,
        updated_at=now_str,
    )
    db_session.add(conflicting)
    db_session.commit()

    override_deps(emp_user, {})

    # Try to edit the pending request to overlap with the approved one
    payload = {
        "start_date": conflict_start,
        "end_date": conflict_end,
    }

    response = client.patch(f"/api/v1/requests/{time_off_request.request_id}", json=payload)
    assert response.status_code == 400
    assert "overlaps with an existing pending or approved" in response.json()["detail"]


def test_owner_can_cancel_own_pending_request(
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_user: Employees,
    time_off_request: TimeOffRequest,
):
    override_deps(emp_user, {})

    response = client.delete(f"/api/v1/requests/{time_off_request.request_id}")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "cancelled"

    # Balance should be reversed
    balance = db_session.exec(
        select(TimeOffBalance).where(
            TimeOffBalance.employee_id == emp_user.employee_id,
            TimeOffBalance.absence_type == AbsenceTypeEnum.VACATION.value,
        )
    ).first()
    assert balance is not None
    assert balance.pending_days == "0.00"


def test_other_employee_cannot_cancel_someone_elses_request(
    override_deps,
    client: TestClient,
    emp_other: Employees,
    time_off_request: TimeOffRequest,
):
    override_deps(emp_other, {})

    response = client.delete(f"/api/v1/requests/{time_off_request.request_id}")
    assert response.status_code == 403


def test_admin_can_cancel_pending_request(
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_other: Employees,
    time_off_request: TimeOffRequest,
):
    admin_perms = {"permissions": [{"module_key": "timeoff", "permissions": {"admin_actions": True}}]}
    override_deps(emp_other, admin_perms)

    response = client.delete(f"/api/v1/requests/{time_off_request.request_id}")
    assert response.status_code == 200
    assert response.json()["status"] == "cancelled"


def test_cannot_cancel_approved_request(
    override_deps,
    client: TestClient,
    db_session: Session,
    emp_user: Employees,
    time_off_request: TimeOffRequest,
):
    # First approve the request
    now_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
    time_off_request.status = RequestStatusEnum.APPROVED.value
    time_off_request.updated_at = now_str

    year = int(time_off_request.start_date[:4])
    balance = db_session.exec(
        select(TimeOffBalance).where(
            TimeOffBalance.employee_id == emp_user.employee_id,
            TimeOffBalance.absence_type == AbsenceTypeEnum.VACATION.value,
            TimeOffBalance.year == year,
        )
    ).first()
    balance.pending_days = "0.00"
    balance.used_days = "2.00"
    db_session.add(balance)
    db_session.add(time_off_request)
    db_session.commit()

    override_deps(emp_user, {})

    response = client.delete(f"/api/v1/requests/{time_off_request.request_id}")
    assert response.status_code == 400
    assert "Only pending requests can be cancelled" in response.json()["detail"]
